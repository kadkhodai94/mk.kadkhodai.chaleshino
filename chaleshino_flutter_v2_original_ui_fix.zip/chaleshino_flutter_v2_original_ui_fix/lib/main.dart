import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ChaleshinoApp());
}

class AppColors {
  static const bg = Color(0xFFE8EEF9);
  static const paper = Color(0xFFFEFFFA);
  static const card = Color(0xFFFFFFFF);
  static const ink = Color(0xFF18243B);
  static const muted = Color(0xFF66758F);
  static const line = Color(0x2914C8D8);
  static const primary = Color(0xFF6C63FF);
  static const primary2 = Color(0xFFFFB84D);
  static const primaryDark = Color(0xFFFF9F43);
  static const accent = Color(0xFF8F6CFF);
  static const success = Color(0xFF18BF8F);
  static const danger = Color(0xFFFF5C7A);
  static const cyan = Color(0xFF14C8D8);
  static const deep = Color(0xFF243052);
}

List<BoxShadow> originalShadow({double opacity = .18, double blur = 34, Offset offset = const Offset(0, 18)}) => [
  BoxShadow(color: const Color(0xFF374696).withOpacity(opacity), blurRadius: blur, offset: offset),
  const BoxShadow(color: Color(0xFFFFFFFF), blurRadius: 0, offset: Offset(0, 1), spreadRadius: 0),
];

const adiveryAppId = 'b9b2a447-98d3-4759-973f-5cf3e51a9539';
const adiveryRewardedPlacement = 'c95439ae-07b3-4dac-b71f-21cd4470e605';
const adiveryBannerPlacement = '91f6c8c8-1e9d-4776-be9b-4d14bf4a3fe4';

class ChaleshinoApp extends StatelessWidget {
  const ChaleshinoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'چالشینو',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
        fontFamily: 'Roboto',
        snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: RootScreen(),
      ),
    );
  }
}

class AppData {
  int coins;
  int energy;
  int hints;
  int xp;
  int totalCorrect;
  int totalWrong;
  int totalGames;
  int completedRounds;
  int adsWatched;
  int bestSpeed;
  int streak;
  String lastDaily;
  bool sound;
  bool vibration;
  bool lightMode;
  bool skipTutorial;
  Set<String> achievements;

  AppData({
    this.coins = 850,
    this.energy = 40,
    this.hints = 3,
    this.xp = 0,
    this.totalCorrect = 0,
    this.totalWrong = 0,
    this.totalGames = 0,
    this.completedRounds = 0,
    this.adsWatched = 0,
    this.bestSpeed = 0,
    this.streak = 0,
    this.lastDaily = '',
    this.sound = true,
    this.vibration = true,
    this.lightMode = false,
    this.skipTutorial = false,
    Set<String>? achievements,
  }) : achievements = achievements ?? <String>{};

  factory AppData.fromJson(Map<String, dynamic> json) {
    return AppData(
      coins: json['coins'] ?? 850,
      energy: json['energy'] ?? 40,
      hints: json['hints'] ?? 3,
      xp: json['xp'] ?? 0,
      totalCorrect: json['totalCorrect'] ?? 0,
      totalWrong: json['totalWrong'] ?? 0,
      totalGames: json['totalGames'] ?? 0,
      completedRounds: json['completedRounds'] ?? 0,
      adsWatched: json['adsWatched'] ?? 0,
      bestSpeed: json['bestSpeed'] ?? 0,
      streak: json['streak'] ?? 0,
      lastDaily: json['lastDaily'] ?? '',
      sound: json['sound'] ?? true,
      vibration: json['vibration'] ?? true,
      lightMode: json['lightMode'] ?? false,
      skipTutorial: json['skipTutorial'] ?? false,
      achievements: Set<String>.from(json['achievements'] ?? <String>[]),
    );
  }

  Map<String, dynamic> toJson() => {
        'coins': coins,
        'energy': energy,
        'hints': hints,
        'xp': xp,
        'totalCorrect': totalCorrect,
        'totalWrong': totalWrong,
        'totalGames': totalGames,
        'completedRounds': completedRounds,
        'adsWatched': adsWatched,
        'bestSpeed': bestSpeed,
        'streak': streak,
        'lastDaily': lastDaily,
        'sound': sound,
        'vibration': vibration,
        'lightMode': lightMode,
        'skipTutorial': skipTutorial,
        'achievements': achievements.toList(),
      };
}

class LeagueInfo {
  final String title;
  final String icon;
  final int minXp;
  final int nextXp;
  final double rewardFactor;

  const LeagueInfo(this.title, this.icon, this.minXp, this.nextXp, this.rewardFactor);
}

const leagues = <LeagueInfo>[
  LeagueInfo('برنزی', '🥉', 0, 450, 1.0),
  LeagueInfo('نقره‌ای', '🥈', 450, 1100, 1.15),
  LeagueInfo('طلایی', '🥇', 1100, 2300, 1.35),
  LeagueInfo('الماسی', '💎', 2300, 4200, 1.6),
  LeagueInfo('افسانه‌ای', '👑', 4200, 7000, 2.0),
];

LeagueInfo leagueForXp(int xp) {
  LeagueInfo selected = leagues.first;
  for (final league in leagues) {
    if (xp >= league.minXp) selected = league;
  }
  return selected;
}

enum GameType { choice, word, trueFalse, yesNo, speed, memory }

class GameQuestion {
  final String prompt;
  final List<String> options;
  final String answer;
  final String hint;
  final String visual;
  final List<String> letters;

  const GameQuestion({
    required this.prompt,
    required this.options,
    required this.answer,
    this.hint = '',
    this.visual = '',
    this.letters = const [],
  });
}

class GameDefinition {
  final String id;
  final String title;
  final String icon;
  final String description;
  final GameType type;
  final int energyCost;
  final int baseReward;
  final List<GameQuestion> questions;

  const GameDefinition({
    required this.id,
    required this.title,
    required this.icon,
    required this.description,
    required this.type,
    required this.energyCost,
    required this.baseReward,
    required this.questions,
  });
}

class GameSessionResult {
  final int correct;
  final int wrong;
  final int coins;
  final int xp;
  final bool record;

  const GameSessionResult({
    required this.correct,
    required this.wrong,
    required this.coins,
    required this.xp,
    required this.record,
  });
}

class AchievementDef {
  final String id;
  final String title;
  final String description;
  final String icon;
  final int coins;
  final int xp;

  const AchievementDef(this.id, this.title, this.description, this.icon, this.coins, this.xp);
}

const achievementDefs = <AchievementDef>[
  AchievementDef('first_win', 'شروع قوی', 'اولین بازی کامل شد', '🔥', 120, 30),
  AchievementDef('ten_correct', 'ذهن آماده', '۱۰ جواب درست ثبت شد', '🧠', 180, 55),
  AchievementDef('fifty_rounds', 'بازیکن جدی', '۵۰ مرحله انجام شد', '🎯', 300, 100),
  AchievementDef('gold_league', 'طلایی شدی', 'رسیدن به لیگ طلایی', '🥇', 450, 160),
  AchievementDef('ads_10', 'حامی بازی', '۱۰ تبلیغ جایزه‌دار دیده شد', '🎬', 260, 80),
  AchievementDef('streak_7', 'هفت روزه', '۷ روز پشت سر هم ورود', '📅', 500, 180),
  AchievementDef('speed_6', 'سرعتی‌باز', '۶ جواب درست در چالش سرعتی', '⚡', 350, 120),
];

final games = <GameDefinition>[
  GameDefinition(
    id: 'riddle',
    title: 'چیستان',
    icon: '❓',
    description: 'به معماها سریع جواب بده و سکه بگیر.',
    type: GameType.choice,
    energyCost: 3,
    baseReward: 28,
    questions: const [
      GameQuestion(prompt: 'آن چیست که هرچه بیشتر از آن برداری، بزرگ‌تر می‌شود؟', options: ['چاه', 'سایه', 'آب', 'کوه'], answer: 'چاه', hint: 'روی زمین ایجاد می‌شود.'),
      GameQuestion(prompt: 'کدام کلید هیچ دری را باز نمی‌کند؟', options: ['کلید برق', 'کلید خانه', 'کلید ماشین', 'کلید صندوق'], answer: 'کلید برق'),
      GameQuestion(prompt: 'همیشه جلو می‌رود اما هیچ‌وقت برنمی‌گردد.', options: ['زمان', 'باد', 'رود', 'ماشین'], answer: 'زمان'),
      GameQuestion(prompt: 'نه پا دارد نه بال، ولی حرکت می‌کند.', options: ['ابر', 'سنگ', 'درخت', 'خانه'], answer: 'ابر'),
    ],
  ),
  GameDefinition(
    id: 'word',
    title: 'حدس کلمه',
    icon: '🔤',
    description: 'با حروف داده‌شده جواب درست را بساز.',
    type: GameType.word,
    energyCost: 4,
    baseReward: 35,
    questions: const [
      GameQuestion(prompt: 'وسیله‌ای برای نوشتن', options: [], answer: 'مداد', letters: ['م', 'د', 'ا', 'د', 'ر', 'س'], hint: 'در کیف مدرسه هست.'),
      GameQuestion(prompt: 'چیزی که شب روشن می‌شود', options: [], answer: 'چراغ', letters: ['چ', 'ر', 'ا', 'غ', 'ک', 'ل'], hint: 'نور می‌دهد.'),
      GameQuestion(prompt: 'میوه‌ای زرد و شیرین', options: [], answer: 'موز', letters: ['م', 'و', 'ز', 'ن', 'ا'], hint: 'پوست زرد دارد.'),
      GameQuestion(prompt: 'جای خواندن کتاب', options: [], answer: 'کتابخانه', letters: ['ک', 'ت', 'ا', 'ب', 'خ', 'ا', 'ن', 'ه'], hint: 'پر از کتاب است.'),
    ],
  ),
  GameDefinition(
    id: 'typo',
    title: 'غلط‌یاب',
    icon: '📝',
    description: 'کلمه درست را از بین گزینه‌ها پیدا کن.',
    type: GameType.choice,
    energyCost: 3,
    baseReward: 26,
    questions: const [
      GameQuestion(prompt: 'کدام املا درست است؟', options: ['استثنا', 'استسنا', 'اصتثنا', 'استثنی'], answer: 'استثنا'),
      GameQuestion(prompt: 'کدام کلمه درست نوشته شده؟', options: ['موفقیت', 'موقیت', 'موفغیت', 'موفقییت'], answer: 'موفقیت'),
      GameQuestion(prompt: 'املای درست را انتخاب کن.', options: ['مسئولیت', 'مسولیت', 'مسیولیت', 'مسعولیت'], answer: 'مسئولیت'),
      GameQuestion(prompt: 'کدام گزینه درست است؟', options: ['ضروری', 'زروری', 'ضروی', 'ضرری'], answer: 'ضروری'),
    ],
  ),
  GameDefinition(
    id: 'logic',
    title: 'معمای منطقی',
    icon: '🧩',
    description: 'جواب منطقی را انتخاب کن.',
    type: GameType.choice,
    energyCost: 4,
    baseReward: 38,
    questions: const [
      GameQuestion(prompt: '۲، ۴، ۸، ۱۶، ؟', options: ['۲۴', '۳۲', '۳۰', '۲۸'], answer: '۳۲'),
      GameQuestion(prompt: 'اگر امروز دوشنبه باشد، ۳ روز بعد چه روزی است؟', options: ['چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'], answer: 'پنجشنبه'),
      GameQuestion(prompt: 'کدام عدد زوج نیست؟', options: ['۱۲', '۱۸', '۲۱', '۴۰'], answer: '۲۱'),
      GameQuestion(prompt: 'نصف ۸۰ چند است؟', options: ['۲۰', '۳۰', '۴۰', '۵۰'], answer: '۴۰'),
    ],
  ),
  GameDefinition(
    id: 'visual',
    title: 'معمای تصویری',
    icon: '🖼️',
    description: 'از روی نشانه تصویری جواب بده.',
    type: GameType.choice,
    energyCost: 4,
    baseReward: 34,
    questions: const [
      GameQuestion(prompt: 'این نشانه به چه چیزی نزدیک‌تر است؟', visual: '🌧️ + ☂️', options: ['باران', 'تابستان', 'آتش', 'کوه'], answer: 'باران'),
      GameQuestion(prompt: 'این ترکیب چه مفهومی دارد؟', visual: '📚 + 🧠', options: ['یادگیری', 'خواب', 'ورزش', 'سفر'], answer: 'یادگیری'),
      GameQuestion(prompt: 'این تصویر چه حسی دارد؟', visual: '🏆 + 🎉', options: ['پیروزی', 'ترس', 'خستگی', 'باران'], answer: 'پیروزی'),
      GameQuestion(prompt: 'این ترکیب چیست؟', visual: '⚡ + 🏃', options: ['سرعت', 'آرامش', 'سکوت', 'شب'], answer: 'سرعت'),
    ],
  ),
  GameDefinition(
    id: 'truefalse',
    title: 'درست یا غلط',
    icon: '✅',
    description: 'درستی جمله را تشخیص بده.',
    type: GameType.trueFalse,
    energyCost: 2,
    baseReward: 22,
    questions: const [
      GameQuestion(prompt: 'تهران پایتخت ایران است.', options: ['درست', 'غلط'], answer: 'درست'),
      GameQuestion(prompt: 'عدد ۹ یک عدد زوج است.', options: ['درست', 'غلط'], answer: 'غلط'),
      GameQuestion(prompt: 'آب در دمای معمولی مایع است.', options: ['درست', 'غلط'], answer: 'درست'),
      GameQuestion(prompt: 'خورشید از غرب طلوع می‌کند.', options: ['درست', 'غلط'], answer: 'غلط'),
    ],
  ),
  GameDefinition(
    id: 'yesno',
    title: 'بله یا خیر',
    icon: '🔘',
    description: 'فقط ۵ ثانیه وقت داری.',
    type: GameType.yesNo,
    energyCost: 2,
    baseReward: 20,
    questions: const [
      GameQuestion(prompt: 'آیا ۵ بزرگ‌تر از ۳ است؟', options: ['بله', 'خیر'], answer: 'بله'),
      GameQuestion(prompt: 'آیا ماه از خودش نور تولید می‌کند؟', options: ['بله', 'خیر'], answer: 'خیر'),
      GameQuestion(prompt: 'آیا زنبور عسل تولید می‌کند؟', options: ['بله', 'خیر'], answer: 'بله'),
      GameQuestion(prompt: 'آیا زمستان گرم‌ترین فصل سال است؟', options: ['بله', 'خیر'], answer: 'خیر'),
    ],
  ),
  GameDefinition(
    id: 'speed',
    title: 'چالش سرعتی',
    icon: '⚡',
    description: 'در زمان کم بیشترین جواب درست را بده.',
    type: GameType.speed,
    energyCost: 5,
    baseReward: 42,
    questions: const [
      GameQuestion(prompt: '۳ + ۴ = ؟', options: ['۵', '۶', '۷', '۸'], answer: '۷'),
      GameQuestion(prompt: '۱۰ - ۶ = ؟', options: ['۲', '۳', '۴', '۵'], answer: '۴'),
      GameQuestion(prompt: '۲ × ۵ = ؟', options: ['۷', '۸', '۱۰', '۱۲'], answer: '۱۰'),
      GameQuestion(prompt: '۱۲ ÷ ۳ = ؟', options: ['۳', '۴', '۵', '۶'], answer: '۴'),
      GameQuestion(prompt: '۸ + ۹ = ؟', options: ['۱۵', '۱۶', '۱۷', '۱۸'], answer: '۱۷'),
      GameQuestion(prompt: '۶ × ۳ = ؟', options: ['۱۲', '۱۵', '۱۸', '۲۱'], answer: '۱۸'),
    ],
  ),
  GameDefinition(
    id: 'memory',
    title: 'حافظه سریع',
    icon: '🧠',
    description: 'ترتیب نمایش را به خاطر بسپار.',
    type: GameType.memory,
    energyCost: 4,
    baseReward: 40,
    questions: const [
      GameQuestion(prompt: 'ترتیب را حفظ کن', visual: '🔴 🟡 🔵', options: ['🔴 🟡 🔵', '🟡 🔵 🔴', '🔵 🔴 🟡', '🔴 🔵 🟡'], answer: '🔴 🟡 🔵'),
      GameQuestion(prompt: 'ترتیب را حفظ کن', visual: '🍎 🍋 🍇', options: ['🍇 🍋 🍎', '🍎 🍋 🍇', '🍋 🍇 🍎', '🍎 🍇 🍋'], answer: '🍎 🍋 🍇'),
      GameQuestion(prompt: 'ترتیب را حفظ کن', visual: '۱ ۳ ۲ ۴', options: ['۱ ۳ ۲ ۴', '۱ ۲ ۳ ۴', '۴ ۲ ۳ ۱', '۳ ۱ ۴ ۲'], answer: '۱ ۳ ۲ ۴'),
      GameQuestion(prompt: 'ترتیب را حفظ کن', visual: '🐱 🐶 🐰', options: ['🐶 🐱 🐰', '🐰 🐶 🐱', '🐱 🐶 🐰', '🐱 🐰 🐶'], answer: '🐱 🐶 🐰'),
    ],
  ),
];

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  AppData data = AppData();
  bool loaded = false;
  int tab = 2;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('chaleshino_state_v1');
    if (raw != null) {
      try {
        data = AppData.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      } catch (_) {
        data = AppData();
      }
    }
    setState(() => loaded = true);
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('chaleshino_state_v1', jsonEncode(data.toJson()));
  }

  void _mutate(void Function() change) {
    setState(change);
    _save();
  }

  Future<GameSessionResult> _completeGame(GameDefinition game, int correct, int wrong) async {
    final league = leagueForXp(data.xp);
    final coins = max(0, (correct * game.baseReward * league.rewardFactor).round() - wrong * 6);
    final xp = max(0, correct * 18 - wrong * 3 + (correct >= 4 ? 20 : 0));
    final record = game.id == 'speed' && correct > data.bestSpeed;
    _mutate(() {
      data.coins += coins;
      data.xp += xp;
      data.totalCorrect += correct;
      data.totalWrong += wrong;
      data.totalGames += 1;
      data.completedRounds += correct + wrong;
      if (record) data.bestSpeed = correct;
      _unlockAchievements();
    });
    return GameSessionResult(correct: correct, wrong: wrong, coins: coins, xp: xp, record: record);
  }

  void _unlockAchievements() {
    void unlock(String id) {
      if (data.achievements.contains(id)) return;
      final def = achievementDefs.firstWhere((a) => a.id == id);
      data.achievements.add(id);
      data.coins += def.coins;
      data.xp += def.xp;
    }

    if (data.totalGames >= 1) unlock('first_win');
    if (data.totalCorrect >= 10) unlock('ten_correct');
    if (data.completedRounds >= 50) unlock('fifty_rounds');
    if (data.xp >= leagues[2].minXp) unlock('gold_league');
    if (data.adsWatched >= 10) unlock('ads_10');
    if (data.streak >= 7) unlock('streak_7');
    if (data.bestSpeed >= 6) unlock('speed_6');
  }

  void _openGame(GameDefinition game) {
    if (data.energy < game.energyCost) {
      _snack('انرژی کافی نیست. از فروشگاه یا جایزه‌ها انرژی بگیر.');
      return;
    }
    void startGame() {
      _mutate(() => data.energy -= game.energyCost);
      _pushGame(game);
    }
    if (data.skipTutorial) {
      startGame();
      return;
    }
    showDialog<void>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Text('${game.icon} ${game.title}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(game.description),
              const SizedBox(height: 12),
              Text('قلب: ۳ | انرژی مصرفی: ${game.energyCost}'),
              Text('پاداش پایه هر جواب درست: ${game.baseReward} سکه'),
              Text('زمان پاسخ: ${_timeLimitFor(game)} ثانیه'),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
            FilledButton(
              onPressed: () {
                Navigator.pop(context);
                startGame();
              },
              child: const Text('شروع'),
            ),
          ],
        ),
      ),
    );
  }

  int _timeLimitFor(GameDefinition game) {
    if (game.type == GameType.yesNo) return 5;
    if (game.type == GameType.speed) return 8;
    if (game.type == GameType.memory) return 10;
    final league = leagueForXp(data.xp);
    if (league.title == 'برنزی') return 20;
    if (league.title == 'نقره‌ای') return 18;
    if (league.title == 'طلایی') return 15;
    return 12;
  }

  void _pushGame(GameDefinition game) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Directionality(
          textDirection: TextDirection.rtl,
          child: GameScreen(
            game: game,
            timeLimit: _timeLimitFor(game),
            hints: data.hints,
            onUseHint: () async {
              if (data.hints <= 0) return false;
              _mutate(() => data.hints -= 1);
              return true;
            },
            onComplete: (correct, wrong) => _completeGame(game, correct, wrong),
          ),
        ),
      ),
    ).then((_) => setState(() {}));
  }

  void _claimDaily() {
    final today = DateTime.now().toIso8601String().substring(0, 10);
    if (data.lastDaily == today) {
      _snack('جایزه امروز قبلاً دریافت شده.');
      return;
    }
    _mutate(() {
      data.streak = data.lastDaily.isEmpty ? 1 : data.streak + 1;
      data.lastDaily = today;
      data.coins += 100 + min(data.streak, 7) * 20;
      data.energy += 10;
      data.hints += data.streak % 3 == 0 ? 1 : 0;
      _unlockAchievements();
    });
    _snack('جایزه روزانه دریافت شد.');
  }

  void _watchRewardAd() {
    MockAdivery.showRewarded().then((rewarded) {
      if (!mounted) return;
      if (rewarded) {
        _mutate(() {
          data.adsWatched += 1;
          data.coins += 150;
          data.energy += 8;
          _unlockAchievements();
        });
        _snack('تبلیغ کامل شد؛ ۱۵۰ سکه و ۸ انرژی گرفتی.');
      } else {
        _snack('تبلیغ کامل دیده نشد.');
      }
    });
  }

  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    if (!loaded) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final pages = [
      ProfilePage(data: data, onChanged: _mutate),
      ShopPage(data: data, onChanged: _mutate, snack: _snack),
      HomePage(data: data, openGame: _openGame, watchAd: _watchRewardAd),
      LeaguePage(data: data),
      RewardsPage(data: data, claimDaily: _claimDaily, watchAd: _watchRewardAd),
    ];
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          const Positioned.fill(child: OriginalBackground()),
          Positioned.fill(child: pages[tab]),
          Align(
            alignment: Alignment.bottomCenter,
            child: OriginalBottomNav(
              currentIndex: tab,
              onTap: (i) => setState(() => tab = i),
            ),
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final AppData data;
  final void Function(GameDefinition game) openGame;
  final VoidCallback watchAd;

  const HomePage({super.key, required this.data, required this.openGame, required this.watchAd});

  @override
  Widget build(BuildContext context) {
    final league = leagueForXp(data.xp);
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 124),
        children: [
          Row(
            children: [
              const Expanded(child: Text('چالشینو', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: AppColors.ink))),
              StatPill(label: 'سکه', value: '${data.coins}', icon: '🪙'),
              const SizedBox(width: 8),
              StatPill(label: 'انرژی', value: '${data.energy}', icon: '⚡'),
            ],
          ),
          const SizedBox(height: 16),
          BigHeroCard(data: data, league: league),
          const SizedBox(height: 14),
          GestureDetector(onTap: watchAd, child: const MockBanner()),
          const SizedBox(height: 18),
          const SectionTitle('بازی‌ها'),
          const SizedBox(height: 8),
          SizedBox(
            height: 192,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: games.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (context, index) => GameCard(game: games[index], onTap: () => openGame(games[index])),
            ),
          ),
          const SizedBox(height: 18),
          const SectionTitle('مسیر امروز'),
          MissionTile(icon: '🎯', title: '۳ بازی انجام بده', subtitle: '${min(data.totalGames, 3)}/3 بازی ثبت شده', progress: min(data.totalGames / 3, 1.0)),
          MissionTile(icon: '🧠', title: '۱۰ جواب درست', subtitle: '${min(data.totalCorrect, 10)}/10 جواب درست', progress: min(data.totalCorrect / 10, 1.0)),
        ],
      ),
    );
  }
}

class BigHeroCard extends StatelessWidget {
  final AppData data;
  final LeagueInfo league;

  const BigHeroCard({super.key, required this.data, required this.league});

  @override
  Widget build(BuildContext context) {
    final progress = ((data.xp - league.minXp) / max(1, league.nextXp - league.minXp)).clamp(0.0, 1.0).toDouble();
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFFFEFCFF), Color(0xFFF2F7FF), Color(0xFFF2ECFF)],
        ),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: const Color(0x236C63FF)),
        boxShadow: originalShadow(),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -42,
            bottom: -52,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [AppColors.primary2.withOpacity(.28), AppColors.primary.withOpacity(.15)]),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFE9F8FF), Color(0xFFD9D2FF)]),
                    border: Border.all(color: const Color(0x296C63FF)),
                    boxShadow: originalShadow(opacity: .12, blur: 24),
                  ),
                  child: Center(child: Text(league.icon, style: const TextStyle(fontSize: 34))),
                ),
                const SizedBox(width: 12),
                Expanded(child: Text('لیگ ${league.title}', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppColors.ink))),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFF0F8FF)]),
                    border: Border.all(color: AppColors.line),
                    boxShadow: originalShadow(opacity: .08, blur: 15),
                  ),
                  child: Text('${data.xp} XP', style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.primary)),
                ),
              ]),
              const SizedBox(height: 16),
              ClipRRect(
                borderRadius: BorderRadius.circular(99),
                child: LinearProgressIndicator(
                  value: progress,
                  minHeight: 12,
                  backgroundColor: const Color(0xFFE6EEFB),
                  color: AppColors.cyan,
                ),
              ),
              const SizedBox(height: 11),
              Text('تا لیگ بعدی: ${max(0, league.nextXp - data.xp)} XP', style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w800)),
            ],
          ),
        ],
      ),
    );
  }
}


class GameCard extends StatelessWidget {
  final GameDefinition game;
  final VoidCallback onTap;

  const GameCard({super.key, required this.game, required this.onTap});

  LinearGradient _gradient(int hash) {
    if (hash % 3 == 0) return const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFFFF8EB)]);
    if (hash % 2 == 0) return const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFF3F1FF)]);
    return const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFF0FBFF)]);
  }

  List<Color> _iconColors(int hash) {
    if (hash % 3 == 0) return const [Color(0xFFFFCF6D), Color(0xFFFF9F43)];
    if (hash % 2 == 0) return const [Color(0xFF8F6CFF), Color(0xFF6C63FF)];
    return const [Color(0xFF22D3B6), Color(0xFF14C8D8)];
  }

  @override
  Widget build(BuildContext context) {
    final hash = game.id.hashCode.abs();
    final colors = _iconColors(hash);
    return SizedBox(
      width: 214,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(30),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: _gradient(hash),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: hash % 3 == 0 ? const Color(0x2BFFB84D) : const Color(0x2114C8D8)),
            boxShadow: originalShadow(),
          ),
          child: Stack(
            children: [
              Positioned(
                left: -42,
                bottom: -52,
                child: Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [colors.first.withOpacity(.22), colors.last.withOpacity(.12)]),
                  ),
                ),
              ),
              Positioned(
                left: 0,
                top: 0,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFF0F8FF)]),
                    border: Border.all(color: AppColors.line),
                  ),
                  child: Text('${game.energyCost} ⚡', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: AppColors.deep)),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: LinearGradient(colors: colors),
                      boxShadow: originalShadow(opacity: .14, blur: 20),
                    ),
                    child: Center(child: Text(game.icon, style: const TextStyle(fontSize: 31))),
                  ),
                  const SizedBox(height: 12),
                  Text(game.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppColors.ink)),
                  const SizedBox(height: 7),
                  Text(game.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.2, height: 1.65, color: AppColors.muted)),
                  const Spacer(),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(value: .35 + (hash % 6) / 10, minHeight: 8, backgroundColor: const Color(0xFFE8F2FB), color: colors.last),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class GameScreen extends StatefulWidget {
  final GameDefinition game;
  final int timeLimit;
  final int hints;
  final Future<bool> Function() onUseHint;
  final Future<GameSessionResult> Function(int correct, int wrong) onComplete;

  const GameScreen({super.key, required this.game, required this.timeLimit, required this.hints, required this.onUseHint, required this.onComplete});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  Timer? timer;
  int seconds = 0;
  int index = 0;
  int hearts = 3;
  int correct = 0;
  int wrong = 0;
  String wordInput = '';
  bool memoryPreview = false;
  bool finishing = false;
  String hintText = '';
  late List<GameQuestion> rounds;

  @override
  void initState() {
    super.initState();
    rounds = List<GameQuestion>.from(widget.game.questions)..shuffle(Random());
    if (widget.game.type == GameType.speed) rounds = [...rounds, ...rounds]..shuffle(Random());
    _setupRound();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  GameQuestion get q => rounds[index % rounds.length];

  void _setupRound() {
    timer?.cancel();
    wordInput = '';
    hintText = '';
    seconds = widget.timeLimit;
    if (widget.game.type == GameType.memory) {
      memoryPreview = true;
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted && !finishing) setState(() => memoryPreview = false);
      });
    } else {
      memoryPreview = false;
    }
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || finishing) return;
      setState(() => seconds--);
      if (seconds <= 0) _timeout();
    });
    setState(() {});
  }

  void _timeout() {
    timer?.cancel();
    wrong += 1;
    hearts -= 1;
    if (hearts <= 0) {
      _finish();
    } else {
      _next();
    }
  }

  void _answer(String value) {
    if (memoryPreview || finishing) return;
    timer?.cancel();
    if (value.trim() == q.answer.trim()) {
      correct += 1;
    } else {
      wrong += 1;
      hearts -= 1;
    }
    if (hearts <= 0) {
      _finish();
    } else {
      _next();
    }
  }

  void _next() {
    if (index >= 7) {
      _finish();
      return;
    }
    index += 1;
    _setupRound();
  }

  Future<void> _finish() async {
    if (finishing) return;
    finishing = true;
    timer?.cancel();
    final result = await widget.onComplete(correct, wrong);
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => Directionality(
          textDirection: TextDirection.rtl,
          child: ResultScreen(game: widget.game, result: result),
        ),
      ),
    );
  }

  Future<void> _showHint() async {
    final ok = await widget.onUseHint();
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('راهنما نداری.')));
      return;
    }
    setState(() => hintText = q.hint.isNotEmpty ? q.hint : 'جواب درست: ${q.answer}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 32),
          children: [
            Row(
              children: [
                IconButton.filledTonal(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
                const SizedBox(width: 8),
                Expanded(child: Text('${widget.game.icon} ${widget.game.title}', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppColors.ink))),
                StatPill(label: 'قلب', value: List.filled(hearts, '❤').join(), icon: ''),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28), border: Border.all(color: const Color(0xFFEFE3CE))),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(child: LinearProgressIndicator(value: seconds / widget.timeLimit, minHeight: 10, borderRadius: BorderRadius.circular(99), color: seconds <= 5 ? AppColors.danger : AppColors.success)),
                      const SizedBox(width: 12),
                      Text('$seconds ثانیه', style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.ink)),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Text('مرحله ${index + 1} از ۸', style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 12),
                  if (q.visual.isNotEmpty) Text(q.visual, textAlign: TextAlign.center, style: const TextStyle(fontSize: 45)),
                  const SizedBox(height: 8),
                  Text(q.prompt, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, height: 1.55, fontWeight: FontWeight.w900, color: AppColors.ink)),
                  if (hintText.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: const Color(0xFFFFF4D7), borderRadius: BorderRadius.circular(18)),
                      child: Text('راهنما: $hintText', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.ink)),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (widget.game.type == GameType.word) _buildWordInput() else _buildChoiceInput(),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: OutlinedButton.icon(onPressed: _showHint, icon: const Icon(Icons.lightbulb_rounded), label: const Text('راهنما'))),
                const SizedBox(width: 10),
                Expanded(child: OutlinedButton.icon(onPressed: _setupRound, icon: const Icon(Icons.refresh_rounded), label: const Text('شروع دوباره'))),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChoiceInput() {
    if (widget.game.type == GameType.memory && memoryPreview) {
      return Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: const Color(0xFFFFF4D7), borderRadius: BorderRadius.circular(24)),
        child: Column(
          children: [
            const Text('به خاطر بسپار...', style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.ink)),
            const SizedBox(height: 12),
            Text(q.visual, style: const TextStyle(fontSize: 36)),
          ],
        ),
      );
    }
    return GridView.count(
      crossAxisCount: 2,
      childAspectRatio: 2.6,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      children: q.options.map((option) => AnswerButton(text: option, onTap: () => _answer(option))).toList(),
    );
  }

  Widget _buildWordInput() {
    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
          child: Text(wordInput.isEmpty ? 'حروف را انتخاب کن' : wordInput, textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: AppColors.ink)),
        ),
        const SizedBox(height: 12),
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 8,
          runSpacing: 8,
          children: q.letters.map((letter) => FilledButton.tonal(onPressed: () => setState(() => wordInput += letter), child: Text(letter, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)))).toList(),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: OutlinedButton(onPressed: () => setState(() => wordInput = ''), child: const Text('پاک کردن'))),
            const SizedBox(width: 10),
            Expanded(child: FilledButton(onPressed: () => _answer(wordInput), child: const Text('ثبت جواب'))),
          ],
        ),
      ],
    );
  }
}

class ResultScreen extends StatelessWidget {
  final GameDefinition game;
  final GameSessionResult result;

  const ResultScreen({super.key, required this.game, required this.result});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 22, 18, 34),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFFFF2D4)]),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Column(
                children: [
                  const Text('🏁', style: TextStyle(fontSize: 56)),
                  const SizedBox(height: 8),
                  Text('نتیجه ${game.title}', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: AppColors.ink)),
                  if (result.record) const Padding(padding: EdgeInsets.only(top: 8), child: Text('رکورد جدید ثبت شد ⚡', style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.success))),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(child: ResultBox(label: 'درست', value: '${result.correct}', color: AppColors.success)),
                      const SizedBox(width: 10),
                      Expanded(child: ResultBox(label: 'غلط', value: '${result.wrong}', color: AppColors.danger)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(child: ResultBox(label: 'سکه', value: '${result.coins}', color: AppColors.primaryDark)),
                      const SizedBox(width: 10),
                      Expanded(child: ResultBox(label: 'XP', value: '${result.xp}', color: AppColors.accent)),
                    ],
                  ),
                  const SizedBox(height: 22),
                  FilledButton.icon(
                    onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                    icon: const Icon(Icons.home_rounded),
                    label: const Text('بازگشت به خانه'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ResultBox extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const ResultBox({super.key, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [Colors.white, color.withOpacity(.10)]),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: color.withOpacity(.18)),
        boxShadow: originalShadow(opacity: .08, blur: 16),
      ),
      child: Column(children: [
        Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: color)),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.muted)),
      ]),
    );
  }
}


class RewardsPage extends StatelessWidget {
  final AppData data;
  final VoidCallback claimDaily;
  final VoidCallback watchAd;

  const RewardsPage({super.key, required this.data, required this.claimDaily, required this.watchAd});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 124),
        children: [
          const PageHeader(title: 'جایزه‌ها', subtitle: 'پاداش روزانه، مأموریت و تبلیغ جایزه‌دار'),
          const SizedBox(height: 16),
          ActionCard(icon: '🎁', title: 'جایزه روزانه', subtitle: 'زنجیره فعلی: ${data.streak} روز', button: 'دریافت', onTap: claimDaily),
          const SizedBox(height: 12),
          ActionCard(icon: '🎬', title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه + ۸ انرژی', button: 'تماشا', onTap: watchAd),
          const SizedBox(height: 18),
          const SectionTitle('مأموریت‌ها'),
          MissionTile(icon: '🎮', title: 'امروز بازی کن', subtitle: '${data.totalGames} بازی انجام‌شده', progress: min(data.totalGames / 3, 1.0)),
          MissionTile(icon: '✅', title: 'جواب درست جمع کن', subtitle: '${data.totalCorrect} جواب درست', progress: min(data.totalCorrect / 10, 1.0)),
          MissionTile(icon: '⚡', title: 'رکورد سرعتی', subtitle: 'بهترین رکورد: ${data.bestSpeed}', progress: min(data.bestSpeed / 6, 1.0)),
        ],
      ),
    );
  }
}

class ShopPage extends StatelessWidget {
  final AppData data;
  final void Function(void Function() change) onChanged;
  final void Function(String message) snack;

  const ShopPage({super.key, required this.data, required this.onChanged, required this.snack});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 130),
        children: [
          const PageHeader(title: 'فروشگاه', subtitle: 'بسته‌های تستی برای نسخه آفلاین'),
          const SizedBox(height: 12),
          SizedBox(
            height: 156,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                ShopItem(icon: '🪙', title: 'بسته سکه', subtitle: '+۵۰۰ سکه', onTap: () => onChanged(() => data.coins += 500)),
                ShopItem(icon: '⚡', title: 'بسته انرژی', subtitle: '+۳۰ انرژی', onTap: () => onChanged(() => data.energy += 30)),
                ShopItem(icon: '💡', title: 'بسته راهنما', subtitle: '+۵ راهنما', onTap: () => onChanged(() => data.hints += 5)),
                ShopItem(icon: '💎', title: 'بسته ویژه', subtitle: '+۱۰۰۰ سکه + انرژی', onTap: () => onChanged(() { data.coins += 1000; data.energy += 50; data.hints += 4; })),
              ],
            ),
          ),
          const SizedBox(height: 18),
          ActionCard(icon: '🧪', title: 'خرید تستی', subtitle: 'در نسخه Flutter نهایی به پرداخت مارکت وصل می‌شود.', button: 'فعال است', onTap: () => snack('خرید تستی داخل نسخه آفلاین فعال است.')),
          const SizedBox(height: 12),
          const MockBanner(),
        ],
      ),
    );
  }
}

class LeaguePage extends StatelessWidget {
  final AppData data;

  const LeaguePage({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final current = leagueForXp(data.xp);
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 124),
        children: [
          const PageHeader(title: 'لیگ فعلی تو', subtitle: 'سختی و پاداش بازی‌ها با لیگ بالاتر بیشتر می‌شود'),
          const SizedBox(height: 16),
          BigHeroCard(data: data, league: current),
          const SizedBox(height: 18),
          const SectionTitle('مسیر لیگ‌ها'),
          ...leagues.map((league) => LeagueTile(league: league, active: league.title == current.title)),
        ],
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  final AppData data;
  final void Function(void Function() change) onChanged;

  const ProfilePage({super.key, required this.data, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final league = leagueForXp(data.xp);
    final totalAnswers = data.totalCorrect + data.totalWrong;
    final successRate = totalAnswers == 0 ? 0 : (data.totalCorrect * 100 / totalAnswers).round();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 130),
        children: [
          const PageHeader(title: 'پروفایل', subtitle: 'آمار، تنظیمات و دستاوردها'),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
            child: Row(
              children: [
                const CircleAvatar(radius: 34, backgroundColor: Color(0xFFFFE6B0), child: Text('چ', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: AppColors.primaryDark))),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('بازیکن چالشینو', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AppColors.ink)),
                  Text('${league.icon} لیگ ${league.title}', style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w800)),
                ])),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: ResultBox(label: 'موفقیت', value: '$successRate٪', color: AppColors.success)),
            const SizedBox(width: 10),
            Expanded(child: ResultBox(label: 'رکورد سرعتی', value: '${data.bestSpeed}', color: AppColors.accent)),
          ]),
          const SizedBox(height: 18),
          const SectionTitle('تنظیمات'),
          SwitchListTile(
            value: data.sound,
            onChanged: (v) => onChanged(() => data.sound = v),
            title: const Text('صدا'),
            secondary: const Icon(Icons.volume_up_rounded),
          ),
          SwitchListTile(
            value: data.vibration,
            onChanged: (v) => onChanged(() => data.vibration = v),
            title: const Text('لرزش'),
            secondary: const Icon(Icons.vibration_rounded),
          ),
          SwitchListTile(
            value: data.skipTutorial,
            onChanged: (v) => onChanged(() => data.skipTutorial = v),
            title: const Text('رد کردن آموزش سریع'),
            secondary: const Icon(Icons.school_rounded),
          ),
          const SizedBox(height: 12),
          const SectionTitle('دستاوردها'),
          ...achievementDefs.map((def) => AchievementTile(def: def, unlocked: data.achievements.contains(def.id))),
        ],
      ),
    );
  }
}

class MockAdivery {
  static Future<bool> showRewarded() async {
    await Future<void>.delayed(const Duration(milliseconds: 700));
    return true;
  }
}

class MockBanner extends StatelessWidget {
  const MockBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 74),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.centerRight, end: Alignment.centerLeft, colors: [Color(0xFF243052), Color(0xFF6258F2)]),
        borderRadius: BorderRadius.circular(28),
        boxShadow: originalShadow(opacity: .16, blur: 28),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: const LinearGradient(colors: [Color(0xFFFFCF6D), Color(0xFFFF9F43)]),
              boxShadow: originalShadow(opacity: .10, blur: 18),
            ),
            child: const Center(child: Text('🎬', style: TextStyle(fontSize: 28))),
          ),
          const SizedBox(width: 12),
          const Expanded(child: Text('جایگاه تبلیغ Adivery آماده اتصال', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15))),
          const Icon(Icons.chevron_left_rounded, color: Colors.white, size: 28),
        ],
      ),
    );
  }
}



class OriginalBackground extends StatelessWidget {
  const OriginalBackground({super.key});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFE4EBF7), Color(0xFFF1F6FF), Color(0xFFE7E1FF)],
        ),
      ),
      child: Stack(
        children: [
          Positioned(top: -80, right: -70, child: _Glow(color: AppColors.primary, size: 220, opacity: .20)),
          Positioned(top: 40, left: -75, child: _Glow(color: AppColors.cyan, size: 220, opacity: .20)),
          Positioned(bottom: -100, right: 80, child: _Glow(color: AppColors.primary2, size: 260, opacity: .18)),
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),
        ],
      ),
    );
  }
}

class _Glow extends StatelessWidget {
  final Color color;
  final double size;
  final double opacity;
  const _Glow({required this.color, required this.size, required this.opacity});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(opacity)),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint1 = Paint()..color = AppColors.primary.withOpacity(.045)..strokeWidth = 1;
    final paint2 = Paint()..color = AppColors.cyan.withOpacity(.045)..strokeWidth = 1;
    const step = 34.0;
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint1);
    }
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint2);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class OriginalBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const OriginalBottomNav({super.key, required this.currentIndex, required this.onTap});

  static const items = [
    (Icons.person_rounded, 'پروفایل'),
    (Icons.storefront_rounded, 'فروشگاه'),
    (Icons.home_rounded, 'خانه'),
    (Icons.emoji_events_rounded, 'لیگ'),
    (Icons.card_giftcard_rounded, 'جایزه‌ها'),
  ];

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).padding.bottom;
    return Container(
      padding: EdgeInsets.fromLTRB(12, 12, 12, 13 + bottom),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [const Color(0x00E8F0FA), const Color(0xF2EFF6FF), Colors.white.withOpacity(.99)],
          stops: const [.0, .30, 1],
        ),
        boxShadow: [BoxShadow(color: const Color(0xFF4C56AA).withOpacity(.10), blurRadius: 26, offset: const Offset(0, -12))],
      ),
      child: Row(
        textDirection: TextDirection.ltr,
        children: List.generate(items.length, (i) {
          final item = items[i];
          final active = currentIndex == i;
          final isHome = i == 2;
          return Expanded(
            child: GestureDetector(
              onTap: () => onTap(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                height: isHome ? 70 : 58,
                margin: EdgeInsets.only(top: isHome ? 0 : 12, left: 4, right: 4, bottom: isHome ? 0 : 0),
                transform: Matrix4.translationValues(0, active ? (isHome ? -9 : -3) : (isHome ? -6 : 0), 0),
                decoration: BoxDecoration(
                  gradient: isHome
                      ? const LinearGradient(colors: [Color(0xFF20D9C2), Color(0xFF6C63FF), Color(0xFFFFB84D)])
                      : active
                          ? const LinearGradient(colors: [Color(0xFF7F78FF), Color(0xFF6258F2)])
                          : const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFEFFBFF)]),
                  borderRadius: BorderRadius.circular(isHome ? 28 : 18),
                  border: Border.all(color: isHome ? Colors.white.withOpacity(.64) : AppColors.line),
                  boxShadow: [
                    BoxShadow(color: (isHome ? AppColors.primary : AppColors.primary).withOpacity(active || isHome ? .25 : .10), blurRadius: isHome ? 30 : 16, offset: Offset(0, isHome ? 16 : 9)),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(item.$1, color: active || isHome ? Colors.white : AppColors.muted, size: isHome ? 30 : 24),
                    const SizedBox(height: 3),
                    Text(item.$2, style: TextStyle(fontSize: isHome ? 11 : 10, fontWeight: FontWeight.w900, color: active || isHome ? Colors.white : AppColors.muted)),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class StatPill extends StatelessWidget {
  final String label;
  final String value;
  final String icon;

  const StatPill({super.key, required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFEFFBFF)]),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.line),
        boxShadow: originalShadow(opacity: .11, blur: 18),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon.isNotEmpty) Text(icon, style: const TextStyle(fontSize: 16)),
          if (icon.isNotEmpty) const SizedBox(width: 5),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.ink, fontSize: 13)),
        ],
      ),
    );
  }
}


class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle(this.title, {super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.ink)),
        const Spacer(),
        Container(width: 36, height: 5, decoration: BoxDecoration(borderRadius: BorderRadius.circular(99), gradient: const LinearGradient(colors: [AppColors.cyan, AppColors.primary]))),
      ],
    );
  }
}


class PageHeader extends StatelessWidget {
  final String title;
  final String subtitle;

  const PageHeader({super.key, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFF4FBFF)]),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppColors.line),
        boxShadow: originalShadow(opacity: .12, blur: 26),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: AppColors.ink)),
        const SizedBox(height: 7),
        Text(subtitle, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w700, height: 1.7)),
      ]),
    );
  }
}


class MissionTile extends StatelessWidget {
  final String icon;
  final String title;
  final String subtitle;
  final double progress;

  const MissionTile({super.key, required this.icon, required this.title, required this.subtitle, required this.progress});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 13),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFF4FBFF)]),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppColors.line),
        boxShadow: originalShadow(opacity: .12, blur: 25),
      ),
      child: Row(children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), gradient: const LinearGradient(colors: [AppColors.cyan, AppColors.success])),
          child: Center(child: Text(icon, style: const TextStyle(fontSize: 27))),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.ink, fontSize: 16)),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: progress, minHeight: 9, borderRadius: BorderRadius.circular(99), color: AppColors.success, backgroundColor: const Color(0xFFE6EEF7)),
          const SizedBox(height: 6),
          Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 12, fontWeight: FontWeight.w700)),
        ])),
      ]),
    );
  }
}


class AnswerButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;

  const AnswerButton({super.key, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFEAF7FF), Color(0xFFF2EEFF)]),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0x296C63FF)),
            boxShadow: originalShadow(opacity: .11, blur: 18),
          ),
          child: Center(child: Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w900, color: AppColors.deep))),
        ),
      ),
    );
  }
}


class ActionCard extends StatelessWidget {
  final String icon;
  final String title;
  final String subtitle;
  final String button;
  final VoidCallback onTap;

  const ActionCard({super.key, required this.icon, required this.title, required this.subtitle, required this.button, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFF4FBFF)]),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppColors.line),
        boxShadow: originalShadow(opacity: .12, blur: 26),
      ),
      child: Row(children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), gradient: const LinearGradient(colors: [AppColors.primary2, AppColors.danger])),
          child: Center(child: Text(icon, style: const TextStyle(fontSize: 30))),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppColors.ink)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w700, height: 1.55)),
        ])),
        FilledButton(
          onPressed: onTap,
          style: FilledButton.styleFrom(backgroundColor: AppColors.success, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17))),
          child: Text(button, style: const TextStyle(fontWeight: FontWeight.w900)),
        ),
      ]),
    );
  }
}


class ShopItem extends StatelessWidget {
  final String icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const ShopItem({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 142,
      margin: const EdgeInsets.only(left: 12),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFF0FBFF)]),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.line),
        boxShadow: originalShadow(opacity: .12, blur: 23),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [AppColors.primary2, AppColors.danger])),
          child: Center(child: Text(icon, style: const TextStyle(fontSize: 28))),
        ),
        const Spacer(),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.ink)),
        const SizedBox(height: 3),
        Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: onTap, style: FilledButton.styleFrom(backgroundColor: AppColors.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), child: const Text('گرفتن'))),
      ]),
    );
  }
}


class LeagueTile extends StatelessWidget {
  final LeagueInfo league;
  final bool active;

  const LeagueTile({super.key, required this.league, required this.active});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: active ? const LinearGradient(colors: [Color(0xFFFFF9E8), Color(0xFFFFFFFF)]) : const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFF4FBFF)]),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: active ? AppColors.primary2 : AppColors.line, width: active ? 1.5 : 1),
        boxShadow: originalShadow(opacity: active ? .15 : .10, blur: 22),
      ),
      child: Row(children: [
        Container(width: 48, height: 48, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFE9F8FF), Color(0xFFD9D2FF)])), child: Center(child: Text(league.icon, style: const TextStyle(fontSize: 29)))),
        const SizedBox(width: 12),
        Expanded(child: Text(league.title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.ink))),
        Text('${league.minXp} XP', style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w800)),
      ]),
    );
  }
}


class AchievementTile extends StatelessWidget {
  final AchievementDef def;
  final bool unlocked;

  const AchievementTile({super.key, required this.def, required this.unlocked});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFFFFF), Color(0xFFF4FBFF)]),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.line),
        boxShadow: originalShadow(opacity: .10, blur: 20),
      ),
      child: Row(children: [
        Container(width: 48, height: 48, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: unlocked ? const LinearGradient(colors: [AppColors.primary2, AppColors.primary]) : const LinearGradient(colors: [Color(0xFFE6EEF7), Color(0xFFFFFFFF)])), child: Center(child: Text(unlocked ? def.icon : '🔒', style: const TextStyle(fontSize: 27)))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(def.title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.ink)),
          Text(def.description, style: const TextStyle(color: AppColors.muted, fontSize: 12, height: 1.6)),
        ])),
        Text(unlocked ? 'گرفته شد' : '+${def.coins}', style: TextStyle(color: unlocked ? AppColors.success : AppColors.primaryDark, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

