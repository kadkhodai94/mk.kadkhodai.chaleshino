import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ChaleshinoApp());
}

class AppColor {
  static const bg = Color(0xFFEAF0FA);
  static const paper = Color(0xFFFFFCF8);
  static const ink = Color(0xFF14223A);
  static const muted = Color(0xFF60718D);
  static const primary = Color(0xFF675CFF);
  static const violet = Color(0xFF9C5BFF);
  static const cyan = Color(0xFF08C7D8);
  static const green = Color(0xFF17C69B);
  static const orange = Color(0xFFFFB345);
  static const danger = Color(0xFFFF5575);
  static const navy = Color(0xFF243766);
  static const gold = Color(0xFFFFD36A);
  static const glass = Color(0xFFF9FCFF);
}

List<BoxShadow> htmlShadow({double opacity = .18, double blur = 34, Offset offset = const Offset(0, 18)}) => [
      BoxShadow(color: const Color(0xFF263966).withOpacity(opacity * .62), blurRadius: blur * 1.18, spreadRadius: -8, offset: Offset(0, offset.dy + 8)),
      BoxShadow(color: const Color(0xFF6276BD).withOpacity(opacity * .34), blurRadius: blur * .65, spreadRadius: -12, offset: const Offset(0, 9)),
      BoxShadow(color: Colors.white.withOpacity(.88), blurRadius: 0, offset: const Offset(0, 1)),
    ];

BoxDecoration htmlCard({
  List<Color> colors = const [Color(0xFFFFFFFF), Color(0xFFF9FCFF), Color(0xFFF1F6FF)],
  double radius = 30,
  Color? border,
  double shadowOpacity = .18,
}) {
  return BoxDecoration(
    gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors, stops: colors.length == 3 ? const [0, .48, 1] : null),
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: border ?? const Color(0xFFFFFFFF).withOpacity(.72), width: 1.15),
    boxShadow: htmlShadow(opacity: shadowOpacity),
  );
}

class ChaleshinoApp extends StatelessWidget {
  const ChaleshinoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'چالشینو',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Tahoma',
        scaffoldBackgroundColor: AppColor.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColor.primary),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: ChaleshinoRoot()),
    );
  }
}


class GameLevel {
  final String q;
  final List<String> options;
  final int answer;
  final String hint;
  final String difficulty;
  final String? word;
  final List<String> letters;
  final List<String> items;

  const GameLevel({
    required this.q,
    this.options = const [],
    this.answer = 0,
    this.hint = 'با دقت گزینه‌ها را مقایسه کن.',
    this.difficulty = 'easy',
    this.word,
    this.letters = const [],
    this.items = const [],
  });
}

class GameDef {
  final String id;
  final String title;
  final String description;
  final String icon;
  final int energy;
  final Color c1;
  final Color c2;
  final String mode;
  final List<GameLevel> levels;

  const GameDef(this.id, this.title, this.description, this.icon, this.energy, this.c1, this.c2, this.mode, this.levels);
}

const games = <GameDef>[
  GameDef('riddle', 'چیستان', 'چیستان‌های کوتاه روزانه با تایمر و قلب.', 'riddle', 3, Color(0xFFFFCF6D), Color(0xFFFF9F43), 'choice', [
    GameLevel(q: 'چیزی که هرچه بیشتر برداری، بزرگ‌تر می‌شود؟', options: ['چاله', 'درخت', 'دفتر', 'سایه'], answer: 0, hint: 'وقتی از زمین برمی‌داری، عمقش بیشتر می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'کدام ماه ۲۸ روز دارد؟', options: ['همه ماه‌ها', 'اسفند', 'بهمن', 'فقط فوریه'], answer: 0, hint: 'همه ماه‌ها حداقل ۲۸ روز دارند.', difficulty: 'easy'),
    GameLevel(q: 'چیزی که باز می‌شود اما در نیست؟', options: ['چتر', 'پنجره', 'کتاب', 'قفل'], answer: 0, hint: 'در باران استفاده می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'همیشه همراه توست اما گاهی جلو یا عقب می‌افتد؟', options: ['سایه', 'کیف', 'ساعت', 'صدا'], answer: 0, hint: 'با نور دیده می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'بی‌صداست اما خبر می‌دهد؛ چیست؟', options: ['چراغ', 'کتاب', 'باد', 'آینه'], answer: 0, hint: 'با روشن و خاموش شدن پیام می‌دهد.', difficulty: 'easy'),
    GameLevel(q: 'چه چیزی با سکوت قوی‌تر می‌شود؟', options: ['راز', 'باد', 'باران', 'کتاب'], answer: 0, hint: 'اگر گفته نشود می‌ماند.', difficulty: 'easy'),
    GameLevel(q: 'نه پا دارد نه دست، اما راه می‌رود؛ چیست؟', options: ['ساعت', 'کفش', 'صندلی', 'درخت'], answer: 0, hint: 'عقربه‌هایش حرکت می‌کنند.', difficulty: 'easy'),
    GameLevel(q: 'چه چیزی پر دارد ولی پرواز نمی‌کند؟', options: ['بالش', 'پرنده', 'هواپیما', 'بادکنک'], answer: 0, hint: 'برای خواب است.', difficulty: 'easy'),
    GameLevel(q: 'چه چیزی می‌شکند اما صدا ندارد؟', options: ['قول', 'شیشه', 'سنگ', 'چوب'], answer: 0, hint: 'قول می‌تواند شکسته شود.', difficulty: 'easy'),
    GameLevel(q: 'کدام چیز را هرچه خشک‌تر کنی خیس‌تر می‌شود؟', options: ['حوله', 'آفتاب', 'دفتر', 'سکه'], answer: 0, hint: 'حوله هنگام خشک‌کردن خیس می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'خانه‌ای که در ندارد چیست؟', options: ['تخم‌مرغ', 'اتاق', 'کمد', 'قفس'], answer: 0, hint: 'پوسته دارد نه در.', difficulty: 'easy'),
    GameLevel(q: 'چه چیزی دندان دارد ولی غذا نمی‌خورد؟', options: ['شانه', 'گربه', 'ماهی', 'قاشق'], answer: 0, hint: 'شانه دندانه دارد.', difficulty: 'easy'),
    GameLevel(q: 'چه چیزی زبان دارد ولی حرف نمی‌زند؟', options: ['کفش', 'انسان', 'رادیو', 'کتاب'], answer: 0, hint: 'کفش زبانه دارد.', difficulty: 'easy'),
    GameLevel(q: 'چه چیزی چشم دارد ولی نمی‌بیند؟', options: ['سوزن', 'گربه', 'دوربین', 'چراغ'], answer: 0, hint: 'سوزن سوراخی به نام چشم دارد.', difficulty: 'easy'),
    GameLevel(q: 'کدام چیز هرچه جلوتر می‌رود کوتاه‌تر می‌شود؟', options: ['شمع', 'جاده', 'قطار', 'رود'], answer: 0, hint: 'شمع با سوختن کوتاه می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'چه چیزی بالا می‌رود ولی پایین نمی‌آید؟', options: ['سن', 'توپ', 'بادکنک', 'دود'], answer: 0, hint: 'سن فقط زیاد می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'چه چیزی همیشه می‌آید اما نمی‌رسد؟', options: ['فردا', 'امروز', 'دیروز', 'صبح'], answer: 0, hint: 'فردا همیشه روز بعد است.', difficulty: 'easy'),
    GameLevel(q: 'کدام چیز بدون بال پرواز می‌کند؟', options: ['زمان', 'سنگ', 'دفتر', 'قلم'], answer: 0, hint: 'زمان می‌گذرد.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی بدون دهان جواب می‌دهد؟', options: ['اکو', 'رادیو', 'کتاب', 'تلفن'], answer: 0, hint: 'اکو صدای تو را برمی‌گرداند.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی هرچه بیشتر داشته باشی کمتر می‌بینی؟', options: ['تاریکی', 'نور', 'آینه', 'پنجره'], answer: 0, hint: 'تاریکی دید را کم می‌کند.', difficulty: 'medium'),
    GameLevel(q: 'کدام چیز با پا می‌آید اما پا ندارد؟', options: ['صدا', 'باد', 'سایه', 'باران'], answer: 0, hint: 'صدای پا شنیده می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی در آب می‌افتد اما خیس نمی‌شود؟', options: ['سایه', 'کاغذ', 'سنگ', 'لباس'], answer: 0, hint: 'سایه خیس نمی‌شود.', difficulty: 'medium'),
    GameLevel(q: 'کدام چیز سر دارد اما فکر نمی‌کند؟', options: ['میخ', 'انسان', 'گربه', 'ماهی'], answer: 0, hint: 'میخ سر دارد.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی گرد است اما توپ نیست و زمان را نشان می‌دهد؟', options: ['ساعت', 'ماه', 'بشقاب', 'سکه'], answer: 0, hint: 'ساعت گرد زمان را نشان می‌دهد.', difficulty: 'medium'),
    GameLevel(q: 'کدام راه را نمی‌شود رفت؟', options: ['راه‌حل', 'جاده', 'کوچه', 'پل'], answer: 0, hint: 'راه‌حل مسیر واقعی نیست.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی دو دست دارد اما چیزی نمی‌گیرد؟', options: ['ساعت', 'آدمک', 'صندلی', 'درخت'], answer: 0, hint: 'ساعت عقربه دارد.', difficulty: 'medium'),
    GameLevel(q: 'کدام نامه را پست نمی‌کنند؟', options: ['حرف', 'پاکت', 'کارت', 'بسته'], answer: 0, hint: 'حرف هم نامه/حرف است.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی بدون پا از کوه پایین می‌آید؟', options: ['آب', 'انسان', 'بز', 'ماشین'], answer: 0, hint: 'آب جاری می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی هرچه بیشتر بخوری بیشتر جا می‌خواهد؟', options: ['اشتها', 'نان', 'آب', 'برنج'], answer: 0, hint: 'اشتها بیشتر می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'کدام چیز را با چشم می‌خوری؟', options: ['منظره', 'غذا', 'سیب', 'نان'], answer: 0, hint: 'منظره را می‌بینی.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی با شکستن مفیدتر می‌شود؟', options: ['تخم‌مرغ', 'شیشه', 'قفل', 'سنگ'], answer: 0, hint: 'تخم‌مرغ برای پخت شکسته می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی در روز ناپیدا و شب پیداست؟', options: ['ستاره', 'درخت', 'خانه', 'رود'], answer: 0, hint: 'ستاره‌ها شب دیده می‌شوند.', difficulty: 'medium'),
    GameLevel(q: 'کدام پرنده نمی‌پرد؟', options: ['پنگوئن', 'گنجشک', 'کبوتر', 'عقاب'], answer: 0, hint: 'پنگوئن پرواز نمی‌کند.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی بدون حرکت همه جا می‌رود؟', options: ['خبر', 'سنگ', 'صندلی', 'درخت'], answer: 0, hint: 'خبر پخش می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'کدام چیز هرچه خالی‌تر باشد سبک‌تر نیست؟', options: ['بادکنک', 'کیف', 'لیوان', 'جعبه'], answer: 0, hint: 'بادکنک خالی سبک است ولی این سؤال دام است؛ بادکنک پر از هوا هم سبک می‌ماند.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی با نوشتن کم می‌شود؟', options: ['جوهر', 'دفتر', 'مداد', 'کاغذ'], answer: 0, hint: 'جوهر مصرف می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'کدام چیز را قبل از استفاده می‌شکنی؟', options: ['تخم‌مرغ', 'قاشق', 'لیوان', 'کفش'], answer: 0, hint: 'برای پخت معمولاً شکسته می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی در جیب جا می‌شود اما وزن ندارد؟', options: ['سایه', 'سکه', 'کلید', 'گوشی'], answer: 0, hint: 'سایه وزن ندارد.', difficulty: 'hard'),
    GameLevel(q: 'کدام چیز هرچه بیشتر بدوی، بیشتر عقب می‌ماند؟', options: ['نفس', 'کفش', 'ساعت', 'کیف'], answer: 0, hint: 'نفس کم می‌آوری.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی در هواست ولی دیده نمی‌شود؟', options: ['اکسیژن', 'پرنده', 'ابر', 'بادبادک'], answer: 0, hint: 'هوای اطراف دیده نمی‌شود.', difficulty: 'hard'),
    GameLevel(q: 'کدام چیز با چشم بسته هم دیده می‌شود؟', options: ['خواب', 'کتاب', 'چراغ', 'تصویر'], answer: 0, hint: 'خواب در ذهن دیده می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی همیشه راست می‌گوید اما حرف نمی‌زند؟', options: ['آینه', 'رادیو', 'دفتر', 'نقشه'], answer: 0, hint: 'آینه همان را نشان می‌دهد.', difficulty: 'hard'),
    GameLevel(q: 'کدام چیز با اضافه‌کردن حرف، کوچک‌تر می‌شود؟', options: ['کم', 'زیاد', 'بزرگ', 'دور'], answer: 0, hint: 'این سؤال زبانی است؛ کم با مفهوم کوچکی همراه است.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی پر از سوراخ است اما آب نگه می‌دارد؟', options: ['اسفنج', 'سبد', 'تور', 'پنجره'], answer: 0, hint: 'اسفنج آب جذب می‌کند.', difficulty: 'hard'),
    GameLevel(q: 'کدام چیز بالا دارد ولی پایین ندارد؟', options: ['عدد صفر', 'نردبان', 'کوه', 'درخت'], answer: 0, hint: 'معمای لفظی است.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی در ابتدا سخت و در پایان شیرین است؟', options: ['تمرین', 'سنگ', 'یخ', 'نمک'], answer: 0, hint: 'تمرین با نتیجه شیرین می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'کدام چیز می‌دود اما نفس نمی‌کشد؟', options: ['رود', 'اسب', 'انسان', 'گربه'], answer: 0, hint: 'رود جاری است.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی همه را دنبال می‌کند ولی گم نمی‌شود؟', options: ['سایه', 'سگ', 'صدای پا', 'باد'], answer: 0, hint: 'سایه همراه است.', difficulty: 'hard'),
    GameLevel(q: 'کدام چیز با دیدن روشن‌تر می‌شود؟', options: ['ذهن', 'لامپ', 'آتش', 'چراغ'], answer: 0, hint: 'فهم و ذهن روشن می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی اول سفید است، بعد سیاه می‌شود و باز هم مفید است؟', options: ['تخته', 'کاغذ', 'دیوار', 'ابر'], answer: 0, hint: 'تخته با نوشتن سیاه می‌شود.', difficulty: 'hard'),
  ]),
  GameDef('word', 'حدس کلمه', 'کلمه را از حروف به‌هم‌ریخته بساز.', 'word', 4, Color(0xFF14C8D8), Color(0xFF6C63FF), 'word', [
    GameLevel(q: 'این حروف را مرتب کن:', word: 'امتیاز', letters: ['م', 'ا', 'ی', 'ز', 'ت', 'ا'], hint: 'عدد پیشرفت در بازی', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'رقابت', letters: ['ب', 'ت', 'ا', 'ق', 'ر'], hint: 'برای بالا رفتن در لیگ', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'تمرکز', letters: ['ک', 'م', 'ر', 'ز', 'ت'], hint: 'برای جواب سریع لازم است', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'پیشرفت', letters: ['ش', 'پ', 'ف', 'ر', 'ت', 'ی'], hint: 'نتیجه ادامه دادن', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'استدلال', letters: ['ا', 'ل', 'د', 'س', 'ل', 'ت', 'ا'], hint: 'برای معمای سخت لازم است', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'راهبرد', letters: ['ه', 'ا', 'ر', 'ب', 'ر', 'د'], hint: 'روش درست برای برد', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'جایزه', letters: ['ه', 'ی', 'ز', 'ا', 'ج'], hint: 'پاداش روزانه', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'انرژی', letters: ['ژ', 'ر', 'ی', 'ن', 'ا'], hint: 'برای شروع بازی لازم است', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'راهنما', letters: ['ن', 'ر', 'ا', 'ا', 'ه', 'م'], hint: 'کمک داخل مرحله', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'مرحله', letters: ['م', 'ر', 'ه', 'ح', 'ل'], hint: 'بخش کوچک بازی', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'سرعت', letters: ['س', 'ع', 'ر', 'ت'], hint: 'برای چالش زمانی', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'حافظه', letters: ['ه', 'ظ', 'ف', 'ا', 'ح'], hint: 'برای یادآوری آیتم‌ها', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'چیستان', letters: ['ی', 'س', 'چ', 'ن', 'ت', 'ا'], hint: 'سؤال معمایی', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'لیگ', letters: ['گ', 'ل', 'ی'], hint: 'رتبه‌بندی هفتگی', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'رتبه', letters: ['ه', 'ب', 'ر', 'ت'], hint: 'جایگاه کاربر', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'سکه', letters: ['ه', 'س', 'ک'], hint: 'پول داخل بازی', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'آواتار', letters: ['ر', 'ا', 'و', 'ت', 'ا', 'آ'], hint: 'تصویر پروفایل', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'قاب', letters: ['ب', 'ق', 'ا'], hint: 'تزئین پروفایل', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'ماموریت', letters: ['و', 'ا', 'ت', 'م', 'ی', 'م', 'ر'], hint: 'کار روزانه برای پاداش', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'تبلیغ', letters: ['غ', 'ت', 'ب', 'ی', 'ل'], hint: 'راه گرفتن جایزه', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'پاداش', letters: ['ا', 'د', 'پ', 'ش', 'ا'], hint: 'هدیه بعد از برد', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'برنزی', letters: ['ن', 'ر', 'ی', 'ب', 'ز'], hint: 'لیگ شروع', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'نقره‌ای', letters: ['ق', '‌', 'ی', 'ر', 'ه', 'ا', 'ن'], hint: 'لیگ بعدی', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'طلایی', letters: ['ی', 'ا', 'ی', 'ل', 'ط'], hint: 'لیگ ارزشمند', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'الماسی', letters: ['س', 'م', 'ا', 'ی', 'ا', 'ل'], hint: 'لیگ سخت', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'افسانه‌ای', letters: ['ا', 'ه', 'ی', 'ف', 'ا', 'ن', 'ا', '‌', 'س'], hint: 'بالاترین لیگ', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'فکری', letters: ['ی', 'ف', 'ر', 'ک'], hint: 'نوع بازی کوتاه', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'تصویری', letters: ['ت', 'و', 'ر', 'ی', 'ص', 'ی'], hint: 'معمای با نشانه', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'عمومی', letters: ['م', 'ع', 'م', 'ی', 'و'], hint: 'اطلاعات متنوع', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'روزانه', letters: ['و', 'ر', 'ا', 'ز', 'ه', 'ن'], hint: 'چالش هر روز', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'ماهانه', letters: ['ا', 'ن', 'ه', 'م', 'ه', 'ا'], hint: 'رتبه‌بندی بلندتر', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'هفتگی', letters: ['ه', 'ف', 'گ', 'ت', 'ی'], hint: 'لیگ دوره‌ای', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'درست', letters: ['د', 'س', 'ر', 'ت'], hint: 'جواب صحیح', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'غلط', letters: ['ل', 'غ', 'ط'], hint: 'جواب اشتباه', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'قلب', letters: ['ق', 'ب', 'ل'], hint: 'جان کاربر', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'زمان', letters: ['ا', 'م', 'ن', 'ز'], hint: 'محدودیت پاسخ', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'رکورد', letters: ['ک', 'ر', 'د', 'و', 'ر'], hint: 'بهترین نتیجه', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'موفقیت', letters: ['ف', 'ق', 'ت', 'ی', 'و', 'م'], hint: 'برد و پیشروی', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'چالش', letters: ['ش', 'چ', 'ا', 'ل'], hint: 'هسته بازی', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'کلمه', letters: ['ل', 'م', 'ک', 'ه'], hint: 'جواب حدس کلمه', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'جدول', letters: ['ج', 'ل', 'د', 'و'], hint: 'بازی حروف', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'خواننده', letters: ['و', 'ن', 'ن', 'ا', 'خ', 'ه', 'د'], hint: 'حدس آهنگ', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'ضرب‌المثل', letters: ['م', '‌', 'ل', 'ل', 'ر', 'ث', 'ب', 'ض', 'ا'], hint: 'عبارت معروف', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'تفاوت', letters: ['ف', 'و', 'ت', 'ت', 'ا'], hint: 'پیدا کردن اختلاف', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'سینما', letters: ['م', 'ی', 'ن', 'ا', 'س'], hint: 'موضوع سؤال', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'فوتبال', letters: ['و', 'ت', 'ل', 'ب', 'ا', 'ف'], hint: 'موضوع سؤال', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'کردی', letters: ['د', 'ی', 'ک', 'ر'], hint: 'موضوع محلی', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'فارسی', letters: ['ی', 'ر', 'س', 'ا', 'ف'], hint: 'زبان سؤال', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'نشان', letters: ['ن', 'ن', 'ش', 'ا'], hint: 'آیکن یا علامت', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'هدف', letters: ['ف', 'د', 'ه'], hint: 'چیزی که دنبال می‌شود', difficulty: 'hard'),
  ]),
  GameDef('truefalse', 'درست یا غلط', 'جمله را بخوان و سریع درست یا غلط را انتخاب کن.', 'truefalse', 3, Color(0xFF8F6CFF), Color(0xFFFFCF6D), 'choice', [
    GameLevel(q: 'در چالش روزانه، بازی‌ها باید کوتاه و سریع باشند.', options: ['درست', 'غلط'], answer: 0, hint: 'بازی‌های ۳۰ تا ۶۰ ثانیه‌ای مناسب‌ترند.', difficulty: 'easy'),
    GameLevel(q: 'تبلیغ باید بعد از هر مرحله اجباری باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'تبلیغ زیاد باعث حذف اپ می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'تبلیغ جایزه‌دار باید با انتخاب کاربر باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'کاربر برای پاداش خودش انتخاب می‌کند.', difficulty: 'easy'),
    GameLevel(q: 'بنر بهتر است وسط صفحه بازی نمایش داده شود.', options: ['درست', 'غلط'], answer: 1, hint: 'بنر وسط بازی تمرکز را خراب می‌کند.', difficulty: 'easy'),
    GameLevel(q: 'انرژی روزانه باعث برگشت کاربر می‌شود.', options: ['درست', 'غلط'], answer: 0, hint: 'انرژی محدود کاربر را روزانه برمی‌گرداند.', difficulty: 'easy'),
    GameLevel(q: 'جایزه روزانه می‌تواند با تبلیغ دو برابر شود.', options: ['درست', 'غلط'], answer: 0, hint: 'Rewarded برای دوبرابر کردن مناسب است.', difficulty: 'easy'),
    GameLevel(q: 'سکه فقط برای نمایش است و مصرف نمی‌شود.', options: ['درست', 'غلط'], answer: 1, hint: 'سکه باید برای راهنما، ادامه و آیتم خرج شود.', difficulty: 'easy'),
    GameLevel(q: 'لیگ هفتگی رقابت کاربر را بیشتر می‌کند.', options: ['درست', 'غلط'], answer: 0, hint: 'لیگ انگیزه برگشت می‌دهد.', difficulty: 'easy'),
    GameLevel(q: 'چالش سرعتی باید چند دقیقه طول بکشد.', options: ['درست', 'غلط'], answer: 1, hint: 'چالش سرعتی کوتاه و ۳۰ ثانیه‌ای است.', difficulty: 'easy'),
    GameLevel(q: 'سؤال‌ها باید با لیگ سخت‌تر شوند.', options: ['درست', 'غلط'], answer: 0, hint: 'رتبه بالاتر یعنی سؤال سخت‌تر.', difficulty: 'easy'),
    GameLevel(q: 'جواب غلط نباید هیچ اثری داشته باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'طبق منطق بازی، قلب کم می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'راهنما یکی از محل‌های خرج سکه است.', options: ['درست', 'غلط'], answer: 0, hint: 'سکه برای گرفتن راهنما خرج می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'آواتار و قاب پروفایل برای شخصی‌سازی است.', options: ['درست', 'غلط'], answer: 0, hint: 'این‌ها انگیزه خرید/جمع‌آوری می‌دهند.', difficulty: 'easy'),
    GameLevel(q: 'رتبه‌بندی ماهانه باعث رقابت طولانی‌تر می‌شود.', options: ['درست', 'غلط'], answer: 0, hint: 'ماهانه برای کاربران فعال مناسب است.', difficulty: 'easy'),
    GameLevel(q: 'مأموریت روزانه نقشی در برگشت کاربر ندارد.', options: ['درست', 'غلط'], answer: 1, hint: 'مأموریت روزانه محرک برگشت است.', difficulty: 'easy'),
    GameLevel(q: 'سؤال تکراری در یک دور بازی بهتر است زیاد باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'تکرار کیفیت بازی را پایین می‌آورد.', difficulty: 'easy'),
    GameLevel(q: 'کاربر با برد مرحله سکه می‌گیرد.', options: ['درست', 'غلط'], answer: 0, hint: 'این هسته اقتصاد بازی است.', difficulty: 'easy'),
    GameLevel(q: 'ادامه بعد از باخت می‌تواند با سکه یا تبلیغ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'هر دو مسیر درآمد/مصرف سکه می‌سازند.', difficulty: 'medium'),
    GameLevel(q: 'Native Ad داخل خانه باید شبیه کارت معمولی باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'این مدل کمتر آزاردهنده است.', difficulty: 'medium'),
    GameLevel(q: 'قلب‌ها باید بعد از هر جواب غلط زیاد شوند.', options: ['درست', 'غلط'], answer: 1, hint: 'جواب غلط قلب را کم می‌کند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 21 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 22 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 23 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 24 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 25 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 26 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 27 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 28 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 29 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 30 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 31 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 32 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 33 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 34 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'قانون شماره 35 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 36 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 37 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 38 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 39 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 40 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 41 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 42 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 43 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 44 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 45 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 46 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 47 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 48 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 49 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'قانون شماره 50 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
  ]),
  GameDef('yesno', 'بله یا خیر', 'سؤال کوتاه را در ۵ ثانیه با بله یا خیر جواب بده.', 'yesno', 3, Color(0xFF14C8D8), Color(0xFF18BF8F), 'choice', [
    GameLevel(q: 'آیا در چالش روزانه، بازی‌ها باید کوتاه و سریع باشند.', options: ['بله', 'خیر'], answer: 0, hint: 'بازی‌های ۳۰ تا ۶۰ ثانیه‌ای مناسب‌ترند.', difficulty: 'easy'),
    GameLevel(q: 'آیا تبلیغ باید بعد از هر مرحله اجباری باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'تبلیغ زیاد باعث حذف اپ می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'آیا تبلیغ جایزه‌دار باید با انتخاب کاربر باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'کاربر برای پاداش خودش انتخاب می‌کند.', difficulty: 'easy'),
    GameLevel(q: 'آیا بنر بهتر است وسط صفحه بازی نمایش داده شود.', options: ['بله', 'خیر'], answer: 1, hint: 'بنر وسط بازی تمرکز را خراب می‌کند.', difficulty: 'easy'),
    GameLevel(q: 'آیا انرژی روزانه باعث برگشت کاربر می‌شود.', options: ['بله', 'خیر'], answer: 0, hint: 'انرژی محدود کاربر را روزانه برمی‌گرداند.', difficulty: 'easy'),
    GameLevel(q: 'آیا جایزه روزانه می‌تواند با تبلیغ دو برابر شود.', options: ['بله', 'خیر'], answer: 0, hint: 'Rewarded برای دوبرابر کردن مناسب است.', difficulty: 'easy'),
    GameLevel(q: 'آیا سکه فقط برای نمایش است و مصرف نمی‌شود.', options: ['بله', 'خیر'], answer: 1, hint: 'سکه باید برای راهنما، ادامه و آیتم خرج شود.', difficulty: 'easy'),
    GameLevel(q: 'آیا لیگ هفتگی رقابت کاربر را بیشتر می‌کند.', options: ['بله', 'خیر'], answer: 0, hint: 'لیگ انگیزه برگشت می‌دهد.', difficulty: 'easy'),
    GameLevel(q: 'آیا چالش سرعتی باید چند دقیقه طول بکشد.', options: ['بله', 'خیر'], answer: 1, hint: 'چالش سرعتی کوتاه و ۳۰ ثانیه‌ای است.', difficulty: 'easy'),
    GameLevel(q: 'آیا سؤال‌ها باید با لیگ سخت‌تر شوند.', options: ['بله', 'خیر'], answer: 0, hint: 'رتبه بالاتر یعنی سؤال سخت‌تر.', difficulty: 'easy'),
    GameLevel(q: 'آیا جواب غلط نباید هیچ اثری داشته باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'طبق منطق بازی، قلب کم می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'آیا راهنما یکی از محل‌های خرج سکه است.', options: ['بله', 'خیر'], answer: 0, hint: 'سکه برای گرفتن راهنما خرج می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'آیا آواتار و قاب پروفایل برای شخصی‌سازی است.', options: ['بله', 'خیر'], answer: 0, hint: 'این‌ها انگیزه خرید/جمع‌آوری می‌دهند.', difficulty: 'easy'),
    GameLevel(q: 'آیا رتبه‌بندی ماهانه باعث رقابت طولانی‌تر می‌شود.', options: ['بله', 'خیر'], answer: 0, hint: 'ماهانه برای کاربران فعال مناسب است.', difficulty: 'easy'),
    GameLevel(q: 'آیا مأموریت روزانه نقشی در برگشت کاربر ندارد.', options: ['بله', 'خیر'], answer: 1, hint: 'مأموریت روزانه محرک برگشت است.', difficulty: 'easy'),
    GameLevel(q: 'آیا سؤال تکراری در یک دور بازی بهتر است زیاد باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'تکرار کیفیت بازی را پایین می‌آورد.', difficulty: 'easy'),
    GameLevel(q: 'آیا کاربر با برد مرحله سکه می‌گیرد.', options: ['بله', 'خیر'], answer: 0, hint: 'این هسته اقتصاد بازی است.', difficulty: 'easy'),
    GameLevel(q: 'آیا ادامه بعد از باخت می‌تواند با سکه یا تبلیغ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'هر دو مسیر درآمد/مصرف سکه می‌سازند.', difficulty: 'medium'),
    GameLevel(q: 'آیا Native Ad داخل خانه باید شبیه کارت معمولی باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'این مدل کمتر آزاردهنده است.', difficulty: 'medium'),
    GameLevel(q: 'آیا قلب‌ها باید بعد از هر جواب غلط زیاد شوند.', options: ['بله', 'خیر'], answer: 1, hint: 'جواب غلط قلب را کم می‌کند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 21 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 22 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 23 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 24 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 25 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 26 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 27 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 28 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 29 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 30 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 31 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 32 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 33 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 34 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'medium'),
    GameLevel(q: 'آیا قانون شماره 35 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 36 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 37 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 38 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 39 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 40 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 41 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 42 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 43 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 44 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 45 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 46 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 47 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 48 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 49 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 0, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
    GameLevel(q: 'آیا قانون شماره 50 بازی باید با منطق چالش روزانه هماهنگ باشد.', options: ['بله', 'خیر'], answer: 1, hint: 'قانون‌ها باید واضح و قابل تست باشند.', difficulty: 'hard'),
  ]),
  GameDef('picture', 'معمای تصویری', 'با نشانه‌های تصویری جواب درست را انتخاب کن.', 'picture', 4, Color(0xFF18BF8F), Color(0xFF14C8D8), 'choice', [
    GameLevel(q: '🪙 + 🏆 یعنی چه؟', options: ['امتیاز لیگ', 'آب‌وهوا', 'غذا', 'خواب'], answer: 0, hint: 'سکه و جام یعنی رقابت.', difficulty: 'easy'),
    GameLevel(q: '🧠 + 🎯 یعنی چه؟', options: ['تمرکز', 'سفر', 'باران', 'خرید'], answer: 0, hint: 'هدف و مغز یعنی دقت.', difficulty: 'easy'),
    GameLevel(q: '⚡ + ⏱ یعنی چه؟', options: ['سرعت بازی', 'آرامش', 'پروفایل', 'فروشگاه'], answer: 0, hint: 'زمان و انرژی مهم است.', difficulty: 'easy'),
    GameLevel(q: '🏅 + ⭐ یعنی چه؟', options: ['رتبه ویژه', 'سؤال ساده', 'خروج', 'قفل'], answer: 0, hint: 'مدال و ستاره برای جایگاه بالا.', difficulty: 'easy'),
    GameLevel(q: '🎁 + 📅 یعنی چه؟', options: ['جایزه روزانه', 'خرید گوشی', 'آموزش', 'تنظیمات'], answer: 0, hint: 'تقویم و هدیه یعنی جایزه روزانه.', difficulty: 'easy'),
    GameLevel(q: '❤️ + ❌ یعنی چه؟', options: ['کم شدن قلب', 'برد مرحله', 'خرید سکه', 'افزایش انرژی'], answer: 0, hint: 'اشتباه باعث کم شدن قلب می‌شود.', difficulty: 'easy'),
    GameLevel(q: '📺 + 🪙 یعنی چه؟', options: ['تبلیغ جایزه‌دار', 'صفحه تنظیمات', 'جدول کلمات', 'خروج از بازی'], answer: 0, hint: 'دیدن ویدئو برای سکه.', difficulty: 'easy'),
    GameLevel(q: '🔥 + 📈 یعنی چه؟', options: ['رشد رکورد', 'خاموشی', 'فروشگاه', 'پیام'], answer: 0, hint: 'آتش و نمودار یعنی رشد سریع.', difficulty: 'easy'),
    GameLevel(q: '🔐 + 💰 یعنی چه؟', options: ['مرحله پولی', 'باز کردن رایگان', 'حذف حساب', 'تنظیم صدا'], answer: 0, hint: 'قفل با پول یعنی بازکردن با سکه.', difficulty: 'easy'),
    GameLevel(q: '🧩 + 🔤 یعنی چه؟', options: ['جدول کلمات', 'فوتبال', 'خواب', 'باران'], answer: 0, hint: 'قطعه و حرف یعنی بازی کلمات.', difficulty: 'easy'),
    GameLevel(q: '🎵 + 👤 یعنی چه؟', options: ['حدس خواننده', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'easy'),
    GameLevel(q: '🎬 + ❓ یعنی چه؟', options: ['سؤال سینمایی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'easy'),
    GameLevel(q: '⚽ + 🧠 یعنی چه؟', options: ['سؤال فوتبالی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'easy'),
    GameLevel(q: '🌄 + 🔍 یعنی چه؟', options: ['پیدا کردن تفاوت', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'easy'),
    GameLevel(q: '📜 + 💬 یعنی چه؟', options: ['ضرب‌المثل', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'easy'),
    GameLevel(q: '🔔 + 🎁 یعنی چه؟', options: ['نوتیفیکیشن جایزه', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'easy'),
    GameLevel(q: '🛒 + 🖼 یعنی چه؟', options: ['خرید آواتار', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'easy'),
    GameLevel(q: '🧿 + 🖼 یعنی چه؟', options: ['قاب پروفایل', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '📊 + 👑 یعنی چه؟', options: ['رتبه‌بندی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '📆 + ✅ یعنی چه؟', options: ['مأموریت روزانه', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '🧠 + ⚡ یعنی چه؟', options: ['چالش سرعتی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '🔡 + ❓ یعنی چه؟', options: ['حدس کلمه', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '🖼 + ❓ یعنی چه؟', options: ['معمای تصویری', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '🧭 + 🏆 یعنی چه؟', options: ['مسیر پیشرفت', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '💡 + 🪙 یعنی چه؟', options: ['خرید راهنما', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '🚪 + 📺 یعنی چه؟', options: ['ادامه با تبلیغ', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '⭐ + XP یعنی چه؟', options: ['امتیاز تجربه', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '❤️ + 3 یعنی چه؟', options: ['سه قلب', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '⏱ + 30 یعنی چه؟', options: ['سی ثانیه', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '🏆 + 7 یعنی چه؟', options: ['لیگ هفتگی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '📅 + 30 یعنی چه؟', options: ['رتبه ماهانه', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '🎯 + ✅ یعنی چه؟', options: ['جواب درست', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '❌ + ❤️ یعنی چه؟', options: ['جریمه غلط', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '🧠 + 📝 یعنی چه؟', options: ['سؤال عمومی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'medium'),
    GameLevel(q: '🎮 + 🕹 یعنی چه؟', options: ['شروع بازی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '📱 + 🇮🇷 یعنی چه؟', options: ['اپ ایرانی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '🪙 + 🛍 یعنی چه؟', options: ['خرید با سکه', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '🧩 + 🧠 یعنی چه؟', options: ['معمای منطقی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '👁 + 🧠 یعنی چه؟', options: ['حافظه سریع', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '🔁 + ❓ یعنی چه؟', options: ['سؤال چرخشی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '🧪 + ✅ یعنی چه؟', options: ['تست مرحله', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '📌 + امروز یعنی چه؟', options: ['چالش امروز', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '🔊 + ⚙ یعنی چه؟', options: ['تنظیم صدا', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '📳 + ⚙ یعنی چه؟', options: ['تنظیم لرزش', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '🚀 + 🏅 یعنی چه؟', options: ['پیشرفت لیگ', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '🥉 + ➡ یعنی چه؟', options: ['شروع برنزی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '🥈 + ⬆ یعنی چه؟', options: ['سطح نقره‌ای', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '🥇 + 🔥 یعنی چه؟', options: ['لیگ طلایی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '💎 + 🧠 یعنی چه؟', options: ['لیگ الماسی', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
    GameLevel(q: '🌟 + 👑 یعنی چه؟', options: ['افسانه‌ای', 'تنظیمات', 'خروج', 'خواب'], answer: 0, hint: 'به نشانه‌ها دقت کن.', difficulty: 'hard'),
  ]),
  GameDef('typo', 'غلط‌یاب', 'گزینه درست‌تر را انتخاب کن.', 'typo', 4, Color(0xFFFF7D9B), Color(0xFFFF5C7A), 'choice', [
    GameLevel(q: 'کدام درست‌تر است؟', options: ['امتیاز', 'امتیازی', 'امطیاز', 'امتیازز'], answer: 0, hint: 'شکل درست: امتیاز', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['رتبه‌بندی', 'رتبه بندیی', 'رطبه‌بندی', 'رتبه‌بندیز'], answer: 0, hint: 'شکل درست: رتبه‌بندی', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['استدلال', 'استدلالی', 'اسطدلال', 'استدلالز'], answer: 0, hint: 'شکل درست: استدلال', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['مسئولیت‌پذیری', 'مسئولیت پذیریی', 'مسئولیط‌پذیری', 'مسئولیت‌پذیریز'], answer: 0, hint: 'شکل درست: مسئولیت‌پذیری', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['چالش روزانه', 'چالش روزانهی', 'چالش روزانهه', 'چالش روزانهز'], answer: 0, hint: 'شکل درست: چالش روزانه', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['جایزه روزانه', 'جایزه روزانهی', 'جایزه روزانهه', 'جایزه روزانهز'], answer: 0, hint: 'شکل درست: جایزه روزانه', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['مأموریت', 'ماموریتی', 'مأموریط', 'مأموریتز'], answer: 0, hint: 'شکل درست: مأموریت', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['افسانه‌ای', 'افسانه ایی', 'افسانه‌ایه', 'افسانه‌ایز'], answer: 0, hint: 'شکل درست: افسانه‌ای', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['نقره‌ای', 'نقره ایی', 'نقره‌ایه', 'نقره‌ایز'], answer: 0, hint: 'شکل درست: نقره‌ای', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['پیشرفت', 'پیشرفتی', 'پیشرفط', 'پیشرفتز'], answer: 0, hint: 'شکل درست: پیشرفت', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['تمرکز', 'تمرکزی', 'طمرکز', 'تمرکزز'], answer: 0, hint: 'شکل درست: تمرکز', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['حافظه سریع', 'حافظه سریعی', 'حافظه سریعه', 'حافظه سریعز'], answer: 0, hint: 'شکل درست: حافظه سریع', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['چالش سرعتی', 'چالش سرعتیی', 'چالش سرعطی', 'چالش سرعتیز'], answer: 0, hint: 'شکل درست: چالش سرعتی', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['معمای تصویری', 'معمای تصویریی', 'معمای طصویری', 'معمای تصویریز'], answer: 0, hint: 'شکل درست: معمای تصویری', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['حدس کلمه', 'حدس کلمهی', 'حدس کلمهه', 'حدس کلمهز'], answer: 0, hint: 'شکل درست: حدس کلمه', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['تبلیغ جایزه‌دار', 'تبلیغ جایزه داری', 'طبلیغ جایزه‌دار', 'تبلیغ جایزه‌دارز'], answer: 0, hint: 'شکل درست: تبلیغ جایزه‌دار', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['رتبه ماهانه', 'رتبه ماهانهی', 'رطبه ماهانه', 'رتبه ماهانهز'], answer: 0, hint: 'شکل درست: رتبه ماهانه', difficulty: 'easy'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['لیگ هفتگی', 'لیگ هفتگیی', 'لیگ هفطگی', 'لیگ هفتگیز'], answer: 0, hint: 'شکل درست: لیگ هفتگی', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['آواتار', 'اواتاری', 'آواطار', 'آواتارز'], answer: 0, hint: 'شکل درست: آواتار', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['پروفایل', 'پروفایلی', 'پروفایله', 'پروفایلز'], answer: 0, hint: 'شکل درست: پروفایل', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['انرژی', 'انرژیی', 'انرژیه', 'انرژیز'], answer: 0, hint: 'شکل درست: انرژی', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['راهنما', 'راهنمای', 'راهنماه', 'راهنماز'], answer: 0, hint: 'شکل درست: راهنما', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['سکه', 'سکهی', 'سکهه', 'سکهز'], answer: 0, hint: 'شکل درست: سکه', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['قلب', 'قلبی', 'قلبه', 'قلبز'], answer: 0, hint: 'شکل درست: قلب', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['مرحله سخت', 'مرحله سختی', 'مرحله سخط', 'مرحله سختز'], answer: 0, hint: 'شکل درست: مرحله سخت', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['ادامه بازی', 'ادامه بازیی', 'ادامه بازیه', 'ادامه بازیز'], answer: 0, hint: 'شکل درست: ادامه بازی', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['فروشگاه', 'فروشگاهی', 'فروشگاهه', 'فروشگاهز'], answer: 0, hint: 'شکل درست: فروشگاه', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['تنظیمات', 'تنظیماتی', 'طنظیمات', 'تنظیماتز'], answer: 0, hint: 'شکل درست: تنظیمات', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['دستاورد', 'دستاوردی', 'دسطاورد', 'دستاوردز'], answer: 0, hint: 'شکل درست: دستاورد', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['مدال', 'مدالی', 'مداله', 'مدالز'], answer: 0, hint: 'شکل درست: مدال', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['جواب درست', 'جواب درستی', 'جواب درسط', 'جواب درستز'], answer: 0, hint: 'شکل درست: جواب درست', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['جواب غلط', 'جواب غلطی', 'جواب غلطه', 'جواب غلطز'], answer: 0, hint: 'شکل درست: جواب غلط', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['کاربر فعال', 'کاربر فعالی', 'کاربر فعاله', 'کاربر فعالز'], answer: 0, hint: 'شکل درست: کاربر فعال', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['چالش امروز', 'چالش امروزی', 'چالش امروزه', 'چالش امروزز'], answer: 0, hint: 'شکل درست: چالش امروز', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['سؤال عمومی', 'سؤال عمومیی', 'سؤال عمومیه', 'سؤال عمومیز'], answer: 0, hint: 'شکل درست: سؤال عمومی', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['سؤال فوتبالی', 'سؤال فوتبالیی', 'سؤال فوطبالی', 'سؤال فوتبالیز'], answer: 0, hint: 'شکل درست: سؤال فوتبالی', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['سؤال سینمایی', 'سؤال سینماییی', 'سؤال سینماییه', 'سؤال سینماییز'], answer: 0, hint: 'شکل درست: سؤال سینمایی', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['ضرب‌المثل', 'ضرب المثلی', 'ضرب‌المثله', 'ضرب‌المثلز'], answer: 0, hint: 'شکل درست: ضرب‌المثل', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['جدول کلمات', 'جدول کلماتی', 'جدول کلماط', 'جدول کلماتز'], answer: 0, hint: 'شکل درست: جدول کلمات', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['خواننده', 'خوانندهی', 'خوانندهه', 'خوانندهز'], answer: 0, hint: 'شکل درست: خواننده', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['تفاوت تصویر', 'تفاوت تصویری', 'طفاوت تصویر', 'تفاوت تصویرز'], answer: 0, hint: 'شکل درست: تفاوت تصویر', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['قاب پروفایل', 'قاب پروفایلی', 'قاب پروفایله', 'قاب پروفایلز'], answer: 0, hint: 'شکل درست: قاب پروفایل', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['پاداش ویژه', 'پاداش ویژهی', 'پاداش ویژهه', 'پاداش ویژهز'], answer: 0, hint: 'شکل درست: پاداش ویژه', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['شروع بازی', 'شروع بازیی', 'شروع بازیه', 'شروع بازیز'], answer: 0, hint: 'شکل درست: شروع بازی', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['پایان بازی', 'پایان بازیی', 'پایان بازیه', 'پایان بازیز'], answer: 0, hint: 'شکل درست: پایان بازی', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['رکورد جدید', 'رکورد جدیدی', 'رکورد جدیده', 'رکورد جدیدز'], answer: 0, hint: 'شکل درست: رکورد جدید', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['سطح سخت', 'سطح سختی', 'سطح سخط', 'سطح سختز'], answer: 0, hint: 'شکل درست: سطح سخت', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['سطح متوسط', 'سطح متوسطی', 'سطح مطوسط', 'سطح متوسطز'], answer: 0, hint: 'شکل درست: سطح متوسط', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['سطح آسان', 'سطح اسانی', 'سطح آسانه', 'سطح آسانز'], answer: 0, hint: 'شکل درست: سطح آسان', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['بازی کوتاه', 'بازی کوتاهی', 'بازی کوطاه', 'بازی کوتاهز'], answer: 0, hint: 'شکل درست: بازی کوتاه', difficulty: 'hard'),
  ]),
  GameDef('logic', 'معمای منطقی', 'سؤال‌های کوتاه و فکری با انتخاب جواب.', 'logic', 5, Color(0xFF6C63FF), Color(0xFF14C8D8), 'choice', [
    GameLevel(q: 'اگر 1 جواب درست بدهی و ۲ جواب دیگر هم درست شود، چند جواب درست داری؟', options: ['3', '2', '4', '1'], answer: 0, hint: '1+۲', difficulty: 'easy'),
    GameLevel(q: 'اگر هر برد ۱۴ سکه بدهد، 4 برد چند سکه می‌دهد؟', options: ['56', '48', '40', '80'], answer: 0, hint: 'تعداد برد را در پاداش ضرب کن.', difficulty: 'easy'),
    GameLevel(q: 'اگر با هر غلط یک قلب کم شود و ۳ قلب داشته باشی، بعد از 3 غلط چند قلب می‌ماند؟', options: ['0', '3', '3', '1'], answer: 0, hint: 'قلب‌ها از ۳ کم می‌شوند.', difficulty: 'easy'),
    GameLevel(q: 'اگر لیگ سخت‌تر شود، سؤال‌ها چه می‌شوند؟', options: ['سخت‌تر', 'آسان‌تر', 'حذف می‌شوند', 'بدون تغییر اجباری'], answer: 0, hint: 'رتبه بالاتر چالش سخت‌تر دارد.', difficulty: 'easy'),
    GameLevel(q: 'برای جلوگیری از تکرار سؤال، سیستم باید چه کند؟', options: ['سؤال بعدی را بچرخاند', 'همان سؤال را تکرار کند', 'بازی را ببندد', 'سکه را صفر کند'], answer: 0, hint: 'چرخش سؤال لازم است.', difficulty: 'easy'),
    GameLevel(q: 'اگر 6 جواب درست بدهی و ۲ جواب دیگر هم درست شود، چند جواب درست داری؟', options: ['8', '7', '9', '6'], answer: 0, hint: '6+۲', difficulty: 'easy'),
    GameLevel(q: 'اگر هر برد ۱۴ سکه بدهد، 2 برد چند سکه می‌دهد؟', options: ['28', '24', '20', '40'], answer: 0, hint: 'تعداد برد را در پاداش ضرب کن.', difficulty: 'easy'),
    GameLevel(q: 'اگر با هر غلط یک قلب کم شود و ۳ قلب داشته باشی، بعد از 1 غلط چند قلب می‌ماند؟', options: ['2', '3', '1', '1'], answer: 0, hint: 'قلب‌ها از ۳ کم می‌شوند.', difficulty: 'easy'),
    GameLevel(q: 'اگر لیگ سخت‌تر شود، سؤال‌ها چه می‌شوند؟', options: ['سخت‌تر', 'آسان‌تر', 'حذف می‌شوند', 'بدون تغییر اجباری'], answer: 0, hint: 'رتبه بالاتر چالش سخت‌تر دارد.', difficulty: 'easy'),
    GameLevel(q: 'برای جلوگیری از تکرار سؤال، سیستم باید چه کند؟', options: ['سؤال بعدی را بچرخاند', 'همان سؤال را تکرار کند', 'بازی را ببندد', 'سکه را صفر کند'], answer: 0, hint: 'چرخش سؤال لازم است.', difficulty: 'easy'),
    GameLevel(q: 'اگر 11 جواب درست بدهی و ۲ جواب دیگر هم درست شود، چند جواب درست داری؟', options: ['13', '12', '14', '11'], answer: 0, hint: '11+۲', difficulty: 'easy'),
    GameLevel(q: 'اگر هر برد ۱۴ سکه بدهد، 7 برد چند سکه می‌دهد؟', options: ['98', '84', '70', '140'], answer: 0, hint: 'تعداد برد را در پاداش ضرب کن.', difficulty: 'easy'),
    GameLevel(q: 'اگر با هر غلط یک قلب کم شود و ۳ قلب داشته باشی، بعد از 2 غلط چند قلب می‌ماند؟', options: ['1', '3', '2', '1'], answer: 0, hint: 'قلب‌ها از ۳ کم می‌شوند.', difficulty: 'easy'),
    GameLevel(q: 'اگر لیگ سخت‌تر شود، سؤال‌ها چه می‌شوند؟', options: ['سخت‌تر', 'آسان‌تر', 'حذف می‌شوند', 'بدون تغییر اجباری'], answer: 0, hint: 'رتبه بالاتر چالش سخت‌تر دارد.', difficulty: 'easy'),
    GameLevel(q: 'برای جلوگیری از تکرار سؤال، سیستم باید چه کند؟', options: ['سؤال بعدی را بچرخاند', 'همان سؤال را تکرار کند', 'بازی را ببندد', 'سکه را صفر کند'], answer: 0, hint: 'چرخش سؤال لازم است.', difficulty: 'easy'),
    GameLevel(q: 'اگر 16 جواب درست بدهی و ۲ جواب دیگر هم درست شود، چند جواب درست داری؟', options: ['18', '17', '19', '16'], answer: 0, hint: '16+۲', difficulty: 'easy'),
    GameLevel(q: 'اگر هر برد ۱۴ سکه بدهد، 5 برد چند سکه می‌دهد؟', options: ['70', '60', '50', '100'], answer: 0, hint: 'تعداد برد را در پاداش ضرب کن.', difficulty: 'easy'),
    GameLevel(q: 'اگر با هر غلط یک قلب کم شود و ۳ قلب داشته باشی، بعد از 3 غلط چند قلب می‌ماند؟', options: ['0', '3', '3', '1'], answer: 0, hint: 'قلب‌ها از ۳ کم می‌شوند.', difficulty: 'medium'),
    GameLevel(q: 'اگر لیگ سخت‌تر شود، سؤال‌ها چه می‌شوند؟', options: ['سخت‌تر', 'آسان‌تر', 'حذف می‌شوند', 'بدون تغییر اجباری'], answer: 0, hint: 'رتبه بالاتر چالش سخت‌تر دارد.', difficulty: 'medium'),
    GameLevel(q: 'برای جلوگیری از تکرار سؤال، سیستم باید چه کند؟', options: ['سؤال بعدی را بچرخاند', 'همان سؤال را تکرار کند', 'بازی را ببندد', 'سکه را صفر کند'], answer: 0, hint: 'چرخش سؤال لازم است.', difficulty: 'medium'),
    GameLevel(q: 'اگر 21 جواب درست بدهی و ۲ جواب دیگر هم درست شود، چند جواب درست داری؟', options: ['23', '22', '24', '21'], answer: 0, hint: '21+۲', difficulty: 'medium'),
    GameLevel(q: 'اگر هر برد ۱۴ سکه بدهد، 3 برد چند سکه می‌دهد؟', options: ['42', '36', '30', '60'], answer: 0, hint: 'تعداد برد را در پاداش ضرب کن.', difficulty: 'medium'),
    GameLevel(q: 'اگر با هر غلط یک قلب کم شود و ۳ قلب داشته باشی، بعد از 3 غلط چند قلب می‌ماند؟', options: ['0', '3', '3', '1'], answer: 0, hint: 'قلب‌ها از ۳ کم می‌شوند.', difficulty: 'medium'),
    GameLevel(q: 'اگر لیگ سخت‌تر شود، سؤال‌ها چه می‌شوند؟', options: ['سخت‌تر', 'آسان‌تر', 'حذف می‌شوند', 'بدون تغییر اجباری'], answer: 0, hint: 'رتبه بالاتر چالش سخت‌تر دارد.', difficulty: 'medium'),
    GameLevel(q: 'برای جلوگیری از تکرار سؤال، سیستم باید چه کند؟', options: ['سؤال بعدی را بچرخاند', 'همان سؤال را تکرار کند', 'بازی را ببندد', 'سکه را صفر کند'], answer: 0, hint: 'چرخش سؤال لازم است.', difficulty: 'medium'),
    GameLevel(q: 'اگر 26 جواب درست بدهی و ۲ جواب دیگر هم درست شود، چند جواب درست داری؟', options: ['28', '27', '29', '26'], answer: 0, hint: '26+۲', difficulty: 'medium'),
    GameLevel(q: 'اگر هر برد ۱۴ سکه بدهد، 8 برد چند سکه می‌دهد؟', options: ['112', '96', '80', '160'], answer: 0, hint: 'تعداد برد را در پاداش ضرب کن.', difficulty: 'medium'),
    GameLevel(q: 'اگر با هر غلط یک قلب کم شود و ۳ قلب داشته باشی، بعد از 1 غلط چند قلب می‌ماند؟', options: ['2', '3', '1', '1'], answer: 0, hint: 'قلب‌ها از ۳ کم می‌شوند.', difficulty: 'medium'),
    GameLevel(q: 'اگر لیگ سخت‌تر شود، سؤال‌ها چه می‌شوند؟', options: ['سخت‌تر', 'آسان‌تر', 'حذف می‌شوند', 'بدون تغییر اجباری'], answer: 0, hint: 'رتبه بالاتر چالش سخت‌تر دارد.', difficulty: 'medium'),
    GameLevel(q: 'برای جلوگیری از تکرار سؤال، سیستم باید چه کند؟', options: ['سؤال بعدی را بچرخاند', 'همان سؤال را تکرار کند', 'بازی را ببندد', 'سکه را صفر کند'], answer: 0, hint: 'چرخش سؤال لازم است.', difficulty: 'medium'),
    GameLevel(q: 'اگر 31 جواب درست بدهی و ۲ جواب دیگر هم درست شود، چند جواب درست داری؟', options: ['33', '32', '34', '31'], answer: 0, hint: '31+۲', difficulty: 'medium'),
    GameLevel(q: 'اگر هر برد ۱۴ سکه بدهد، 6 برد چند سکه می‌دهد؟', options: ['84', '72', '60', '120'], answer: 0, hint: 'تعداد برد را در پاداش ضرب کن.', difficulty: 'medium'),
    GameLevel(q: 'اگر با هر غلط یک قلب کم شود و ۳ قلب داشته باشی، بعد از 2 غلط چند قلب می‌ماند؟', options: ['1', '3', '2', '1'], answer: 0, hint: 'قلب‌ها از ۳ کم می‌شوند.', difficulty: 'medium'),
    GameLevel(q: 'اگر لیگ سخت‌تر شود، سؤال‌ها چه می‌شوند؟', options: ['سخت‌تر', 'آسان‌تر', 'حذف می‌شوند', 'بدون تغییر اجباری'], answer: 0, hint: 'رتبه بالاتر چالش سخت‌تر دارد.', difficulty: 'medium'),
    GameLevel(q: 'برای جلوگیری از تکرار سؤال، سیستم باید چه کند؟', options: ['سؤال بعدی را بچرخاند', 'همان سؤال را تکرار کند', 'بازی را ببندد', 'سکه را صفر کند'], answer: 0, hint: 'چرخش سؤال لازم است.', difficulty: 'hard'),
    GameLevel(q: 'اگر 36 جواب درست بدهی و ۲ جواب دیگر هم درست شود، چند جواب درست داری؟', options: ['38', '37', '39', '36'], answer: 0, hint: '36+۲', difficulty: 'hard'),
    GameLevel(q: 'اگر هر برد ۱۴ سکه بدهد، 4 برد چند سکه می‌دهد؟', options: ['56', '48', '40', '80'], answer: 0, hint: 'تعداد برد را در پاداش ضرب کن.', difficulty: 'hard'),
    GameLevel(q: 'اگر با هر غلط یک قلب کم شود و ۳ قلب داشته باشی، بعد از 3 غلط چند قلب می‌ماند؟', options: ['0', '3', '3', '1'], answer: 0, hint: 'قلب‌ها از ۳ کم می‌شوند.', difficulty: 'hard'),
    GameLevel(q: 'اگر لیگ سخت‌تر شود، سؤال‌ها چه می‌شوند؟', options: ['سخت‌تر', 'آسان‌تر', 'حذف می‌شوند', 'بدون تغییر اجباری'], answer: 0, hint: 'رتبه بالاتر چالش سخت‌تر دارد.', difficulty: 'hard'),
    GameLevel(q: 'برای جلوگیری از تکرار سؤال، سیستم باید چه کند؟', options: ['سؤال بعدی را بچرخاند', 'همان سؤال را تکرار کند', 'بازی را ببندد', 'سکه را صفر کند'], answer: 0, hint: 'چرخش سؤال لازم است.', difficulty: 'hard'),
    GameLevel(q: 'اگر 41 جواب درست بدهی و ۲ جواب دیگر هم درست شود، چند جواب درست داری؟', options: ['43', '42', '44', '41'], answer: 0, hint: '41+۲', difficulty: 'hard'),
    GameLevel(q: 'اگر هر برد ۱۴ سکه بدهد، 2 برد چند سکه می‌دهد؟', options: ['28', '24', '20', '40'], answer: 0, hint: 'تعداد برد را در پاداش ضرب کن.', difficulty: 'hard'),
    GameLevel(q: 'اگر با هر غلط یک قلب کم شود و ۳ قلب داشته باشی، بعد از 3 غلط چند قلب می‌ماند؟', options: ['0', '3', '3', '1'], answer: 0, hint: 'قلب‌ها از ۳ کم می‌شوند.', difficulty: 'hard'),
    GameLevel(q: 'اگر لیگ سخت‌تر شود، سؤال‌ها چه می‌شوند؟', options: ['سخت‌تر', 'آسان‌تر', 'حذف می‌شوند', 'بدون تغییر اجباری'], answer: 0, hint: 'رتبه بالاتر چالش سخت‌تر دارد.', difficulty: 'hard'),
    GameLevel(q: 'برای جلوگیری از تکرار سؤال، سیستم باید چه کند؟', options: ['سؤال بعدی را بچرخاند', 'همان سؤال را تکرار کند', 'بازی را ببندد', 'سکه را صفر کند'], answer: 0, hint: 'چرخش سؤال لازم است.', difficulty: 'hard'),
    GameLevel(q: 'اگر 46 جواب درست بدهی و ۲ جواب دیگر هم درست شود، چند جواب درست داری؟', options: ['48', '47', '49', '46'], answer: 0, hint: '46+۲', difficulty: 'hard'),
    GameLevel(q: 'اگر هر برد ۱۴ سکه بدهد، 7 برد چند سکه می‌دهد؟', options: ['98', '84', '70', '140'], answer: 0, hint: 'تعداد برد را در پاداش ضرب کن.', difficulty: 'hard'),
    GameLevel(q: 'اگر با هر غلط یک قلب کم شود و ۳ قلب داشته باشی، بعد از 1 غلط چند قلب می‌ماند؟', options: ['2', '3', '1', '1'], answer: 0, hint: 'قلب‌ها از ۳ کم می‌شوند.', difficulty: 'hard'),
    GameLevel(q: 'اگر لیگ سخت‌تر شود، سؤال‌ها چه می‌شوند؟', options: ['سخت‌تر', 'آسان‌تر', 'حذف می‌شوند', 'بدون تغییر اجباری'], answer: 0, hint: 'رتبه بالاتر چالش سخت‌تر دارد.', difficulty: 'hard'),
    GameLevel(q: 'برای جلوگیری از تکرار سؤال، سیستم باید چه کند؟', options: ['سؤال بعدی را بچرخاند', 'همان سؤال را تکرار کند', 'بازی را ببندد', 'سکه را صفر کند'], answer: 0, hint: 'چرخش سؤال لازم است.', difficulty: 'hard'),
  ]),
  GameDef('memory', 'حافظه سریع', 'چند آیتم را ببین و بعد از حافظه جواب بده.', 'brain', 4, Color(0xFF30D5C8), Color(0xFF6C63FF), 'memory', [
    GameLevel(q: 'کدام مورد در لیست بود؟', items: ['سکه', 'انرژی', 'قلب'], options: ['انرژی', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['کتاب', 'قلم', 'دفتر', 'کلاس'], options: ['قلم', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['لیگ', 'سکه', 'مرحله', 'XP'], options: ['درخت', 'باران', 'کوه', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'آیتم سوم چه بود؟', items: ['تمرکز', 'سرعت', 'راهبرد', 'تحلیل', 'نوآوری'], options: ['راهبرد', 'باران', 'کوه', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'کدام برای شخصی‌سازی است؟', items: ['آواتار', 'قاب', 'پروفایل'], options: ['قاب', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'بعد از تبلیغ چه پاداشی ممکن است؟', items: ['تبلیغ', 'سکه', 'راهنما'], options: ['سکه', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'لیگ وسط کدام بود؟', items: ['برنزی', 'نقره‌ای', 'طلایی'], options: ['نقره‌ای', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'کدام مربوط به جایزه هر روز است؟', items: ['روزانه', 'هفتگی', 'ماهانه'], options: ['روزانه', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'جواب غلط چه چیزی کم می‌کند؟', items: ['درست', 'غلط', 'قلب'], options: ['قلب', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'کدام زمان را نشان می‌دهد؟', items: ['تایمر', 'سؤال', 'پاسخ'], options: ['تایمر', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'کدام مورد در لیست بود؟', items: ['سکه', 'انرژی', 'قلب'], options: ['انرژی', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['کتاب', 'قلم', 'دفتر', 'کلاس'], options: ['قلم', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['لیگ', 'سکه', 'مرحله', 'XP'], options: ['درخت', 'باران', 'کوه', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'آیتم سوم چه بود؟', items: ['تمرکز', 'سرعت', 'راهبرد', 'تحلیل', 'نوآوری'], options: ['راهبرد', 'باران', 'کوه', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'کدام برای شخصی‌سازی است؟', items: ['آواتار', 'قاب', 'پروفایل'], options: ['قاب', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'بعد از تبلیغ چه پاداشی ممکن است؟', items: ['تبلیغ', 'سکه', 'راهنما'], options: ['سکه', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'لیگ وسط کدام بود؟', items: ['برنزی', 'نقره‌ای', 'طلایی'], options: ['نقره‌ای', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'easy'),
    GameLevel(q: 'کدام مربوط به جایزه هر روز است؟', items: ['روزانه', 'هفتگی', 'ماهانه'], options: ['روزانه', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'جواب غلط چه چیزی کم می‌کند؟', items: ['درست', 'غلط', 'قلب'], options: ['قلب', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'کدام زمان را نشان می‌دهد؟', items: ['تایمر', 'سؤال', 'پاسخ'], options: ['تایمر', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست بود؟', items: ['سکه', 'انرژی', 'قلب'], options: ['انرژی', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['کتاب', 'قلم', 'دفتر', 'کلاس'], options: ['قلم', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['لیگ', 'سکه', 'مرحله', 'XP'], options: ['درخت', 'باران', 'کوه', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'آیتم سوم چه بود؟', items: ['تمرکز', 'سرعت', 'راهبرد', 'تحلیل', 'نوآوری'], options: ['راهبرد', 'باران', 'کوه', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'کدام برای شخصی‌سازی است؟', items: ['آواتار', 'قاب', 'پروفایل'], options: ['قاب', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'بعد از تبلیغ چه پاداشی ممکن است؟', items: ['تبلیغ', 'سکه', 'راهنما'], options: ['سکه', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'لیگ وسط کدام بود؟', items: ['برنزی', 'نقره‌ای', 'طلایی'], options: ['نقره‌ای', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'کدام مربوط به جایزه هر روز است؟', items: ['روزانه', 'هفتگی', 'ماهانه'], options: ['روزانه', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'جواب غلط چه چیزی کم می‌کند؟', items: ['درست', 'غلط', 'قلب'], options: ['قلب', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'کدام زمان را نشان می‌دهد؟', items: ['تایمر', 'سؤال', 'پاسخ'], options: ['تایمر', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست بود؟', items: ['سکه', 'انرژی', 'قلب'], options: ['انرژی', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['کتاب', 'قلم', 'دفتر', 'کلاس'], options: ['قلم', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['لیگ', 'سکه', 'مرحله', 'XP'], options: ['درخت', 'باران', 'کوه', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'آیتم سوم چه بود؟', items: ['تمرکز', 'سرعت', 'راهبرد', 'تحلیل', 'نوآوری'], options: ['راهبرد', 'باران', 'کوه', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'medium'),
    GameLevel(q: 'کدام برای شخصی‌سازی است؟', items: ['آواتار', 'قاب', 'پروفایل'], options: ['قاب', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'بعد از تبلیغ چه پاداشی ممکن است؟', items: ['تبلیغ', 'سکه', 'راهنما'], options: ['سکه', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'لیگ وسط کدام بود؟', items: ['برنزی', 'نقره‌ای', 'طلایی'], options: ['نقره‌ای', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'کدام مربوط به جایزه هر روز است؟', items: ['روزانه', 'هفتگی', 'ماهانه'], options: ['روزانه', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'جواب غلط چه چیزی کم می‌کند؟', items: ['درست', 'غلط', 'قلب'], options: ['قلب', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'کدام زمان را نشان می‌دهد؟', items: ['تایمر', 'سؤال', 'پاسخ'], options: ['تایمر', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد در لیست بود؟', items: ['سکه', 'انرژی', 'قلب'], options: ['انرژی', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['کتاب', 'قلم', 'دفتر', 'کلاس'], options: ['قلم', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['لیگ', 'سکه', 'مرحله', 'XP'], options: ['درخت', 'باران', 'کوه', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'آیتم سوم چه بود؟', items: ['تمرکز', 'سرعت', 'راهبرد', 'تحلیل', 'نوآوری'], options: ['راهبرد', 'باران', 'کوه', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'کدام برای شخصی‌سازی است؟', items: ['آواتار', 'قاب', 'پروفایل'], options: ['قاب', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'بعد از تبلیغ چه پاداشی ممکن است؟', items: ['تبلیغ', 'سکه', 'راهنما'], options: ['سکه', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'لیگ وسط کدام بود؟', items: ['برنزی', 'نقره‌ای', 'طلایی'], options: ['نقره‌ای', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'کدام مربوط به جایزه هر روز است؟', items: ['روزانه', 'هفتگی', 'ماهانه'], options: ['روزانه', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'جواب غلط چه چیزی کم می‌کند؟', items: ['درست', 'غلط', 'قلب'], options: ['قلب', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
    GameLevel(q: 'کدام زمان را نشان می‌دهد؟', items: ['تایمر', 'سؤال', 'پاسخ'], options: ['تایمر', 'درخت', 'خواب', 'چراغ'], answer: 0, hint: 'آیتم‌ها را چند ثانیه به خاطر بسپار.', difficulty: 'hard'),
  ]),
  GameDef('speed', 'چالش سرعتی', '۳۰ ثانیه سؤال سریع و رکوردی.', 'speed', 5, Color(0xFFFFB84D), Color(0xFFEF476F), 'speed', [
    GameLevel(q: 'زمان چالش سرعتی چند ثانیه است؟', options: ['۳۰', '۴۵', '۶۰', '۹۰'], answer: 0, hint: 'چالش سرعتی باید کوتاه باشد.', difficulty: 'easy'),
    GameLevel(q: 'دیدن تبلیغ جایزه‌دار چند سکه بدهد؟', options: ['۵۰۰', '۱۰۰', '۱۵۰', '۵۰'], answer: 0, hint: 'منطق ارسالی کاربر ۵۰۰ سکه است.', difficulty: 'easy'),
    GameLevel(q: 'جواب غلط چه کم می‌کند؟', options: ['قلب', 'آیکن', 'نام', 'رنگ'], answer: 0, hint: 'قلب کم می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'برای ادامه بعد از باخت چه می‌شود دید؟', options: ['تبلیغ', 'فقط تنظیمات', 'راهنما', 'پروفایل'], answer: 0, hint: 'تبلیغ جایزه‌دار مسیر ادامه است.', difficulty: 'easy'),
    GameLevel(q: 'سکه برای چه مصرف می‌شود؟', options: ['راهنما', 'خاموشی', 'حذف بازی', 'تغییر نام اپ'], answer: 0, hint: 'راهنما یکی از مصرف‌هاست.', difficulty: 'easy'),
    GameLevel(q: 'لیگ هفتگی برای چیست؟', options: ['رقابت', 'کاهش کیفیت', 'حذف سکه', 'بستن بازی'], answer: 0, hint: 'لیگ رقابت می‌سازد.', difficulty: 'easy'),
    GameLevel(q: 'Native Ad بهتر است کجا باشد؟', options: ['خانه/رتبه‌بندی', 'وسط بازی', 'روی سؤال', 'روی گزینه'], answer: 0, hint: 'نباید وسط بازی باشد.', difficulty: 'easy'),
    GameLevel(q: 'بنر نباید کجا باشد؟', options: ['وسط بازی', 'صفحه تنظیمات', 'صفحه فروشگاه', 'پایین صفحه غیرحساس'], answer: 0, hint: 'وسط بازی تمرکز را خراب می‌کند.', difficulty: 'easy'),
    GameLevel(q: 'جایزه روزانه چه چیزی می‌سازد؟', options: ['برگشت کاربر', 'حذف کاربر', 'کندی بازی', 'ریست لیگ'], answer: 0, hint: 'کاربر را هر روز برمی‌گرداند.', difficulty: 'easy'),
    GameLevel(q: 'سؤال‌ها باید با لیگ چه شوند؟', options: ['سخت‌تر', 'پاک‌تر', 'کم‌رنگ‌تر', 'بی‌زمان'], answer: 0, hint: 'لیگ بالاتر سخت‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'قانون سریع شماره 11: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'easy'),
    GameLevel(q: 'قانون سریع شماره 12: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'easy'),
    GameLevel(q: 'قانون سریع شماره 13: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'easy'),
    GameLevel(q: 'قانون سریع شماره 14: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'easy'),
    GameLevel(q: 'قانون سریع شماره 15: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'easy'),
    GameLevel(q: 'قانون سریع شماره 16: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'easy'),
    GameLevel(q: 'قانون سریع شماره 17: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'easy'),
    GameLevel(q: 'قانون سریع شماره 18: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 19: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 20: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 21: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 22: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 23: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 24: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 25: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 26: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 27: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 28: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 29: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 30: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 31: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 32: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 33: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 34: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'medium'),
    GameLevel(q: 'قانون سریع شماره 35: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 36: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 37: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 38: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 39: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 40: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 41: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 42: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 43: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 44: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 45: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 46: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 47: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 48: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 49: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
    GameLevel(q: 'قانون سریع شماره 50: برد مرحله چه می‌دهد؟', options: ['سکه و XP', 'فقط خروج', 'حذف انرژی', 'خاموشی'], answer: 0, hint: 'برد باید پاداش بدهد.', difficulty: 'hard'),
  ]),
];

class PlayerState {
  int coins;
  int energy;
  int xp;
  int hints;
  int gamesDone;
  int correct;
  int wrong;
  int ads;
  int bestSpeed;
  String dailyDate;
  Map<String, int> progresses;
  Set<String> playedGames;
  Set<String> achievements;

  PlayerState({
    this.coins = 970,
    this.energy = 50,
    this.xp = 0,
    this.hints = 3,
    this.gamesDone = 0,
    this.correct = 0,
    this.wrong = 0,
    this.ads = 0,
    this.bestSpeed = 0,
    this.dailyDate = '',
    Map<String, int>? progresses,
    Set<String>? playedGames,
    Set<String>? achievements,
  })  : progresses = progresses ?? <String, int>{},
        playedGames = playedGames ?? <String>{},
        achievements = achievements ?? <String>{};

  Map<String, dynamic> toJson() => {
        'coins': coins,
        'energy': energy,
        'xp': xp,
        'hints': hints,
        'gamesDone': gamesDone,
        'correct': correct,
        'wrong': wrong,
        'ads': ads,
        'bestSpeed': bestSpeed,
        'dailyDate': dailyDate,
        'progresses': progresses,
        'playedGames': playedGames.toList(),
        'achievements': achievements.toList(),
      };

  factory PlayerState.fromJson(Map<String, dynamic> json) => PlayerState(
        coins: json['coins'] ?? 970,
        energy: json['energy'] ?? 50,
        xp: json['xp'] ?? 0,
        hints: json['hints'] ?? 3,
        gamesDone: json['gamesDone'] ?? 0,
        correct: json['correct'] ?? 0,
        wrong: json['wrong'] ?? 0,
        ads: json['ads'] ?? 0,
        bestSpeed: json['bestSpeed'] ?? 0,
        dailyDate: json['dailyDate'] ?? '',
        progresses: (json['progresses'] is Map)
            ? Map<String, int>.from((json['progresses'] as Map).map((k, v) => MapEntry(k.toString(), (v as num).toInt())))
            : <String, int>{},
        playedGames: Set<String>.from(json['playedGames'] ?? const []),
        achievements: Set<String>.from(json['achievements'] ?? const []),
      );
}

class LeagueRule {
  final String name;
  final int min;
  final double coin;
  final double xp;
  const LeagueRule(this.name, this.min, this.coin, this.xp);
}

const leagueRules = <LeagueRule>[
  LeagueRule('برنزی', 0, 1.00, 1.00),
  LeagueRule('نقره‌ای', 900, 1.15, 1.15),
  LeagueRule('طلایی', 2200, 1.35, 1.30),
  LeagueRule('الماسی', 4200, 1.60, 1.55),
  LeagueRule('افسانه‌ای', 7000, 1.90, 1.85),
];

class ChaleshinoRoot extends StatefulWidget {
  const ChaleshinoRoot({super.key});

  @override
  State<ChaleshinoRoot> createState() => _ChaleshinoRootState();
}

class _ChaleshinoRootState extends State<ChaleshinoRoot> {
  PlayerState state = PlayerState();
  String tab = 'home';
  GameDef? activeGame;
  int hearts = 3;
  int runCorrect = 0;
  int runWrong = 0;
  int lastCoins = 0;
  int lastXp = 0;
  int timeLeft = 0;
  int timeTotal = 1;
  int? selectedAnswer;
  bool hintShown = false;
  bool memoryPreview = false;
  bool speedIntro = false;
  String wordAnswer = '';
  final List<int> wordPicked = <int>[];
  int speedIndex = 0;
  int speedScore = 0;
  int speedWrong = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('chaleshino_flutter_v9_state') ?? prefs.getString('chaleshino_flutter_v8_state') ?? prefs.getString('chaleshino_flutter_v7_state') ?? prefs.getString('chaleshino_flutter_v6_state') ?? prefs.getString('chaleshino_flutter_v5_state');
    if (saved == null) return;
    try {
      setState(() => state = PlayerState.fromJson(jsonDecode(saved)));
    } catch (_) {}
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('chaleshino_flutter_v9_state', jsonEncode(state.toJson()));
  }

  LeagueRule get league {
    final score = state.xp + state.bestSpeed * 40 + state.correct * 10;
    var current = leagueRules.first;
    for (final l in leagueRules) {
      if (score >= l.min) current = l;
    }
    return current;
  }

  int _levelIndex(GameDef game) => (state.progresses[game.id] ?? 0) % game.levels.length;
  GameLevel _level(GameDef game) => game.levels[_levelIndex(game)];

  int _timeLimit(GameDef game, GameLevel level) {
    if (game.mode == 'speed') return 45;
    if (game.id == 'truefalse' || game.id == 'yesno') return 5;
    if (game.mode == 'memory') return level.difficulty == 'hard' ? 10 : 12;
    if (level.difficulty == 'easy') return 20;
    if (level.difficulty == 'medium') return 15;
    return 10;
  }

  int _baseCoin(GameLevel level) {
    switch (level.difficulty) {
      case 'hard':
        return 23;
      case 'medium':
        return 18;
      default:
        return 14;
    }
  }

  int _baseXp(GameLevel level) {
    switch (level.difficulty) {
      case 'hard':
        return 26;
      case 'medium':
        return 20;
      default:
        return 15;
    }
  }

  String _today() => DateTime.now().toIso8601String().substring(0, 10);

  void openTab(String next) {
    timer?.cancel();
    setState(() {
      tab = next;
      activeGame = null;
    });
  }

  void startGame(GameDef game) {
    if (state.energy < game.energy) {
      _toast('انرژی کافی نیست');
      return;
    }
    timer?.cancel();
    setState(() {
      state.energy -= game.energy;
      activeGame = game;
      tab = 'game';
      hearts = 3;
      runCorrect = 0;
      runWrong = 0;
      lastCoins = 0;
      lastXp = 0;
      selectedAnswer = null;
      hintShown = false;
      speedIntro = game.mode == 'speed';
      speedScore = 0;
      speedWrong = 0;
      speedIndex = 0;
    });
    _prepareLevel();
    _save();
  }

  void _prepareLevel() {
    final game = activeGame;
    if (game == null) return;
    final level = _level(game);
    timer?.cancel();
    setState(() {
      selectedAnswer = null;
      hintShown = false;
      wordAnswer = '';
      wordPicked.clear();
      memoryPreview = game.mode == 'memory';
      if (game.mode == 'speed') {
        timeTotal = 45;
        timeLeft = 45;
        speedIndex = speedIndex % game.levels.length;
      } else if (game.mode == 'memory') {
        timeTotal = 4;
        timeLeft = 4;
      } else {
        timeTotal = _timeLimit(game, level);
        timeLeft = timeTotal;
      }
    });
    if (game.mode == 'speed') {
      if (!speedIntro) _startTimer(_endSpeed);
    } else if (game.mode == 'memory') {
      _startTimer(_switchMemoryToAnswer);
    } else {
      _startTimer(() => _finishLevel(false));
    }
  }


  void _startSpeedRun() {
    final game = activeGame;
    if (game == null || game.mode != 'speed') return;
    timer?.cancel();
    setState(() {
      speedIntro = false;
      speedScore = 0;
      speedWrong = 0;
      selectedAnswer = null;
      speedIndex = 0;
      timeTotal = 45;
      timeLeft = 45;
    });
    _startTimer(_endSpeed);
  }

  void _startTimer(VoidCallback onExpire) {
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (timeLeft <= 1) {
        t.cancel();
        onExpire();
      } else {
        setState(() => timeLeft--);
      }
    });
  }

  void _switchMemoryToAnswer() {
    final game = activeGame;
    if (game == null || tab != 'game') return;
    final level = _level(game);
    setState(() {
      memoryPreview = false;
      timeTotal = _timeLimit(game, level);
      timeLeft = timeTotal;
    });
    _startTimer(() => _finishLevel(false));
  }

  void _choiceAnswer(int index) {
    final game = activeGame;
    if (game == null || selectedAnswer != null) return;
    final level = game.mode == 'speed' ? game.levels[speedIndex % game.levels.length] : _level(game);
    setState(() => selectedAnswer = index);
    Future.delayed(const Duration(milliseconds: 260), () {
      if (!mounted || tab != 'game') return;
      if (game.mode == 'speed') {
        _speedAnswer(index == level.answer);
      } else {
        _finishLevel(index == level.answer);
      }
    });
  }

  void _speedAnswer(bool ok) {
    final game = activeGame;
    if (game == null) return;
    setState(() {
      if (ok) {
        speedScore++;
      } else {
        speedWrong++;
      }
      selectedAnswer = null;
      speedIndex = (speedIndex + 1) % game.levels.length;
    });
  }

  void _endSpeed() {
    if (activeGame?.mode != 'speed') return;
    timer?.cancel();
    final earnedCoins = (speedScore * 12 * league.coin).round();
    final earnedXp = (speedScore * 15 * league.xp).round();
    setState(() {
      runCorrect = speedScore;
      runWrong = speedWrong;
      lastCoins = earnedCoins;
      lastXp = earnedXp;
      state.coins += earnedCoins;
      state.xp += earnedXp;
      state.correct += speedScore;
      state.wrong += speedWrong;
      state.bestSpeed = math.max(state.bestSpeed, speedScore);
      _completeGameStats(activeGame!.id);
      tab = 'result';
    });
    _save();
  }

  void _wordPick(int index) {
    final game = activeGame;
    if (game == null || game.mode != 'word') return;
    final level = _level(game);
    if (wordPicked.contains(index)) return;
    if (wordAnswer.length >= (level.word ?? '').length) return;
    setState(() {
      wordPicked.add(index);
      wordAnswer += level.letters[index];
    });
  }

  void _wordBackspace() {
    if (wordPicked.isEmpty) return;
    setState(() {
      wordPicked.removeLast();
      if (wordAnswer.isNotEmpty) wordAnswer = wordAnswer.substring(0, wordAnswer.length - 1);
    });
  }

  void _wordClear() {
    setState(() {
      wordPicked.clear();
      wordAnswer = '';
    });
  }

  String _norm(String s) => s.replaceAll('ي', 'ی').replaceAll('ك', 'ک').replaceAll('آ', 'ا').replaceAll(RegExp(r'\s+'), '').trim();

  void _wordSubmit() {
    final game = activeGame;
    if (game == null || game.mode != 'word') return;
    final level = _level(game);
    _finishLevel(_norm(wordAnswer) == _norm(level.word ?? ''));
  }

  void _useHint() {
    if (hintShown) return;
    if (state.hints <= 0) {
      _toast('راهنما نداری');
      return;
    }
    setState(() {
      state.hints--;
      hintShown = true;
    });
    _save();
  }

  void _finishLevel(bool ok) {
    final game = activeGame;
    if (game == null) return;
    timer?.cancel();
    final level = _level(game);
    final coinReward = (ok ? (_baseCoin(level) * league.coin).round() : 0);
    final xpReward = (ok ? (_baseXp(level) * league.xp).round() : 0);
    setState(() {
      if (ok) {
        runCorrect++;
        state.correct++;
        state.coins += coinReward;
        state.xp += xpReward;
        lastCoins += coinReward;
        lastXp += xpReward;
      } else {
        runWrong++;
        state.wrong++;
        hearts = math.max(0, hearts - 1);
      }
      state.progresses[game.id] = (state.progresses[game.id] ?? 0) + 1;
    });

    final played = runCorrect + runWrong;
    if (hearts <= 0 || played >= 5) {
      _showResult();
    } else {
      _prepareLevel();
    }
    _save();
  }

  void _showResult() {
    final game = activeGame;
    if (game == null) return;
    setState(() {
      _completeGameStats(game.id);
      tab = 'result';
    });
  }

  void _completeGameStats(String gameId) {
    state.gamesDone++;
    state.playedGames.add(gameId);
    if (state.gamesDone >= 3) state.achievements.add('۳ بازی انجام‌شده');
    if (state.correct >= 10) state.achievements.add('۱۰ جواب درست');
    if (state.xp >= 450) state.achievements.add('رسیدن به لیگ بعدی');
    if (state.playedGames.length >= 5) state.achievements.add('۵ بازی مختلف');
    if (state.bestSpeed >= 8) state.achievements.add('رکورد سرعتی');
  }

  void claimDaily() {
    final today = _today();
    if (state.dailyDate == today) {
      _toast('جایزه امروز قبلاً گرفته شده');
      return;
    }
    setState(() {
      state.dailyDate = today;
      state.coins += 130;
      state.energy += 10;
      state.achievements.add('دریافت جایزه روزانه');
    });
    _save();
    _toast('جایزه روزانه دریافت شد');
  }

  void watchAd() {
    setState(() {
      state.ads++;
      state.coins += 500;
      state.energy += 10;
      state.hints += 1;
      state.achievements.add('تماشای تبلیغ جایزه‌دار');
    });
    _save();
    _toast('۵۰۰ سکه، ۱۰ انرژی و ۱ راهنما اضافه شد');
  }

  void buy({int coins = 0, int energy = 0, int hints = 0}) {
    setState(() {
      state.coins += coins;
      state.energy += energy;
      state.hints += hints;
    });
    _save();
    _toast('بسته اضافه شد');
  }

  void _toast(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: AppColor.ink, fontWeight: FontWeight.w900)),
        backgroundColor: Colors.white,
        behavior: SnackBarBehavior.floating,
        elevation: 18,
        margin: const EdgeInsets.fromLTRB(34, 0, 34, 104),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: AppColor.cyan.withOpacity(.16))),
        duration: const Duration(milliseconds: 1100),
      ),
    );
  }

  Widget _page() {
    switch (tab) {
      case 'shop':
        return ShopPage(state: state, onBuy: buy, onAd: watchAd);
      case 'rewards':
        return RewardsPage(state: state, onDaily: claimDaily, onAd: watchAd);
      case 'league':
        return LeaguePage(state: state, league: league);
      case 'profile':
        return ProfilePage(state: state);
      case 'game':
        final game = activeGame ?? games.first;
        final level = game.mode == 'speed' ? game.levels[speedIndex % game.levels.length] : _level(game);
        return GamePage(
          game: game,
          level: level,
          levelNumber: game.mode == 'speed' ? speedIndex + 1 : _levelIndex(game) + 1,
          totalLevels: game.levels.length,
          hearts: hearts,
          correct: runCorrect,
          wrong: runWrong,
          timeLeft: timeLeft,
          timeTotal: timeTotal,
          selectedAnswer: selectedAnswer,
          hintShown: hintShown,
          memoryPreview: memoryPreview,
          wordAnswer: wordAnswer,
          wordPicked: wordPicked,
          speedScore: speedScore,
          speedWrong: speedWrong,
          speedIntro: speedIntro,
          onSpeedStart: _startSpeedRun,
          onBack: () => openTab('home'),
          onChoice: _choiceAnswer,
          onWordLetter: _wordPick,
          onWordBack: _wordBackspace,
          onWordClear: _wordClear,
          onWordSubmit: _wordSubmit,
          onHint: _useHint,
        );
      case 'result':
        return ResultPage(game: activeGame ?? games.first, correct: runCorrect, wrong: runWrong, coins: lastCoins, xp: lastXp, onHome: () => openTab('home'), onReplay: () => startGame(activeGame ?? games.first), onAd: watchAd);
      default:
        return HomePage(state: state, onStart: startGame, onAd: watchAd);
    }
  }

  @override
  Widget build(BuildContext context) {
    final showNav = tab != 'game' && tab != 'result';
    return Scaffold(
      backgroundColor: AppColor.bg,
      bottomNavigationBar: showNav ? HtmlBottomNav(active: tab, onTap: openTab) : null,
      body: HtmlBackground(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Column(
              children: [
                SafeArea(bottom: false, child: TopBar(state: state, onProfile: () => openTab('profile'))),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 160),
                    child: ListView(
                      key: ValueKey(tab),
                      padding: EdgeInsets.fromLTRB(16, tab == 'home' ? 6 : 14, 16, showNav ? 26 : 20),
                      children: [_page()],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HtmlBackground extends StatelessWidget {
  final Widget child;
  const HtmlBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFEAF1FA), Color(0xFFF8FBFF), Color(0xFFECE7FF)], stops: [0, .52, 1]),
      ),
      child: Stack(
        children: [
          Positioned(top: -78, right: -74, child: CircleBlob(size: 238, color: AppColor.primary.withOpacity(.18))),
          Positioned(top: 50, left: -92, child: CircleBlob(size: 220, color: AppColor.cyan.withOpacity(.19))),
          Positioned(bottom: -118, left: 76, child: CircleBlob(size: 270, color: AppColor.orange.withOpacity(.16))),
          CustomPaint(painter: HtmlGridPainter(), size: Size.infinite),
          child,
        ],
      ),
    );
  }
}

class CircleBlob extends StatelessWidget {
  final double size;
  final Color color;
  const CircleBlob({super.key, required this.size, required this.color});
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: BoxDecoration(color: color, shape: BoxShape.circle));
}

class HtmlGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p1 = Paint()..color = AppColor.primary.withOpacity(.034)..strokeWidth = 1;
    final p2 = Paint()..color = AppColor.cyan.withOpacity(.030)..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 34) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p1);
    }
    for (double x = 0; x < size.width; x += 34) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p2);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class TopBar extends StatelessWidget {
  final PlayerState state;
  final VoidCallback onProfile;
  const TopBar({super.key, required this.state, required this.onProfile});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                HtmlIconBox(icon: 'brain', size: 52, radius: 20, colors: const [Color(0xFF6EE7F9), Color(0xFF675CFF), Color(0xFFFFC85A)], iconColor: Colors.white),
                const SizedBox(width: 10),
                const Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('چالشینو', style: TextStyle(fontSize: 24, height: 1.05, fontWeight: FontWeight.w900, color: AppColor.ink)),
                      SizedBox(height: 4),
                      Text('نسخه حرفه‌ای v10', style: TextStyle(fontSize: 11, color: Color(0xFF6D7893), fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Wrap(
            textDirection: TextDirection.ltr,
            spacing: 7,
            runSpacing: 7,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              GestureDetector(onTap: onProfile, child: HtmlIconBox(icon: 'profile', size: 44, radius: 18, colors: const [Colors.white, Color(0xFFEFFBFF)], iconColor: AppColor.primary)),
              WalletPill(icon: 'energy', value: state.energy.toString()),
              WalletPill(icon: 'coin', value: state.coins.toString()),
            ],
          ),
        ],
      ),
    );
  }
}

class WalletPill extends StatelessWidget {
  final String icon;
  final String value;
  const WalletPill({super.key, required this.icon, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFFFFFFF), Color(0xFFF6FBFF), Color(0xFFEAF3FF)]),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white.withOpacity(.82), width: 1.15),
        boxShadow: htmlShadow(opacity: .13, blur: 26, offset: const Offset(0, 12)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [HtmlSvgIcon(icon, size: 19, color: icon == 'coin' ? AppColor.orange : AppColor.primary), const SizedBox(width: 7), Text(value, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900, color: AppColor.ink))]),
    );
  }
}

class HomePage extends StatelessWidget {
  final PlayerState state;
  final ValueChanged<GameDef> onStart;
  final VoidCallback onAd;
  const HomePage({super.key, required this.state, required this.onStart, required this.onAd});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SizedBox(
        height: 116,
        child: ListView(
          scrollDirection: Axis.horizontal,
          reverse: true,
          padding: const EdgeInsets.only(bottom: 10),
          children: [
            HomeAdCard(title: 'تبلیغ ویدئویی جایزه‌دار', subtitle: 'Placement واقعی ثبت شد؛ در HTML فعلاً شبیه‌سازی می‌شود.', icon: 'ad', action: 'تماشا', onTap: onAd),
            const SizedBox(width: 12),
            const HomeAdCard(title: 'تبلیغ بنری', subtitle: 'جایگاه بنری واقعی برای نسخه اندروید آماده شد.', icon: 'gift'),
            const SizedBox(width: 12),
            const HomeAdCard(title: 'بنر دوم تستی', subtitle: 'اسکرول افقی بنرها برای اتصال SDK حفظ شد.', icon: 'star'),
          ],
        ),
      ),
      GamesFrame(onStart: onStart),
      const SizedBox(height: 12),
      const SectionTitle(title: 'مسیر امروز', hint: 'مأموریت روزانه'),
      MissionProgressCard(title: '۳ بازی انجام بده', subtitle: '${state.gamesDone.clamp(0, 3)}/3 بازی ثبت شده', value: (state.gamesDone / 3).clamp(0, 1).toDouble(), icon: 'target', c1: AppColor.green, c2: AppColor.cyan),
      const SizedBox(height: 12),
      MissionProgressCard(title: '۱۰ جواب درست', subtitle: '${state.correct.clamp(0, 10)}/10 جواب درست', value: (state.correct / 10).clamp(0, 1).toDouble(), icon: 'brain', c1: AppColor.orange, c2: AppColor.danger),
    ]);
  }
}

class HomeAdCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final String? action;
  final VoidCallback? onTap;
  const HomeAdCard({super.key, required this.title, required this.subtitle, required this.icon, this.action, this.onTap});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: action == null ? 260 : 306,
      padding: const EdgeInsets.all(14),
      decoration: htmlCard(colors: const [Color(0xFFFFF5DA), Color(0xFFFFFFFF), Color(0xFFE8FBFF)], radius: 30, border: Colors.white70, shadowOpacity: .18),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 46, radius: 17, colors: const [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Colors.white),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, color: AppColor.ink, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.3, color: Color(0xFF60708B), fontWeight: FontWeight.w800, height: 1.55))])),
        if (action != null) ...[const SizedBox(width: 8), HtmlButton(label: action!, onTap: onTap ?? () {}, color1: AppColor.green, color2: AppColor.cyan, compact: true)],
      ]),
    );
  }
}

class GamesFrame extends StatelessWidget {
  final ValueChanged<GameDef> onStart;
  const GamesFrame({super.key, required this.onStart});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: -2),
      padding: const EdgeInsets.fromLTRB(6, 10, 6, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white.withOpacity(.52), const Color(0xFFEEF8FF).withOpacity(.38), const Color(0xFFFFF7EA).withOpacity(.22)]),
        borderRadius: BorderRadius.circular(34),
        border: Border.all(color: Colors.white.withOpacity(.72)),
        boxShadow: htmlShadow(opacity: .10, blur: 32, offset: const Offset(0, 14)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SectionTitle(title: 'بازی‌ها', hint: 'اسکرول کن'),
        SizedBox(
          height: 222,
          child: ListView.separated(
            reverse: true,
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(8, 2, 8, 7),
            itemCount: games.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) => GameCard(game: games[index], onTap: () => onStart(games[index])),
          ),
        ),
      ]),
    );
  }
}

class GameCard extends StatelessWidget {
  final GameDef game;
  final VoidCallback onTap;
  const GameCard({super.key, required this.game, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 226,
        padding: const EdgeInsets.all(16),
        decoration: htmlCard(colors: const [Color(0xFFFFFFFF), Color(0xFFF4FBFF), Color(0xFFF6F1FF)], radius: 30, border: Colors.white70, shadowOpacity: .18),
        child: Stack(children: [
          Positioned(left: -34, bottom: -48, child: CircleBlob(size: 132, color: game.c1.withOpacity(.18))),
          Positioned.fill(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                HtmlIconBox(icon: game.icon, size: 56, radius: 21, colors: [game.c1, game.c2], iconColor: Colors.white),
                MiniChip(text: game.mode == 'speed' ? 'رکوردی' : 'ادامه'),
              ]),
              const SizedBox(height: 8),
              Text(game.title, style: const TextStyle(fontSize: 17.5, height: 1.35, fontWeight: FontWeight.w900, color: AppColor.ink)),
              const SizedBox(height: 5),
              Text(game.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.2, height: 1.6, fontWeight: FontWeight.w700, color: AppColor.muted)),
              const SizedBox(height: 8),
              HtmlProgress(value: .28, colors: [game.c1, game.c2], height: 8),
              const Spacer(),
              Row(children: [MiniChip(text: '${game.energy} انرژی'), const SizedBox(width: 6), const MiniChip(text: 'لیگ برنزی')]),
            ]),
          ),
        ]),
      ),
    );
  }
}

class RewardsPage extends StatelessWidget {
  final PlayerState state;
  final VoidCallback onDaily;
  final VoidCallback onAd;
  const RewardsPage({super.key, required this.state, required this.onDaily, required this.onAd});
  @override
  Widget build(BuildContext context) {
    final claimed = state.dailyDate == DateTime.now().toIso8601String().substring(0, 10);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'جایزه‌ها و مأموریت‌ها', subtitle: 'مأموریت‌های روزانه و هفتگی با لیگ فعلی هماهنگ شده‌اند.', icon: 'gift'),
      const SizedBox(height: 14),
      QuestCard(title: 'جایزه روزانه', subtitle: claimed ? 'جایزه امروز دریافت شده است.' : '۱۳۰ سکه؛ با تبلیغ دو برابر می‌شود.', icon: 'gift', c1: AppColor.orange, c2: AppColor.danger, button: claimed ? 'دریافت شد' : 'دریافت', onTap: onDaily),
      const SizedBox(height: 14),
      const SectionTitle(title: 'مأموریت‌های روزانه', hint: 'امروز'),
      MissionProgressCard(title: '۳ مرحله امروز', subtitle: 'امروز ۳ مرحله کامل کن و پاداش بگیر.', value: (state.gamesDone / 3).clamp(0, 1).toDouble(), icon: 'target', c1: AppColor.green, c2: AppColor.cyan),
      const SizedBox(height: 12),
      MissionProgressCard(title: '۳ بازی مختلف', subtitle: '${state.playedGames.length.clamp(0, 3)}/3 بازی مختلف انجام شده.', value: (state.playedGames.length / 3).clamp(0, 1).toDouble(), icon: 'brain', c1: AppColor.cyan, c2: AppColor.green),
      const SizedBox(height: 12),
      QuestCard(title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه + ۱۰ انرژی تستی', icon: 'ad', c1: AppColor.primary, c2: AppColor.cyan, button: 'تماشا', onTap: onAd),
    ]);
  }
}

class ShopPage extends StatelessWidget {
  final PlayerState state;
  final void Function({int coins, int energy, int hints}) onBuy;
  final VoidCallback onAd;
  const ShopPage({super.key, required this.state, required this.onBuy, required this.onAd});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'فروشگاه چالشینو', subtitle: 'بسته‌های سکه و آیتم‌های بازی برای تست اقتصاد داخلی اضافه شدند.', icon: 'shop'),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: ShopStat(value: state.coins.toString(), label: 'سکه')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.energy.toString(), label: 'انرژی')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.hints.toString(), label: 'راهنما'))]),
      const SectionTitle(title: 'بسته‌های سکه', hint: 'اسکرول افقی'),
      SizedBox(
        height: 176,
        child: ListView(scrollDirection: Axis.horizontal, reverse: true, children: [
          ProductTile(title: '۱۰۰۰ سکه', subtitle: 'بسته شروع', icon: 'coin', c1: AppColor.orange, c2: const Color(0xFFFF9F43), onTap: () => onBuy(coins: 1000)),
          ProductTile(title: '۵۰ انرژی', subtitle: 'برای بازی بیشتر', icon: 'energy', c1: AppColor.cyan, c2: AppColor.primary, onTap: () => onBuy(energy: 50)),
          ProductTile(title: '۵ راهنما', subtitle: 'کمک داخل بازی', icon: 'riddle', c1: AppColor.green, c2: AppColor.cyan, onTap: () => onBuy(hints: 5)),
          ProductTile(title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه رایگان', icon: 'ad', c1: AppColor.primary, c2: AppColor.orange, onTap: onAd),
        ]),
      ),
      const SizedBox(height: 12),
      const HtmlNote(text: 'پرداخت واقعی در نسخه مارکتی فعال می‌شود. این بخش فعلاً تستی است.'),
    ]);
  }
}

class LeaguePage extends StatelessWidget {
  final PlayerState state;
  final LeagueRule league;
  const LeaguePage({super.key, required this.state, required this.league});
  @override
  Widget build(BuildContext context) {
    final next = leagueRules.firstWhere((l) => l.min > (state.xp + state.bestSpeed * 40 + state.correct * 10), orElse: () => leagueRules.last);
    final value = next == league ? 1.0 : ((state.xp + state.bestSpeed * 40 + state.correct * 10) / next.min).clamp(0, 1).toDouble();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      MiniHero(title: 'لیگ ${league.name}', subtitle: 'تا لیگ بعدی: XP ${next.min}', icon: 'medal', trailing: 'XP ${state.xp}'),
      const SizedBox(height: 12),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: htmlCard(colors: const [Color(0xFFFFF9E8), Colors.white, Color(0xFFF5FBFF)], radius: 30, border: AppColor.orange.withOpacity(.18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [const HtmlIconBox(icon: 'medal', size: 60, radius: 22, colors: [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Colors.white), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('لیگ فعلی تو: ${league.name}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 6), Text('پاداش سکه ×${league.coin} • XP ×${league.xp}', style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))]))]),
          const SizedBox(height: 16),
          HtmlProgress(value: value, colors: const [AppColor.orange, AppColor.cyan]),
        ]),
      ),
      const SectionTitle(title: 'رتبه‌بندی کامل', hint: 'نمونه تستی'),
      RankRow(name: 'بازیکن چالشینو', score: state.xp, active: true),
      const RankRow(name: 'هانا', score: 390),
      const RankRow(name: 'آرمان', score: 310),
      const RankRow(name: 'سارا', score: 280),
    ]);
  }
}

class ProfilePage extends StatelessWidget {
  final PlayerState state;
  const ProfilePage({super.key, required this.state});
  @override
  Widget build(BuildContext context) {
    final success = state.correct + state.wrong == 0 ? 0 : ((state.correct / (state.correct + state.wrong)) * 100).round();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'پروفایل کامل‌تر', subtitle: 'آمار، تنظیمات و دستاوردها', icon: 'profile'),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: ShopStat(value: state.gamesDone.toString(), label: 'بازی')), const SizedBox(width: 8), Expanded(child: ShopStat(value: '$success%', label: 'موفقیت')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.bestSpeed.toString(), label: 'رکورد سرعت'))]),
      const SectionTitle(title: 'دستاوردها', hint: 'مدال‌ها'),
      if (state.achievements.isEmpty) const HtmlNote(text: 'هنوز مدالی نگرفتی. چند بازی انجام بده تا مدال‌ها فعال شوند.') else ...state.achievements.map((a) => Padding(padding: const EdgeInsets.only(bottom: 10), child: QuestCard(title: a, subtitle: 'دستاورد فعال شده', icon: 'star', c1: AppColor.orange, c2: AppColor.primary, button: 'فعال', onTap: () {}))),
      const SectionTitle(title: 'تنظیمات بازی', hint: 'تستی'),
      const SettingsLikeCard(title: 'صدا', subtitle: 'برای نسخه Flutter به صداهای بازی وصل می‌شود.'),
      const SizedBox(height: 10),
      const SettingsLikeCard(title: 'لرزش', subtitle: 'برای لمس‌ها و جواب درست/غلط در موبایل.'),
    ]);
  }
}


class GamePage extends StatelessWidget {
  final GameDef game;
  final GameLevel level;
  final int levelNumber;
  final int totalLevels;
  final int hearts;
  final int correct;
  final int wrong;
  final int timeLeft;
  final int timeTotal;
  final int? selectedAnswer;
  final bool hintShown;
  final bool memoryPreview;
  final String wordAnswer;
  final List<int> wordPicked;
  final int speedScore;
  final int speedWrong;
  final bool speedIntro;
  final VoidCallback onSpeedStart;
  final VoidCallback onBack;
  final ValueChanged<int> onChoice;
  final ValueChanged<int> onWordLetter;
  final VoidCallback onWordBack;
  final VoidCallback onWordClear;
  final VoidCallback onWordSubmit;
  final VoidCallback onHint;

  const GamePage({
    super.key,
    required this.game,
    required this.level,
    required this.levelNumber,
    required this.totalLevels,
    required this.hearts,
    required this.correct,
    required this.wrong,
    required this.timeLeft,
    required this.timeTotal,
    required this.selectedAnswer,
    required this.hintShown,
    required this.memoryPreview,
    required this.wordAnswer,
    required this.wordPicked,
    required this.speedScore,
    required this.speedWrong,
    required this.speedIntro,
    required this.onSpeedStart,
    required this.onBack,
    required this.onChoice,
    required this.onWordLetter,
    required this.onWordBack,
    required this.onWordClear,
    required this.onWordSubmit,
    required this.onHint,
  });

  bool get isSpeed => game.mode == 'speed';
  bool get isWord => game.mode == 'word';
  bool get isMemory => game.mode == 'memory';

  String get _description {
    if (isSpeed) return speedIntro ? 'برای شروع ۲ انرژی مصرف می‌شود.' : 'بازی ثابت و سریع | رکورد $speedScore';
    if (game.id == 'yesno') return 'سؤال کوتاه را در ۵ ثانیه با بله یا خیر جواب بده.';
    if (game.id == 'truefalse') return 'جمله را بخوان و سریع درست یا غلط را انتخاب کن.';
    if (game.id == 'image') return 'با چند نشانه تصویری جواب درست را از بین گزینه‌ها انتخاب کن.';
    if (isWord) return 'کلمه را از حروف به‌هم‌ریخته بساز.';
    if (isMemory) return memoryPreview ? 'آیتم‌ها را به خاطر بسپار.' : 'آیتم درست را انتخاب کن.';
    return 'سؤال‌های کوتاه و فکری با انتخاب جواب.';
  }

  int get _baseCoin {
    switch (level.difficulty) {
      case 'hard': return 23;
      case 'medium': return 16;
      default: return 10;
    }
  }

  int get _energyCost {
    if (isSpeed) return 2;
    if (level.difficulty == 'hard') return 2;
    return 1;
  }

  @override
  Widget build(BuildContext context) {
    if (isSpeed && speedIntro) return _speedIntroPage();
    if (isSpeed) return _speedRunPage();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _htmlGameHeader(),
      const SizedBox(height: 10),
      _htmlStagePanel(),
    ]);
  }

  Widget _htmlGameHeader({String? leadingLabel}) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: htmlCard(colors: const [Color(0xFFFFFFFF), Color(0xFFF7FBFF), Color(0xFFEFF2FF)], radius: 28, border: Colors.white70, shadowOpacity: .15),
      child: Row(children: [
        MiniChip(text: leadingLabel ?? (isSpeed ? 'رکورد ${speedScore > 0 ? speedScore : 23}' : '$levelNumber/$totalLevels')),
        const Spacer(),
        Expanded(
          flex: 4,
          child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Row(mainAxisAlignment: MainAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
              Text(game.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 18, color: AppColor.ink, fontWeight: FontWeight.w900)),
              const SizedBox(width: 7),
              HtmlSvgIcon(game.icon, size: 20, color: AppColor.ink),
            ]),
            const SizedBox(height: 3),
            Text(_description, textAlign: TextAlign.right, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, color: AppColor.muted, fontWeight: FontWeight.w800)),
          ]),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: onBack,
          child: Container(width: 52, height: 52, decoration: htmlCard(colors: const [Colors.white, Color(0xFFEFFBFF)], radius: 19, border: AppColor.cyan.withOpacity(.17), shadowOpacity: .13), child: const Center(child: Text('←', style: TextStyle(fontSize: 24, color: AppColor.ink, fontWeight: FontWeight.w900)))),
        ),
      ]),
    );
  }

  Widget _htmlStagePanel() {
    return Container(
      constraints: const BoxConstraints(minHeight: 650),
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
      decoration: htmlCard(colors: const [Color(0xFFFFFFFF), Color(0xFFF9FCFF), Color(0xFFFFF8ED)], radius: 34, border: Colors.white70, shadowOpacity: .18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _stageTopRow(),
        const SizedBox(height: 14),
        _infoStatsRow(),
        const SizedBox(height: 12),
        _timerRow(label: _timerLabel()),
        const SizedBox(height: 14),
        if (isWord) _wordExactBody() else if (isMemory) _memoryExactBody() else if (game.id == 'image') _imageExactBody() else _choiceExactBody(),
        if (hintShown) ...[
          const SizedBox(height: 8),
          HtmlNote(text: 'راهنما: ${level.hint}'),
        ],
        const SizedBox(height: 12),
        _actionButtons(),
        const SizedBox(height: 12),
        _stageChips(),
      ]),
    );
  }

  Widget _stageTopRow() {
    final heartsRow = Row(mainAxisSize: MainAxisSize.min, children: List.generate(3, (i) => Padding(padding: const EdgeInsets.only(left: 8), child: Icon(Icons.favorite, size: 26, color: i < hearts ? AppColor.danger : AppColor.danger.withOpacity(.22)))));
    return Row(children: [
      heartsRow,
      const Spacer(),
      MiniChip(text: 'مرحله $levelNumber'),
    ]);
  }

  Widget _infoStatsRow() {
    return Row(children: [
      Expanded(child: _infoStat(value: _energyCost.toString(), label: 'انرژی')),
      const SizedBox(width: 8),
      Expanded(child: _infoStat(value: _baseCoin.toString(), label: 'سکه پایه')),
      const SizedBox(width: 8),
      Expanded(child: _infoStat(value: _difficultyText(level.difficulty), label: 'سختی')),
    ]);
  }

  String _difficultyText(String v) {
    if (v == 'hard') return 'سخت';
    if (v == 'medium') return 'متوسط';
    return 'آسان';
  }

  Widget _infoStat({required String value, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 13),
      decoration: htmlCard(colors: const [Color(0xFFFFFFFF), Color(0xFFF4FBFF), Color(0xFFEEF6FF)], radius: 21, border: Colors.white70, shadowOpacity: .10),
      child: Column(children: [
        Text(value, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, color: AppColor.ink, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        Text(label, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, color: AppColor.muted, fontWeight: FontWeight.w800)),
      ]),
    );
  }

  String _timerLabel() {
    if (game.id == 'yesno' || game.id == 'truefalse') return 'زمان هر سؤال';
    if (isWord) return 'زمان حدس کلمه';
    if (game.id == 'image') return 'زمان معمای تصویری';
    if (isMemory) return memoryPreview ? 'زمان نمایش' : 'زمان حافظه';
    return 'زمان ${game.title}';
  }

  Widget _timerRow({required String label}) {
    final value = timeTotal <= 0 ? 0.0 : (timeLeft / timeTotal).clamp(0.0, 1.0).toDouble();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
      decoration: htmlCard(colors: const [Color(0xFFFFFFFF), Color(0xFFF5FCFF), Color(0xFFFFF6E8)], radius: 23, border: Colors.white70, shadowOpacity: .11),
      child: Row(children: [
        Text(timeLeft.toString(), style: const TextStyle(fontSize: 22, color: AppColor.ink, fontWeight: FontWeight.w900)),
        const SizedBox(width: 12),
        Expanded(child: HtmlProgress(value: value, colors: const [AppColor.green, AppColor.cyan, AppColor.orange, AppColor.danger], height: 10)),
        const SizedBox(width: 12),
        Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w900))),
      ]),
    );
  }

  Widget _questionBox(String text, {double fontSize = 20}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 18),
      decoration: htmlCard(colors: const [Color(0xFFF9FCFF), Color(0xFFF7F1FF), Color(0xFFFFF7EB)], radius: 26, border: Colors.white70, shadowOpacity: .12),
      child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: fontSize + 1, height: 1.62, fontWeight: FontWeight.w900, color: AppColor.ink)),
    );
  }

  Widget _choiceExactBody() {
    final two = level.options.length == 2;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _questionBox(level.q),
      const SizedBox(height: 12),
      _choiceGrid(height: two ? 68 : 62, fontSize: two ? 18 : 16),
    ]);
  }

  Widget _choiceGrid({double height = 62, double fontSize = 16}) {
    return LayoutBuilder(builder: (context, constraints) {
      final itemWidth = (constraints.maxWidth - 12) / 2;
      return Wrap(
        spacing: 12,
        runSpacing: 12,
        children: List.generate(level.options.length, (i) => SizedBox(width: itemWidth, height: height, child: _choiceButton(i, level.options[i], fontSize: fontSize))),
      );
    });
  }

  Widget _choiceButton(int index, String text, {double fontSize = 16}) {
    final selected = selectedAnswer == index;
    final isGood = selected && index == level.answer;
    final isBad = selected && index != level.answer;
    final colors = isGood ? const [Color(0xFFE4FFF5), Color(0xFFF5FFFC)] : isBad ? const [Color(0xFFFFEDF3), Color(0xFFFFF8FB)] : const [Colors.white, Color(0xFFF3FAFF), Color(0xFFF6F2FF)];
    return GestureDetector(
      onTap: selectedAnswer == null ? () => onChoice(index) : null,
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: htmlCard(colors: colors, radius: 21, border: isGood ? AppColor.green.withOpacity(.42) : isBad ? AppColor.danger.withOpacity(.42) : Colors.white70, shadowOpacity: selected ? .13 : .10),
        child: Text(text, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: fontSize, height: 1.35, fontWeight: FontWeight.w900, color: isBad ? AppColor.danger : isGood ? AppColor.green : AppColor.ink)),
      ),
    );
  }

  Widget _imageExactBody() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Container(
        padding: const EdgeInsets.all(14),
        decoration: htmlCard(colors: const [Color(0xFFF6FBFF), Color(0xFFF8F1FF), Color(0xFFFFF8EF)], radius: 22, border: AppColor.primary.withOpacity(.12), shadowOpacity: .08),
        child: Column(children: [
          Wrap(spacing: 12, runSpacing: 12, alignment: WrapAlignment.center, children: List.generate(level.items.isEmpty ? 2 : level.items.length, (i) {
            final label = level.items.isEmpty ? 'نشانه' : level.items[i];
            final icon = i.isEven ? 'trophy' : 'coin';
            return Container(width: 82, height: 82, padding: const EdgeInsets.all(10), decoration: htmlCard(colors: const [Colors.white, Color(0xFFEFFBFF), Color(0xFFFFF8E8)], radius: 20, border: AppColor.cyan.withOpacity(.16), shadowOpacity: .08), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [HtmlSvgIcon(icon, size: 28, color: i.isEven ? AppColor.orange : AppColor.cyan), const SizedBox(height: 7), Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, color: AppColor.ink, fontWeight: FontWeight.w900))]));
          })),
        ]),
      ),
      const SizedBox(height: 12),
      _choiceGrid(height: 62, fontSize: 15.5),
      const SizedBox(height: 10),
      const HtmlNote(text: 'برای جواب‌های بلند، تایپ حذف شده و جواب با گزینه انتخاب می‌شود.'),
    ]);
  }

  Widget _wordExactBody() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _questionBox(level.q),
      const SizedBox(height: 10),
      Wrap(alignment: WrapAlignment.center, spacing: 10, runSpacing: 8, children: level.letters.map((x) => Container(width: 42, height: 42, alignment: Alignment.center, decoration: htmlCard(colors: const [Colors.white, Color(0xFFFFF2D8)], radius: 15, border: AppColor.orange.withOpacity(.26), shadowOpacity: .08), child: Text(x, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppColor.ink)))).toList()),
      const SizedBox(height: 12),
      Row(children: [
        SizedBox(width: 76, height: 58, child: HtmlButton(label: 'ثبت', onTap: onWordSubmit, color1: AppColor.primary, color2: AppColor.violet, compact: true)),
        const SizedBox(width: 8),
        Expanded(child: Container(height: 58, alignment: Alignment.center, padding: const EdgeInsets.symmetric(horizontal: 12), decoration: htmlCard(colors: const [Colors.white, Color(0xFFF6FBFF)], radius: 20, border: AppColor.cyan.withOpacity(.14), shadowOpacity: .08), child: Text(wordAnswer.isEmpty ? 'جواب را با کیبورد بازی بساز...' : wordAnswer, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, color: AppColor.ink, fontWeight: FontWeight.w900)))),
      ]),
      const SizedBox(height: 12),
      Container(
        padding: const EdgeInsets.all(10),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF6FBFF), Color(0xFFFFF7EC)], radius: 20, border: AppColor.cyan.withOpacity(.13), shadowOpacity: .08),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: const [Expanded(child: Text('هر حرف فقط یک‌بار قابل استفاده است', style: TextStyle(fontSize: 11.5, color: AppColor.muted, fontWeight: FontWeight.w800))), Text('حروف همین مرحله', style: TextStyle(fontSize: 11.5, color: AppColor.ink, fontWeight: FontWeight.w900))]),
          const SizedBox(height: 9),
          LayoutBuilder(builder: (context, constraints) {
            final w = (constraints.maxWidth - 14) / 3;
            return Wrap(spacing: 7, runSpacing: 7, alignment: WrapAlignment.center, children: List.generate(level.letters.length, (i) {
              final used = wordPicked.contains(i);
              return SizedBox(width: w, height: 46, child: GestureDetector(
                onTap: used ? null : () => onWordLetter(i),
                child: Opacity(opacity: used ? .36 : 1, child: Container(alignment: Alignment.center, decoration: htmlCard(colors: const [Colors.white, Color(0xFFF3FAFF)], radius: 15, border: AppColor.primary.withOpacity(.10), shadowOpacity: .07), child: Text(level.letters[i], style: const TextStyle(fontSize: 17, color: AppColor.ink, fontWeight: FontWeight.w900)))),
              ));
            }));
          }),
          const SizedBox(height: 9),
          Row(children: [Expanded(child: HtmlButton(label: 'پاک', onTap: onWordClear, color1: AppColor.orange, color2: AppColor.orange, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'حذف', onTap: onWordBack, color1: AppColor.orange, color2: AppColor.danger, compact: true))]),
        ]),
      ),
    ]);
  }

  Widget _memoryExactBody() {
    if (memoryPreview) {
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _questionBox('این آیتم‌ها را به خاطر بسپار'),
        const SizedBox(height: 12),
        Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: level.items.map((x) => MiniChip(text: x)).toList()),
        const SizedBox(height: 12),
        const HtmlNote(text: 'بعد از پایان زمان، آیتم‌ها مخفی می‌شوند.'),
      ]);
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _questionBox(level.q),
      const SizedBox(height: 12),
      _choiceGrid(height: 62, fontSize: 15.5),
    ]);
  }

  Widget _actionButtons() {
    return Row(children: [
      Expanded(child: _softAction(label: 'ادامه', icon: 'heart', onTap: onBack)),
      const SizedBox(width: 8),
      Expanded(child: _softAction(label: 'رد با تبلیغ', icon: 'play', onTap: onBack)),
      const SizedBox(width: 8),
      Expanded(child: _softAction(label: 'راهنما ۲۵', icon: 'hint', onTap: onHint)),
    ]);
  }

  Widget _softAction({required String label, required String icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 52,
        alignment: Alignment.center,
        decoration: htmlCard(colors: const [Color(0xFFFFFFFF), Color(0xFFF3FAFF), Color(0xFFF7F0FF)], radius: 18, border: Colors.white70, shadowOpacity: .11),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text(label, style: const TextStyle(fontSize: 11.8, color: AppColor.ink, fontWeight: FontWeight.w900)), const SizedBox(width: 6), HtmlSvgIcon(icon, size: 18, color: AppColor.ink)]),
      ),
    );
  }

  Widget _stageChips() {
    final chips = <int>[];
    final start = (levelNumber - 4).clamp(1, totalLevels).toInt();
    for (int i = 0; i < 9; i++) {
      final v = start + i;
      if (v <= totalLevels) chips.add(v);
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: htmlCard(colors: const [Color(0xFFF6F8FF), Color(0xFFF8F2FF)], radius: 22, border: Colors.white70, shadowOpacity: .09),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        reverse: true,
        child: Row(children: chips.map((n) {
          final current = n == levelNumber;
          final done = n < levelNumber;
          return Container(
            width: 42,
            height: 42,
            margin: const EdgeInsets.symmetric(horizontal: 3),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: current ? AppColor.primary : done ? const Color(0xFFD9FFF0) : Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: current ? AppColor.violet.withOpacity(.45) : AppColor.primary.withOpacity(.10)),
              boxShadow: htmlShadow(opacity: .05),
            ),
            child: Text('$n', style: TextStyle(fontSize: 14, color: current ? Colors.white : done ? AppColor.green : AppColor.muted.withOpacity(.65), fontWeight: FontWeight.w900)),
          );
        }).toList()),
      ),
    );
  }

  Widget _speedIntroPage() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _htmlGameHeader(leadingLabel: 'رکورد 23'),
      const SizedBox(height: 10),
      Container(
        constraints: const BoxConstraints(minHeight: 670),
        padding: const EdgeInsets.fromLTRB(20, 46, 20, 30),
        decoration: htmlCard(colors: const [Color(0xFFFFFFFF), Color(0xFFF9FCFF), Color(0xFFF5F1FF)], radius: 36, border: Colors.white70, shadowOpacity: .18),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [MiniChip(text: '+XP'), const SizedBox(width: 10), MiniChip(text: '۴۵ ث'),]),
          const SizedBox(height: 24),
          SizedBox(
            width: 150,
            height: 150,
            child: Stack(alignment: Alignment.center, children: [
              CircularProgressIndicator(value: 1, strokeWidth: 11, color: AppColor.cyan, backgroundColor: AppColor.cyan.withOpacity(.12)),
              Column(mainAxisSize: MainAxisSize.min, children: const [Text('45', style: TextStyle(fontSize: 42, color: AppColor.ink, fontWeight: FontWeight.w900)), SizedBox(height: 3), Text('ثانیه', style: TextStyle(fontSize: 13, color: AppColor.muted, fontWeight: FontWeight.w800))]),
            ]),
          ),
          const SizedBox(height: 28),
          const Text('چالش سرعتی حرفه‌ای', textAlign: TextAlign.center, style: TextStyle(fontSize: 25, color: AppColor.ink, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          const Text('سؤال‌های سریع، امتیاز لحظه‌ای، ثبت رکورد و ورود مستقیم به لیگ هفتگی.', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, height: 1.9, color: AppColor.muted, fontWeight: FontWeight.w800)),
          const SizedBox(height: 30),
          HtmlButton(label: 'شروع چالش سرعتی', onTap: onSpeedStart, color1: AppColor.primary, color2: AppColor.violet),
          const SizedBox(height: 20),
          const Text('پاسخ درست = ۱ امتیاز | پایان بازی بعد از ۴۵ ثانیه', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800)),
        ]),
      ),
    ]);
  }

  Widget _speedRunPage() {
    final value = timeTotal <= 0 ? 0.0 : (timeLeft / timeTotal).clamp(0.0, 1.0).toDouble();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _htmlGameHeader(leadingLabel: 'امتیاز $speedScore'),
      const SizedBox(height: 10),
      Container(
        constraints: const BoxConstraints(minHeight: 670),
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 22),
        decoration: htmlCard(colors: const [Color(0xFFFFFFFF), Color(0xFFF9FCFF), Color(0xFFF5F1FF)], radius: 36, border: Colors.white70, shadowOpacity: .18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [Expanded(child: _infoStat(value: speedScore.toString(), label: 'امتیاز')), const SizedBox(width: 10), Expanded(child: _infoStat(value: timeLeft.toString(), label: 'زمان'))]),
          const SizedBox(height: 18),
          HtmlProgress(value: value, colors: const [AppColor.cyan, AppColor.primary, AppColor.orange], height: 12),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 24),
            decoration: htmlCard(colors: const [Color(0xFFF7FBFF), Color(0xFFF8F2FF), Color(0xFFFFF8EF)], radius: 24, border: AppColor.primary.withOpacity(.12), shadowOpacity: .08),
            child: Column(children: [
              MiniChip(text: 'سؤال سرعتی'),
              const SizedBox(height: 18),
              Text(level.q, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, height: 1.55, color: AppColor.ink, fontWeight: FontWeight.w900)),
            ]),
          ),
          const SizedBox(height: 18),
          _choiceGrid(height: 86, fontSize: 21),
          const SizedBox(height: 22),
          const Text('برای جواب دادن فقط روی گزینه درست بزن؛ سؤال بعدی فوراً نمایش داده می‌شود.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, height: 1.7, color: AppColor.muted, fontWeight: FontWeight.w800)),
        ]),
      ),
    ]);
  }
}

class ResultPage extends StatelessWidget {
  final GameDef game;
  final int correct;
  final int wrong;
  final int coins;
  final int xp;
  final VoidCallback onHome;
  final VoidCallback onReplay;
  final VoidCallback onAd;
  const ResultPage({super.key, required this.game, required this.correct, required this.wrong, required this.coins, required this.xp, required this.onHome, required this.onReplay, required this.onAd});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      MiniHero(title: 'نتیجه ${game.title}', subtitle: 'خلاصه عملکرد این بازی', icon: 'trophy'),
      const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(18), decoration: htmlCard(colors: const [Colors.white, Color(0xFFF3FBFF), Color(0xFFFFF8EE)], radius: 28, border: AppColor.primary.withOpacity(.15)), child: Column(children: [
        const HtmlIconBox(icon: 'trophy', size: 72, radius: 26, colors: [AppColor.cyan, AppColor.primary], iconColor: Colors.white),
        const SizedBox(height: 10),
        const Text('بازی کامل شد', style: TextStyle(fontSize: 22, color: AppColor.ink, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: ShopStat(value: correct.toString(), label: 'درست')), const SizedBox(width: 8), Expanded(child: ShopStat(value: wrong.toString(), label: 'غلط')), const SizedBox(width: 8), Expanded(child: ShopStat(value: coins.toString(), label: 'سکه'))]),
        const SizedBox(height: 8),
        Row(children: [Expanded(child: ShopStat(value: xp.toString(), label: 'XP')), const SizedBox(width: 8), Expanded(child: ShopStat(value: (correct + wrong).toString(), label: 'مرحله')), const SizedBox(width: 8), Expanded(child: ShopStat(value: game.energy.toString(), label: 'انرژی مصرفی'))]),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: HtmlButton(label: 'خانه', onTap: onHome, color1: AppColor.primary, color2: AppColor.violet, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'دوباره', onTap: onReplay, color1: AppColor.green, color2: AppColor.cyan, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'ادامه با تبلیغ', onTap: onAd, color1: AppColor.orange, color2: AppColor.danger, compact: true))]),
      ])),
    ]);
  }
}

class MiniHero extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final String? trailing;
  const MiniHero({super.key, required this.title, required this.subtitle, required this.icon, this.trailing});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 52, radius: 20, colors: const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)], iconColor: AppColor.primary),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, height: 1.45, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 5), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.7, fontWeight: FontWeight.w800, color: AppColor.muted))])),
        if (trailing != null) MiniChip(text: trailing!),
      ]),
    );
  }
}

class MissionProgressCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final double value;
  final String icon;
  final Color c1;
  final Color c2;
  const MissionProgressCard({super.key, required this.title, required this.subtitle, required this.value, required this.icon, required this.c1, required this.c2});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 54, radius: 20, colors: [c1, c2], iconColor: Colors.white),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 8), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.6, fontWeight: FontWeight.w800, color: AppColor.muted)), const SizedBox(height: 9), HtmlProgress(value: value, colors: [c1, c2])])),
      ]),
    );
  }
}

class QuestCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color c1;
  final Color c2;
  final String button;
  final VoidCallback onTap;
  const QuestCard({super.key, required this.title, required this.subtitle, required this.icon, required this.c1, required this.c2, required this.button, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 56, radius: 20, colors: [c1, c2], iconColor: Colors.white),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 6), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.7, fontWeight: FontWeight.w800, color: AppColor.muted))])),
        const SizedBox(width: 8),
        HtmlButton(label: button, onTap: onTap, color1: AppColor.green, color2: AppColor.cyan, compact: true),
      ]),
    );
  }
}

class ProductTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color c1;
  final Color c2;
  final VoidCallback onTap;
  const ProductTile({super.key, required this.title, required this.subtitle, required this.icon, required this.c1, required this.c2, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 148,
        margin: const EdgeInsets.only(left: 10),
        padding: const EdgeInsets.all(13),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF5FBFF)], radius: 24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          HtmlIconBox(icon: icon, size: 48, radius: 17, colors: [c1, c2], iconColor: Colors.white),
          const Spacer(),
          Text(title, style: const TextStyle(fontSize: 14.5, color: AppColor.ink, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text(subtitle, style: const TextStyle(fontSize: 11.5, color: AppColor.muted, fontWeight: FontWeight.w800, height: 1.5)),
        ]),
      ),
    );
  }
}

class RankRow extends StatelessWidget {
  final String name;
  final int score;
  final bool active;
  const RankRow({super.key, required this.name, required this.score, this.active = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: htmlCard(colors: active ? const [Color(0xFFEFFFF8), Color(0xFFF7FCFF), Color(0xFFFFFFFF)] : const [Colors.white, Color(0xFFF5FBFF), Color(0xFFF2F6FF)], radius: 27, border: active ? AppColor.green.withOpacity(.34) : Colors.white70, shadowOpacity: .15),
      child: Row(children: [HtmlIconBox(icon: active ? 'profile' : 'star', size: 42, radius: 16), const SizedBox(width: 10), Expanded(child: Text(name, style: const TextStyle(fontSize: 14, color: AppColor.ink, fontWeight: FontWeight.w900))), MiniChip(text: '$score امتیاز')]),
    );
  }
}

class ShopStat extends StatelessWidget {
  final String value;
  final String label;
  const ShopStat({super.key, required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF3FBFF), Color(0xFFEFF6FF)], radius: 23, border: Colors.white70, shadowOpacity: .13),
        child: Column(children: [Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 11.2, color: AppColor.muted, fontWeight: FontWeight.w800))]),
      );
}

class SettingsLikeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const SettingsLikeCard({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: htmlCard(radius: 25, border: Colors.white70, shadowOpacity: .13),
        child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(fontSize: 11.5, height: 1.7, color: AppColor.muted, fontWeight: FontWeight.w800))])), const MiniChip(text: 'روشن')]),
      );
}

class HtmlNote extends StatelessWidget {
  final String text;
  const HtmlNote({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF7FBFF), Color(0xFFF4F0FF)], radius: 24, border: Colors.white70, shadowOpacity: .08),
        child: Text(text, style: const TextStyle(fontSize: 12, height: 1.8, fontWeight: FontWeight.w800, color: AppColor.muted)),
      );
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String hint;
  const SectionTitle({super.key, required this.title, required this.hint});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 14, 2, 10),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(title, style: const TextStyle(fontSize: 18, color: AppColor.ink, fontWeight: FontWeight.w900)), Text(hint, style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))]),
      );
}

class HtmlProgress extends StatelessWidget {
  final double value;
  final List<Color> colors;
  final double height;
  const HtmlProgress({super.key, required this.value, required this.colors, this.height = 9});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(99),
        child: Container(
          height: height,
          color: const Color(0xFFE8F2FB),
          child: Align(alignment: Alignment.centerRight, child: FractionallySizedBox(widthFactor: value.clamp(0, 1).toDouble(), child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: colors), borderRadius: BorderRadius.circular(99))))),
        ),
      );
}

class MiniChip extends StatelessWidget {
  final String text;
  const MiniChip({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFF3FAFF), Color(0xFFF7F0FF)]), border: Border.all(color: Colors.white70, width: 1.05), borderRadius: BorderRadius.circular(999), boxShadow: htmlShadow(opacity: .055, blur: 16, offset: const Offset(0, 6))),
        child: Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF344260))),
      );
}

class HtmlButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color1;
  final Color color2;
  final bool compact;
  const HtmlButton({super.key, required this.label, required this.onTap, required this.color1, required this.color2, this.compact = false});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: compact ? 11 : 16, vertical: compact ? 9 : 13),
          decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [color1, color2]), borderRadius: BorderRadius.circular(compact ? 18 : 22), border: Border.all(color: Colors.white.withOpacity(.30), width: 1), boxShadow: [BoxShadow(color: color1.withOpacity(.30), blurRadius: 26, spreadRadius: -8, offset: const Offset(0, 14)), BoxShadow(color: const Color(0xFF263966).withOpacity(.12), blurRadius: 16, offset: const Offset(0, 7))]),
          child: Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: compact ? 11.5 : 14, fontWeight: FontWeight.w900, color: Colors.white)),
        ),
      );
}

class HtmlBottomNav extends StatelessWidget {
  final String active;
  final ValueChanged<String> onTap;
  const HtmlBottomNav({super.key, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('rewards', 'جایزه‌ها', 'gift'),
      ('league', 'لیگ', 'trophy'),
      ('home', 'خانه', 'home'),
      ('shop', 'فروشگاه', 'shop'),
      ('profile', 'پروفایل', 'profile'),
    ];
    return Container(
      color: Colors.transparent,
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: SizedBox(
        height: 98,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: items.map((it) {
            final selected = active == it.$1;
            final isHome = it.$1 == 'home';
            return Expanded(
              child: GestureDetector(
                onTap: () => onTap(it.$1),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  height: isHome ? 90 : 74,
                  margin: EdgeInsets.only(top: isHome ? 0 : 10, left: 5, right: 5),
                  decoration: BoxDecoration(
                    gradient: selected || isHome ? const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [AppColor.cyan, AppColor.primary, AppColor.orange]) : const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFEFFBFF)]),
                    borderRadius: BorderRadius.circular(isHome ? 31 : 23),
                    border: Border.all(color: selected || isHome ? Colors.white.withOpacity(.50) : AppColor.cyan.withOpacity(.14)),
                    boxShadow: [BoxShadow(color: const Color(0xFF263966).withOpacity(selected || isHome ? .26 : .13), blurRadius: selected || isHome ? 34 : 22, spreadRadius: selected || isHome ? -7 : -8, offset: const Offset(0, 14)), BoxShadow(color: Colors.white.withOpacity(.70), blurRadius: 0, offset: const Offset(0, 1))],
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [HtmlSvgIcon(it.$3, size: isHome ? 31 : 25, color: selected || isHome ? Colors.white : const Color(0xFF5C6B82)), const SizedBox(height: 5), Text(it.$2, maxLines: 1, style: TextStyle(fontSize: isHome ? 12 : 11, color: selected || isHome ? Colors.white : const Color(0xFF53627B), fontWeight: FontWeight.w900))]),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class HtmlIconBox extends StatelessWidget {
  final String icon;
  final double size;
  final double radius;
  final List<Color>? colors;
  final Color iconColor;
  const HtmlIconBox({super.key, required this.icon, required this.size, required this.radius, this.colors, this.iconColor = AppColor.primary});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors ?? const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)]),
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: Colors.white.withOpacity(.58), width: 1.1),
          boxShadow: [BoxShadow(color: const Color(0xFF263966).withOpacity(.18), blurRadius: 26, spreadRadius: -8, offset: const Offset(0, 14)), BoxShadow(color: Colors.white.withOpacity(.75), blurRadius: 0, offset: const Offset(0, 1))],
        ),
        child: Center(child: HtmlSvgIcon(icon, size: size * .55, color: iconColor)),
      );
}

class HtmlSvgIcon extends StatelessWidget {
  final String name;
  final double size;
  final Color color;
  const HtmlSvgIcon(this.name, {super.key, required this.size, required this.color});
  @override
  Widget build(BuildContext context) {
    final path = svgPaths[name] ?? svgPaths['star']!;
    final svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">$path</svg>';
    return SvgPicture.string(svg, width: size, height: size, colorFilter: ColorFilter.mode(color, BlendMode.srcIn));
  }
}

const svgPaths = <String, String>{
  'brain': r'''<path d="M9 6.4c-2.1.2-3.6 1.8-3.6 3.8 0 1 .4 1.9 1 2.5-.8.6-1.3 1.5-1.3 2.6 0 1.8 1.5 3.3 3.3 3.3h1.1V6.4Z"/><path d="M15 6.4c2.1.2 3.6 1.8 3.6 3.8 0 1-.4 1.9-1 2.5.8.6 1.3 1.5 1.3 2.6 0 1.8-1.5 3.3-3.3 3.3h-1.1V6.4Z"/><path d="M9.5 9.5H7.8M14.5 9.5h1.7M9.5 13H7.6M14.5 13h1.9M9.5 16.4H8.2M14.5 16.4h1.3"/>''',
  'coin': r'''<circle cx="12" cy="12" r="8"/><path d="M9 10.2c.7-1 2-1.5 3.3-1.2 1.5.3 2.7 1.5 2.7 3s-1.2 2.7-2.7 3c-1.3.3-2.6-.2-3.3-1.2"/><path d="M8.5 12h6"/>''',
  'energy': r'''<path d="M13 2.8 5.5 13h5.2L9.8 21.2 18.5 10h-5.3L13 2.8Z"/>''',
  'profile': r'''<circle cx="12" cy="8" r="3.6"/><path d="M4.8 20c1.2-4.2 13.2-4.2 14.4 0"/>''',
  'home': r'''<path d="M3.5 11.2 12 4l8.5 7.2"/><path d="M6.2 10.5v9h11.6v-9"/><path d="M10 19.5v-5h4v5"/>''',
  'gift': r'''<path d="M4.5 9h15v11h-15z"/><path d="M3.5 9h17V6.2h-17z"/><path d="M12 6.2V20"/><path d="M12 6.2C10.8 3 7.3 3.2 7.3 5.4c0 1.5 2.2 1.8 4.7.8ZM12 6.2c1.2-3.2 4.7-3 4.7-.8 0 1.5-2.2 1.8-4.7.8Z"/>''',
  'trophy': r'''<path d="M8 4h8v4.8c0 2.2-1.8 4-4 4s-4-1.8-4-4V4Z"/><path d="M8 6H5.2c0 3.8 2 5.4 4.3 5.6M16 6h2.8c0 3.8-2 5.4-4.3 5.6M12 12.8v3.8M8.8 20h6.4M10 16.6h4"/>''',
  'shop': r'''<path d="M5.2 9.5h13.6l-1 10H6.2l-1-10Z"/><path d="M8.5 9.5V8a3.5 3.5 0 0 1 7 0v1.5"/><path d="M4 9.5h16"/>''',
  'riddle': r'''<path d="M9 18h6M9.5 21h5"/><path d="M8.2 14.5c-1.3-1.1-2-2.7-2-4.4a5.8 5.8 0 0 1 11.6 0c0 1.7-.7 3.3-2 4.4-.8.7-1.1 1.4-1.2 2H9.4c-.1-.6-.4-1.3-1.2-2Z"/><path d="M10.8 10.3c.2-1.8 2.8-1.7 2.8.1 0 1.3-1.6 1.4-1.6 2.6M12 15h.1"/>''',
  'word': r'''<path d="M5 18 9.3 6h1.4L15 18M6.5 14h7"/><path d="M17 8h2.5M17 12h2.5M17 16h2.5"/>''',
  'speed': r'''<circle cx="12" cy="13" r="7"/><path d="M9 3h6M12 13V9M12 13l3 2"/>''',
  'logic': r'''<path d="M8 4h4v4H8zM12 8h4v4h-4zM8 12h4v4H8zM12 16h4v4h-4z"/><path d="M12 6h2M10 10h2M12 14h2"/>''',
  'picture': r'''<path d="M3.5 12s3.2-5.2 8.5-5.2 8.5 5.2 8.5 5.2-3.2 5.2-8.5 5.2S3.5 12 3.5 12Z"/><circle cx="12" cy="12" r="2.8"/>''',
  'ad': r'''<rect x="4" y="6" width="16" height="12" rx="3"/><path d="m10 10 5 2.5-5 2.5Z"/>''',
  'target': r'''<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1.2"/>''',
  'medal': r'''<path d="M8 3h8l-2 5h-4L8 3Z"/><circle cx="12" cy="14" r="5"/><path d="M12 11.5v4.8M9.8 14h4.4"/>''',
  'star': r'''<path d="m12 3 2.4 5 5.5.8-4 3.9.9 5.5-4.8-2.6-4.8 2.6.9-5.5-4-3.9 5.5-.8L12 3Z"/>''',
  'hint': r'''<path d="M9 18h6M9.5 21h5"/><path d="M8.2 14.5c-1.3-1.1-2-2.7-2-4.4a5.8 5.8 0 0 1 11.6 0c0 1.7-.7 3.3-2 4.4-.8.7-1.1 1.4-1.2 2H9.4c-.1-.6-.4-1.3-1.2-2Z"/>''',
  'heart': r'''<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z"/>''',
  'play': r'''<path d="m8 5 10 7-10 7V5Z"/><path d="M4 5v14"/>''',
  'check': r'''<path d="m5 12 4 4 10-10"/>''',
  'truefalse': r'''<path d="m4 7 4 4 5-7"/><path d="M14 8h6M14 12h6M5 18h14"/>''',
  'yesno': r'''<path d="m5 12 4 4 10-10"/><path d="M4 5h16M4 19h16"/>''',
  'typo': r'''<path d="M5 6h14M7 6v12M17 6v12"/><path d="M8 18h3M15 18h3"/>''',
};
