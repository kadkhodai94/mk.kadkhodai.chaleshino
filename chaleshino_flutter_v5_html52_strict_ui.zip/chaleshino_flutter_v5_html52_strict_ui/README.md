# چالشینو Flutter v5 - HTML v52 strict UI

این نسخه WebView نیست. صفحه‌ها با Widgetهای Flutter بازسازی شده‌اند و هدف آن نزدیک‌کردن UI به HTML v52 بدون overlay/opacity اضافی است.

Package name در workflow روی `mk.kadkhodai.chaleshino` تنظیم می‌شود.
