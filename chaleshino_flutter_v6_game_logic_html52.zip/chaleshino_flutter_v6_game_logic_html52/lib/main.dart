import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ChaleshinoApp());
}

class AppColor {
  static const bg = Color(0xFFE8EEF9);
  static const paper = Color(0xFFFFFEFA);
  static const ink = Color(0xFF18243B);
  static const muted = Color(0xFF66758F);
  static const primary = Color(0xFF6C63FF);
  static const violet = Color(0xFF8F6CFF);
  static const cyan = Color(0xFF14C8D8);
  static const green = Color(0xFF18BF8F);
  static const orange = Color(0xFFFFB84D);
  static const danger = Color(0xFFFF5C7A);
}

List<BoxShadow> htmlShadow({double opacity = .18, double blur = 34, Offset offset = const Offset(0, 18)}) => [
      BoxShadow(color: const Color(0xFF374696).withOpacity(opacity), blurRadius: blur, offset: offset),
      BoxShadow(color: Colors.white.withOpacity(.78), blurRadius: 0, offset: const Offset(0, 1)),
    ];

BoxDecoration htmlCard({
  List<Color> colors = const [Colors.white, Color(0xFFF4FBFF)],
  double radius = 30,
  Color? border,
  double shadowOpacity = .18,
}) {
  return BoxDecoration(
    gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors),
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: border ?? AppColor.cyan.withOpacity(.13)),
    boxShadow: htmlShadow(opacity: shadowOpacity),
  );
}

class ChaleshinoApp extends StatelessWidget {
  const ChaleshinoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'چالشینو',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Tahoma',
        scaffoldBackgroundColor: AppColor.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColor.primary),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: ChaleshinoRoot()),
    );
  }
}


class GameLevel {
  final String q;
  final List<String> options;
  final int answer;
  final String hint;
  final String difficulty;
  final String? word;
  final List<String> letters;
  final List<String> items;

  const GameLevel({
    required this.q,
    this.options = const [],
    this.answer = 0,
    this.hint = 'با دقت گزینه‌ها را مقایسه کن.',
    this.difficulty = 'easy',
    this.word,
    this.letters = const [],
    this.items = const [],
  });
}

class GameDef {
  final String id;
  final String title;
  final String description;
  final String icon;
  final int energy;
  final Color c1;
  final Color c2;
  final String mode;
  final List<GameLevel> levels;

  const GameDef(this.id, this.title, this.description, this.icon, this.energy, this.c1, this.c2, this.mode, this.levels);
}

const games = <GameDef>[
  GameDef('riddle', 'چیستان', 'چیستان‌های زمان‌دار با جواب گزینه‌ای.', 'riddle', 3, Color(0xFFFFCF6D), Color(0xFFFF9F43), 'choice', [
    GameLevel(q: 'چیزی که هرچه بیشتر برداری، بزرگ‌تر می‌شود؟', options: ['چاله', 'درخت', 'دفتر', 'سایه'], answer: 0, hint: 'وقتی از زمین برمی‌داری، عمقش بیشتر می‌شود.'),
    GameLevel(q: 'کدام ماه ۲۸ روز دارد؟', options: ['همه ماه‌ها', 'اسفند', 'بهمن', 'فقط فوریه'], answer: 0, hint: 'همه ماه‌ها حداقل ۲۸ روز دارند.'),
    GameLevel(q: 'چیزی که باز می‌شود اما در نیست؟', options: ['چتر', 'پنجره', 'کتاب', 'قفل'], answer: 0, hint: 'در باران استفاده می‌شود.'),
    GameLevel(q: 'کدام همیشه همراه توست اما جلوتر یا عقب‌تر می‌افتد؟', options: ['سایه', 'کیف', 'ساعت', 'صدا'], answer: 0, hint: 'با نور دیده می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'بی‌صداست اما خبر می‌دهد؛ چیست؟', options: ['چراغ', 'کتاب', 'باد', 'آینه'], answer: 0, hint: 'با روشن و خاموش شدن پیام می‌دهد.', difficulty: 'medium'),
    GameLevel(q: 'چه چیزی با سکوت قوی‌تر می‌شود؟', options: ['راز', 'باد', 'باران', 'کتاب'], answer: 0, hint: 'اگر گفته نشود می‌ماند.', difficulty: 'hard'),
  ]),
  GameDef('word', 'حدس کلمه', 'کلمه را از حروف به‌هم‌ریخته بساز.', 'word', 4, Color(0xFF14C8D8), Color(0xFF6C63FF), 'word', [
    GameLevel(q: 'این حروف را مرتب کن:', word: 'امتیاز', letters: ['ز','ا','ی','ت','م','ا'], hint: 'عدد پیشرفت کاربر'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'رقابت', letters: ['ت','ب','ق','ا','ر'], hint: 'برای بالا رفتن در لیگ'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'تمرکز', letters: ['ز','ک','ر','م','ت'], hint: 'برای جواب سریع لازم است', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'پیشرفت', letters: ['ت','ف','ر','ش','ی','پ'], hint: 'نتیجه ادامه دادن', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'استدلال', letters: ['ل','ا','د','ت','س','ا','ل'], hint: 'برای معمای سخت لازم است', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'راهبرد', letters: ['د','ر','ب','ه','ا','ر'], hint: 'روش درست برای برد', difficulty: 'hard'),
  ]),
  GameDef('truefalse', 'درست یا غلط', 'جمله را بخوان و سریع درست یا غلط را انتخاب کن.', 'truefalse', 3, Color(0xFF8F6CFF), Color(0xFFFFCF6D), 'choice', [
    GameLevel(q: 'لیگ برنزی ساده‌ترین سطح بازی است.', options: ['درست', 'غلط'], answer: 0, hint: 'برنزی برای شروع است.'),
    GameLevel(q: 'در لیگ نقره‌ای تایمر از برنزی سخت‌تر می‌شود.', options: ['درست', 'غلط'], answer: 0, hint: 'سطح بالاتر یعنی فشار بیشتر.'),
    GameLevel(q: 'لیگ افسانه‌ای پایین‌ترین لیگ است.', options: ['درست', 'غلط'], answer: 1, hint: 'افسانه‌ای بالاترین سطح است.', difficulty: 'hard'),
    GameLevel(q: 'در جواب غلط باید قلب کم شود.', options: ['درست', 'غلط'], answer: 0, hint: 'قانون قلب‌ها همین است.'),
  ]),
  GameDef('yesno', 'بله یا خیر', 'سؤال کوتاه را در ۵ ثانیه با بله یا خیر جواب بده.', 'yesno', 3, Color(0xFF14C8D8), Color(0xFF18BF8F), 'choice', [
    GameLevel(q: 'آیا لیگ برنزی برای شروع مناسب است؟', options: ['بله', 'خیر'], answer: 0, hint: 'شروع بازی با برنزی است.'),
    GameLevel(q: 'آیا در لیگ نقره‌ای سؤال‌ها کمی سخت‌تر می‌شوند؟', options: ['بله', 'خیر'], answer: 0, hint: 'سختی مرحله‌ای بیشتر می‌شود.'),
    GameLevel(q: 'آیا افسانه‌ای پایین‌ترین لیگ است؟', options: ['بله', 'خیر'], answer: 1, hint: 'افسانه‌ای بالاترین لیگ است.', difficulty: 'hard'),
    GameLevel(q: 'آیا جواب غلط باید بدون جریمه باشد؟', options: ['بله', 'خیر'], answer: 1, hint: 'جواب غلط قلب کم می‌کند.'),
  ]),
  GameDef('picture', 'معمای تصویری', 'با چند نشانه تصویری جواب درست را انتخاب کن.', 'picture', 4, Color(0xFF18BF8F), Color(0xFF14C8D8), 'choice', [
    GameLevel(q: '🪙 + 🏆 یعنی چه؟', options: ['امتیاز لیگ', 'آب‌وهوا', 'غذا', 'خواب'], answer: 0, hint: 'سکه و جام یعنی رقابت.'),
    GameLevel(q: '🧠 + 🎯 یعنی چه؟', options: ['تمرکز', 'سفر', 'باران', 'خرید'], answer: 0, hint: 'هدف و مغز یعنی دقت.'),
    GameLevel(q: '⚡ + ⏱ یعنی چه؟', options: ['سرعت بازی', 'آرامش', 'پروفایل', 'فروشگاه'], answer: 0, hint: 'زمان و انرژی مهم است.', difficulty: 'medium'),
    GameLevel(q: '🏅 + ⭐ یعنی چه؟', options: ['رتبه ویژه', 'سؤال ساده', 'خروج', 'قفل'], answer: 0, hint: 'مدال و ستاره برای جایگاه بالا.', difficulty: 'hard'),
  ]),
  GameDef('typo', 'غلط‌یاب', 'گزینه درست‌تر را انتخاب کن.', 'typo', 4, Color(0xFFFF7D9B), Color(0xFFFF5C7A), 'choice', [
    GameLevel(q: 'کدام درست‌تر است؟', options: ['امتیاز', 'امتیاذ', 'امتیازز', 'امطیاز'], answer: 0, hint: 'حرف آخر ز است.'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['رتبه‌بندی', 'رتبهبندیی', 'ردبه‌بندی', 'رتبه بندیی'], answer: 0, hint: 'رتبه‌بندی با «ت» نوشته می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['استدلال', 'استدلالل', 'اصتدلال', 'استدلاله'], answer: 0, hint: 'شکل درست بدون حرف اضافه است.', difficulty: 'hard'),
    GameLevel(q: 'کدام درست‌تر است؟', options: ['مسئولیت‌پذیری', 'مسولیت پذیریی', 'مسئولیت پزیری', 'مسئولیت‌پذیریی'], answer: 0, hint: 'شکل کامل با نیم‌فاصله بهتر است.', difficulty: 'hard'),
  ]),
  GameDef('logic', 'معمای منطقی', 'سؤال‌های کوتاه و فکری با انتخاب جواب.', 'logic', 5, Color(0xFF6C63FF), Color(0xFF14C8D8), 'choice', [
    GameLevel(q: 'اگر ۲ مرحله انجام دهی و یکی دیگر بروی، چند مرحله شده؟', options: ['۳', '۲', '۴', '۱'], answer: 0, hint: '۲ + ۱'),
    GameLevel(q: 'اگر امتیازت ۹۰۰ شود وارد کدام لیگ می‌شوی؟', options: ['نقره‌ای', 'برنزی', 'طلایی', 'الماسی'], answer: 0, hint: '۹۰۰ شروع نقره‌ای است.', difficulty: 'medium'),
    GameLevel(q: 'اگر پاداش لیگ بیشتر شود، نتیجه چیست؟', options: ['سکه بیشتر', 'سکه کمتر', 'بدون پاداش', 'ریست بازی'], answer: 0, hint: 'ضریب پاداش بالا می‌رود.', difficulty: 'hard'),
    GameLevel(q: 'اگر در یک راند سؤال تکراری نیاید، سیستم چه کاری می‌کند؟', options: ['چرخش سؤال', 'حذف بازی', 'ریست سکه', 'توقف تایمر'], answer: 0, hint: 'سؤال بعدی انتخاب می‌شود.', difficulty: 'hard'),
  ]),
  GameDef('memory', 'حافظه سریع', 'چند آیتم را ببین و بعد از حافظه جواب بده.', 'brain', 4, Color(0xFF30D5C8), Color(0xFF6C63FF), 'memory', [
    GameLevel(q: 'کدام مورد در لیست بود؟', items: ['سکه','انرژی','قلب'], options: ['انرژی','باران','کوه','چراغ'], answer: 0, hint: 'یکی از آیتم‌های بازی بود.'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['کتاب','قلم','دفتر','کلاس'], options: ['قلم','دفتر','کتاب','زنگ'], answer: 0, hint: 'بعد از کتاب آمده بود.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['لیگ','سکه','مرحله','XP'], options: ['درخت','سکه','مرحله','لیگ'], answer: 0, hint: 'یکی خارج از بازی است.', difficulty: 'medium'),
    GameLevel(q: 'آیتم سوم چه بود؟', items: ['تمرکز','سرعت','راهبرد','تحلیل','نوآوری'], options: ['راهبرد','تحلیل','تمرکز','سرعت'], answer: 0, hint: 'بعد از سرعت آمده بود.', difficulty: 'hard'),
  ]),
  GameDef('speed', 'چالش سرعتی', '۴۵ ثانیه سؤال سریع و رکوردی.', 'speed', 5, Color(0xFFFFB84D), Color(0xFFEF476F), 'speed', [
    GameLevel(q: 'برنزی‌ترین لیگ؟', options: ['برنزی','طلایی','الماسی','افسانه‌ای'], answer: 0),
    GameLevel(q: 'لیگ بعد از برنزی؟', options: ['نقره‌ای','طلایی','الماسی','افسانه‌ای'], answer: 0),
    GameLevel(q: 'بیشترین سختی؟', options: ['افسانه‌ای','برنزی','نقره‌ای','طلایی'], answer: 0),
    GameLevel(q: 'پاداش بیشتر با؟', options: ['سختی بالاتر','زمان نامحدود','خروج از بازی','حذف سؤال'], answer: 0),
    GameLevel(q: 'مأموریت روزانه برای چیست؟', options: ['برگشت کاربر','کند کردن بازی','حذف لیگ','خاموش کردن تایمر'], answer: 0),
    GameLevel(q: 'جواب غلط چه کم می‌کند؟', options: ['قلب','سکه واقعی','نام بازی','آیکن'], answer: 0),
  ]),
];

class PlayerState {
  int coins;
  int energy;
  int xp;
  int hints;
  int gamesDone;
  int correct;
  int wrong;
  int ads;
  int bestSpeed;
  String dailyDate;
  Map<String, int> progresses;
  Set<String> playedGames;
  Set<String> achievements;

  PlayerState({
    this.coins = 970,
    this.energy = 50,
    this.xp = 0,
    this.hints = 3,
    this.gamesDone = 0,
    this.correct = 0,
    this.wrong = 0,
    this.ads = 0,
    this.bestSpeed = 0,
    this.dailyDate = '',
    Map<String, int>? progresses,
    Set<String>? playedGames,
    Set<String>? achievements,
  })  : progresses = progresses ?? <String, int>{},
        playedGames = playedGames ?? <String>{},
        achievements = achievements ?? <String>{};

  Map<String, dynamic> toJson() => {
        'coins': coins,
        'energy': energy,
        'xp': xp,
        'hints': hints,
        'gamesDone': gamesDone,
        'correct': correct,
        'wrong': wrong,
        'ads': ads,
        'bestSpeed': bestSpeed,
        'dailyDate': dailyDate,
        'progresses': progresses,
        'playedGames': playedGames.toList(),
        'achievements': achievements.toList(),
      };

  factory PlayerState.fromJson(Map<String, dynamic> json) => PlayerState(
        coins: json['coins'] ?? 970,
        energy: json['energy'] ?? 50,
        xp: json['xp'] ?? 0,
        hints: json['hints'] ?? 3,
        gamesDone: json['gamesDone'] ?? 0,
        correct: json['correct'] ?? 0,
        wrong: json['wrong'] ?? 0,
        ads: json['ads'] ?? 0,
        bestSpeed: json['bestSpeed'] ?? 0,
        dailyDate: json['dailyDate'] ?? '',
        progresses: (json['progresses'] is Map)
            ? Map<String, int>.from((json['progresses'] as Map).map((k, v) => MapEntry(k.toString(), (v as num).toInt())))
            : <String, int>{},
        playedGames: Set<String>.from(json['playedGames'] ?? const []),
        achievements: Set<String>.from(json['achievements'] ?? const []),
      );
}

class LeagueRule {
  final String name;
  final int min;
  final double coin;
  final double xp;
  const LeagueRule(this.name, this.min, this.coin, this.xp);
}

const leagueRules = <LeagueRule>[
  LeagueRule('برنزی', 0, 1.00, 1.00),
  LeagueRule('نقره‌ای', 900, 1.15, 1.15),
  LeagueRule('طلایی', 2200, 1.35, 1.30),
  LeagueRule('الماسی', 4200, 1.60, 1.55),
  LeagueRule('افسانه‌ای', 7000, 1.90, 1.85),
];

class ChaleshinoRoot extends StatefulWidget {
  const ChaleshinoRoot({super.key});

  @override
  State<ChaleshinoRoot> createState() => _ChaleshinoRootState();
}

class _ChaleshinoRootState extends State<ChaleshinoRoot> {
  PlayerState state = PlayerState();
  String tab = 'home';
  GameDef? activeGame;
  int hearts = 3;
  int runCorrect = 0;
  int runWrong = 0;
  int lastCoins = 0;
  int lastXp = 0;
  int timeLeft = 0;
  int timeTotal = 1;
  int? selectedAnswer;
  bool hintShown = false;
  bool memoryPreview = false;
  String wordAnswer = '';
  final List<int> wordPicked = <int>[];
  int speedIndex = 0;
  int speedScore = 0;
  int speedWrong = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('chaleshino_flutter_v6_state') ?? prefs.getString('chaleshino_flutter_v5_state');
    if (saved == null) return;
    try {
      setState(() => state = PlayerState.fromJson(jsonDecode(saved)));
    } catch (_) {}
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('chaleshino_flutter_v6_state', jsonEncode(state.toJson()));
  }

  LeagueRule get league {
    final score = state.xp + state.bestSpeed * 40 + state.correct * 10;
    var current = leagueRules.first;
    for (final l in leagueRules) {
      if (score >= l.min) current = l;
    }
    return current;
  }

  int _levelIndex(GameDef game) => (state.progresses[game.id] ?? 0) % game.levels.length;
  GameLevel _level(GameDef game) => game.levels[_levelIndex(game)];

  int _timeLimit(GameDef game, GameLevel level) {
    if (game.mode == 'speed') return 45;
    if (game.id == 'truefalse' || game.id == 'yesno') return 5;
    if (game.mode == 'memory') return level.difficulty == 'hard' ? 10 : 12;
    if (level.difficulty == 'easy') return 20;
    if (level.difficulty == 'medium') return 15;
    return 10;
  }

  int _baseCoin(GameLevel level) {
    switch (level.difficulty) {
      case 'hard':
        return 23;
      case 'medium':
        return 18;
      default:
        return 14;
    }
  }

  int _baseXp(GameLevel level) {
    switch (level.difficulty) {
      case 'hard':
        return 26;
      case 'medium':
        return 20;
      default:
        return 15;
    }
  }

  String _today() => DateTime.now().toIso8601String().substring(0, 10);

  void openTab(String next) {
    timer?.cancel();
    setState(() {
      tab = next;
      activeGame = null;
    });
  }

  void startGame(GameDef game) {
    if (state.energy < game.energy) {
      _toast('انرژی کافی نیست');
      return;
    }
    timer?.cancel();
    setState(() {
      state.energy -= game.energy;
      activeGame = game;
      tab = 'game';
      hearts = 3;
      runCorrect = 0;
      runWrong = 0;
      lastCoins = 0;
      lastXp = 0;
      selectedAnswer = null;
      hintShown = false;
      speedScore = 0;
      speedWrong = 0;
      speedIndex = 0;
    });
    _prepareLevel();
    _save();
  }

  void _prepareLevel() {
    final game = activeGame;
    if (game == null) return;
    final level = _level(game);
    timer?.cancel();
    setState(() {
      selectedAnswer = null;
      hintShown = false;
      wordAnswer = '';
      wordPicked.clear();
      memoryPreview = game.mode == 'memory';
      if (game.mode == 'speed') {
        timeTotal = 45;
        timeLeft = 45;
        speedIndex = speedIndex % game.levels.length;
      } else if (game.mode == 'memory') {
        timeTotal = 4;
        timeLeft = 4;
      } else {
        timeTotal = _timeLimit(game, level);
        timeLeft = timeTotal;
      }
    });
    if (game.mode == 'speed') {
      _startTimer(_endSpeed);
    } else if (game.mode == 'memory') {
      _startTimer(_switchMemoryToAnswer);
    } else {
      _startTimer(() => _finishLevel(false));
    }
  }

  void _startTimer(VoidCallback onExpire) {
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (timeLeft <= 1) {
        t.cancel();
        onExpire();
      } else {
        setState(() => timeLeft--);
      }
    });
  }

  void _switchMemoryToAnswer() {
    final game = activeGame;
    if (game == null || tab != 'game') return;
    final level = _level(game);
    setState(() {
      memoryPreview = false;
      timeTotal = _timeLimit(game, level);
      timeLeft = timeTotal;
    });
    _startTimer(() => _finishLevel(false));
  }

  void _choiceAnswer(int index) {
    final game = activeGame;
    if (game == null || selectedAnswer != null) return;
    final level = game.mode == 'speed' ? game.levels[speedIndex % game.levels.length] : _level(game);
    setState(() => selectedAnswer = index);
    Future.delayed(const Duration(milliseconds: 260), () {
      if (!mounted || tab != 'game') return;
      if (game.mode == 'speed') {
        _speedAnswer(index == level.answer);
      } else {
        _finishLevel(index == level.answer);
      }
    });
  }

  void _speedAnswer(bool ok) {
    final game = activeGame;
    if (game == null) return;
    setState(() {
      if (ok) {
        speedScore++;
      } else {
        speedWrong++;
      }
      selectedAnswer = null;
      speedIndex = (speedIndex + 1) % game.levels.length;
    });
  }

  void _endSpeed() {
    if (activeGame?.mode != 'speed') return;
    timer?.cancel();
    final earnedCoins = speedScore * 10;
    final earnedXp = speedScore * 14;
    setState(() {
      runCorrect = speedScore;
      runWrong = speedWrong;
      lastCoins = earnedCoins;
      lastXp = earnedXp;
      state.coins += earnedCoins;
      state.xp += earnedXp;
      state.correct += speedScore;
      state.wrong += speedWrong;
      state.bestSpeed = math.max(state.bestSpeed, speedScore);
      _completeGameStats(activeGame!.id);
      tab = 'result';
    });
    _save();
  }

  void _wordPick(int index) {
    final game = activeGame;
    if (game == null || game.mode != 'word') return;
    final level = _level(game);
    if (wordPicked.contains(index)) return;
    if (wordAnswer.length >= (level.word ?? '').length) return;
    setState(() {
      wordPicked.add(index);
      wordAnswer += level.letters[index];
    });
  }

  void _wordBackspace() {
    if (wordPicked.isEmpty) return;
    setState(() {
      wordPicked.removeLast();
      if (wordAnswer.isNotEmpty) wordAnswer = wordAnswer.substring(0, wordAnswer.length - 1);
    });
  }

  void _wordClear() {
    setState(() {
      wordPicked.clear();
      wordAnswer = '';
    });
  }

  String _norm(String s) => s.replaceAll('ي', 'ی').replaceAll('ك', 'ک').replaceAll('آ', 'ا').replaceAll(RegExp(r'\s+'), '').trim();

  void _wordSubmit() {
    final game = activeGame;
    if (game == null || game.mode != 'word') return;
    final level = _level(game);
    _finishLevel(_norm(wordAnswer) == _norm(level.word ?? ''));
  }

  void _useHint() {
    if (hintShown) return;
    if (state.hints <= 0) {
      _toast('راهنما نداری');
      return;
    }
    setState(() {
      state.hints--;
      hintShown = true;
    });
    _save();
  }

  void _finishLevel(bool ok) {
    final game = activeGame;
    if (game == null) return;
    timer?.cancel();
    final level = _level(game);
    final coinReward = (ok ? (_baseCoin(level) * league.coin).round() : 0);
    final xpReward = (ok ? (_baseXp(level) * league.xp).round() : 0);
    setState(() {
      if (ok) {
        runCorrect++;
        state.correct++;
        state.coins += coinReward;
        state.xp += xpReward;
        lastCoins += coinReward;
        lastXp += xpReward;
      } else {
        runWrong++;
        state.wrong++;
        hearts = math.max(0, hearts - 1);
      }
      state.progresses[game.id] = (state.progresses[game.id] ?? 0) + 1;
    });

    final played = runCorrect + runWrong;
    if (hearts <= 0 || played >= 5) {
      _showResult();
    } else {
      _prepareLevel();
    }
    _save();
  }

  void _showResult() {
    final game = activeGame;
    if (game == null) return;
    setState(() {
      _completeGameStats(game.id);
      tab = 'result';
    });
  }

  void _completeGameStats(String gameId) {
    state.gamesDone++;
    state.playedGames.add(gameId);
    if (state.gamesDone >= 3) state.achievements.add('۳ بازی انجام‌شده');
    if (state.correct >= 10) state.achievements.add('۱۰ جواب درست');
    if (state.xp >= 450) state.achievements.add('رسیدن به لیگ بعدی');
    if (state.playedGames.length >= 5) state.achievements.add('۵ بازی مختلف');
    if (state.bestSpeed >= 8) state.achievements.add('رکورد سرعتی');
  }

  void claimDaily() {
    final today = _today();
    if (state.dailyDate == today) {
      _toast('جایزه امروز قبلاً گرفته شده');
      return;
    }
    setState(() {
      state.dailyDate = today;
      state.coins += 130;
      state.energy += 10;
      state.achievements.add('دریافت جایزه روزانه');
    });
    _save();
    _toast('جایزه روزانه دریافت شد');
  }

  void watchAd() {
    setState(() {
      state.ads++;
      state.coins += 150;
      state.energy += 10;
      state.achievements.add('تماشای تبلیغ جایزه‌دار');
    });
    _save();
    _toast('۱۵۰ سکه و ۱۰ انرژی اضافه شد');
  }

  void buy({int coins = 0, int energy = 0, int hints = 0}) {
    setState(() {
      state.coins += coins;
      state.energy += energy;
      state.hints += hints;
    });
    _save();
    _toast('بسته اضافه شد');
  }

  void _toast(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: AppColor.ink, fontWeight: FontWeight.w900)),
        backgroundColor: Colors.white,
        behavior: SnackBarBehavior.floating,
        elevation: 18,
        margin: const EdgeInsets.fromLTRB(34, 0, 34, 104),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: AppColor.cyan.withOpacity(.16))),
        duration: const Duration(milliseconds: 1100),
      ),
    );
  }

  Widget _page() {
    switch (tab) {
      case 'shop':
        return ShopPage(state: state, onBuy: buy, onAd: watchAd);
      case 'rewards':
        return RewardsPage(state: state, onDaily: claimDaily, onAd: watchAd);
      case 'league':
        return LeaguePage(state: state, league: league);
      case 'profile':
        return ProfilePage(state: state);
      case 'game':
        final game = activeGame ?? games.first;
        final level = game.mode == 'speed' ? game.levels[speedIndex % game.levels.length] : _level(game);
        return GamePage(
          game: game,
          level: level,
          levelNumber: game.mode == 'speed' ? speedIndex + 1 : _levelIndex(game) + 1,
          totalLevels: game.levels.length,
          hearts: hearts,
          correct: runCorrect,
          wrong: runWrong,
          timeLeft: timeLeft,
          timeTotal: timeTotal,
          selectedAnswer: selectedAnswer,
          hintShown: hintShown,
          memoryPreview: memoryPreview,
          wordAnswer: wordAnswer,
          wordPicked: wordPicked,
          speedScore: speedScore,
          speedWrong: speedWrong,
          onBack: () => openTab('home'),
          onChoice: _choiceAnswer,
          onWordLetter: _wordPick,
          onWordBack: _wordBackspace,
          onWordClear: _wordClear,
          onWordSubmit: _wordSubmit,
          onHint: _useHint,
        );
      case 'result':
        return ResultPage(game: activeGame ?? games.first, correct: runCorrect, wrong: runWrong, coins: lastCoins, xp: lastXp, onHome: () => openTab('home'), onReplay: () => startGame(activeGame ?? games.first), onAd: watchAd);
      default:
        return HomePage(state: state, onStart: startGame, onAd: watchAd);
    }
  }

  @override
  Widget build(BuildContext context) {
    final showNav = tab != 'game' && tab != 'result';
    return Scaffold(
      backgroundColor: AppColor.bg,
      bottomNavigationBar: showNav ? HtmlBottomNav(active: tab, onTap: openTab) : null,
      body: HtmlBackground(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Column(
              children: [
                SafeArea(bottom: false, child: TopBar(state: state, onProfile: () => openTab('profile'))),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 160),
                    child: ListView(
                      key: ValueKey(tab),
                      padding: EdgeInsets.fromLTRB(16, tab == 'home' ? 6 : 14, 16, showNav ? 26 : 20),
                      children: [_page()],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HtmlBackground extends StatelessWidget {
  final Widget child;
  const HtmlBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFE4EBF7), Color(0xFFF1F6FF), Color(0xFFE7E1FF)], stops: [0, .46, 1]),
      ),
      child: Stack(
        children: [
          Positioned(top: -70, right: -70, child: CircleBlob(size: 220, color: AppColor.primary.withOpacity(.23))),
          Positioned(top: 58, left: -82, child: CircleBlob(size: 204, color: AppColor.cyan.withOpacity(.24))),
          Positioned(bottom: -115, left: 80, child: CircleBlob(size: 250, color: AppColor.orange.withOpacity(.20))),
          CustomPaint(painter: HtmlGridPainter(), size: Size.infinite),
          child,
        ],
      ),
    );
  }
}

class CircleBlob extends StatelessWidget {
  final double size;
  final Color color;
  const CircleBlob({super.key, required this.size, required this.color});
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: BoxDecoration(color: color, shape: BoxShape.circle));
}

class HtmlGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p1 = Paint()..color = AppColor.primary.withOpacity(.052)..strokeWidth = 1;
    final p2 = Paint()..color = AppColor.cyan.withOpacity(.052)..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 34) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p1);
    }
    for (double x = 0; x < size.width; x += 34) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p2);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class TopBar extends StatelessWidget {
  final PlayerState state;
  final VoidCallback onProfile;
  const TopBar({super.key, required this.state, required this.onProfile});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                HtmlIconBox(icon: 'brain', size: 48, radius: 18, colors: const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)], iconColor: AppColor.primary),
                const SizedBox(width: 10),
                const Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('چالشینو', style: TextStyle(fontSize: 22, height: 1.05, fontWeight: FontWeight.w900, color: AppColor.ink)),
                      SizedBox(height: 4),
                      Text('نسخه تستی v52', style: TextStyle(fontSize: 11, color: Color(0xFF6D7893), fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Wrap(
            textDirection: TextDirection.ltr,
            spacing: 7,
            runSpacing: 7,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              GestureDetector(onTap: onProfile, child: HtmlIconBox(icon: 'profile', size: 44, radius: 18, colors: const [Colors.white, Color(0xFFEFFBFF)], iconColor: AppColor.primary)),
              WalletPill(icon: 'energy', value: state.energy.toString()),
              WalletPill(icon: 'coin', value: state.coins.toString()),
            ],
          ),
        ],
      ),
    );
  }
}

class WalletPill extends StatelessWidget {
  final String icon;
  final String value;
  const WalletPill({super.key, required this.icon, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFEFFBFF)]),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColor.cyan.withOpacity(.16)),
        boxShadow: [BoxShadow(color: const Color(0xFF374696).withOpacity(.15), blurRadius: 24, offset: const Offset(0, 12))],
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [HtmlSvgIcon(icon, size: 18, color: icon == 'coin' ? AppColor.orange : AppColor.primary), const SizedBox(width: 6), Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: AppColor.ink))]),
    );
  }
}

class HomePage extends StatelessWidget {
  final PlayerState state;
  final ValueChanged<GameDef> onStart;
  final VoidCallback onAd;
  const HomePage({super.key, required this.state, required this.onStart, required this.onAd});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SizedBox(
        height: 106,
        child: ListView(
          scrollDirection: Axis.horizontal,
          reverse: true,
          padding: const EdgeInsets.only(bottom: 10),
          children: [
            HomeAdCard(title: 'تبلیغ ویدئویی جایزه‌دار', subtitle: 'Placement واقعی ثبت شد؛ در HTML فعلاً شبیه‌سازی می‌شود.', icon: 'ad', action: 'تماشا', onTap: onAd),
            const SizedBox(width: 12),
            const HomeAdCard(title: 'تبلیغ بنری', subtitle: 'جایگاه بنری واقعی برای نسخه اندروید آماده شد.', icon: 'gift'),
            const SizedBox(width: 12),
            const HomeAdCard(title: 'بنر دوم تستی', subtitle: 'اسکرول افقی بنرها برای اتصال SDK حفظ شد.', icon: 'star'),
          ],
        ),
      ),
      GamesFrame(onStart: onStart),
      const SizedBox(height: 12),
      const SectionTitle(title: 'مسیر امروز', hint: 'مأموریت روزانه'),
      MissionProgressCard(title: '۳ بازی انجام بده', subtitle: '${state.gamesDone.clamp(0, 3)}/3 بازی ثبت شده', value: (state.gamesDone / 3).clamp(0, 1).toDouble(), icon: 'target', c1: AppColor.green, c2: AppColor.cyan),
      const SizedBox(height: 12),
      MissionProgressCard(title: '۱۰ جواب درست', subtitle: '${state.correct.clamp(0, 10)}/10 جواب درست', value: (state.correct / 10).clamp(0, 1).toDouble(), icon: 'brain', c1: AppColor.orange, c2: AppColor.danger),
    ]);
  }
}

class HomeAdCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final String? action;
  final VoidCallback? onTap;
  const HomeAdCard({super.key, required this.title, required this.subtitle, required this.icon, this.action, this.onTap});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: action == null ? 248 : 292,
      padding: const EdgeInsets.all(12),
      decoration: htmlCard(colors: const [Color(0xFFFFF8EA), Colors.white, Color(0xFFEEFBFF)], radius: 27, border: AppColor.cyan.withOpacity(.14), shadowOpacity: .14),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 46, radius: 17, colors: const [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Colors.white),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, color: AppColor.ink, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.3, color: Color(0xFF60708B), fontWeight: FontWeight.w800, height: 1.55))])),
        if (action != null) ...[const SizedBox(width: 8), HtmlButton(label: action!, onTap: onTap ?? () {}, color1: AppColor.green, color2: AppColor.cyan, compact: true)],
      ]),
    );
  }
}

class GamesFrame extends StatelessWidget {
  final ValueChanged<GameDef> onStart;
  const GamesFrame({super.key, required this.onStart});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: -4),
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 9),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white.withOpacity(.28), const Color(0xFFEEF8FF).withOpacity(.22)]),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withOpacity(.48)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SectionTitle(title: 'بازی‌ها', hint: 'اسکرول کن'),
        SizedBox(
          height: 206,
          child: ListView.separated(
            reverse: true,
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(8, 2, 8, 7),
            itemCount: games.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) => GameCard(game: games[index], onTap: () => onStart(games[index])),
          ),
        ),
      ]),
    );
  }
}

class GameCard extends StatelessWidget {
  final GameDef game;
  final VoidCallback onTap;
  const GameCard({super.key, required this.game, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 214,
        padding: const EdgeInsets.all(14),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF0FBFF)], radius: 26, border: AppColor.cyan.withOpacity(.13)),
        child: Stack(children: [
          Positioned(left: -34, bottom: -48, child: CircleBlob(size: 122, color: game.c1.withOpacity(.14))),
          Positioned.fill(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                HtmlIconBox(icon: game.icon, size: 52, radius: 18, colors: [game.c1, game.c2], iconColor: Colors.white),
                MiniChip(text: game.mode == 'speed' ? 'رکوردی' : 'ادامه'),
              ]),
              const SizedBox(height: 8),
              Text(game.title, style: const TextStyle(fontSize: 16.5, height: 1.35, fontWeight: FontWeight.w900, color: AppColor.ink)),
              const SizedBox(height: 5),
              Text(game.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.2, height: 1.6, fontWeight: FontWeight.w700, color: AppColor.muted)),
              const SizedBox(height: 8),
              HtmlProgress(value: .28, colors: [game.c1, game.c2], height: 8),
              const Spacer(),
              Row(children: [MiniChip(text: '${game.energy} انرژی'), const SizedBox(width: 6), const MiniChip(text: 'لیگ برنزی')]),
            ]),
          ),
        ]),
      ),
    );
  }
}

class RewardsPage extends StatelessWidget {
  final PlayerState state;
  final VoidCallback onDaily;
  final VoidCallback onAd;
  const RewardsPage({super.key, required this.state, required this.onDaily, required this.onAd});
  @override
  Widget build(BuildContext context) {
    final claimed = state.dailyDate == DateTime.now().toIso8601String().substring(0, 10);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'جایزه‌ها و مأموریت‌ها', subtitle: 'مأموریت‌های روزانه و هفتگی با لیگ فعلی هماهنگ شده‌اند.', icon: 'gift'),
      const SizedBox(height: 14),
      QuestCard(title: 'جایزه روزانه', subtitle: claimed ? 'جایزه امروز دریافت شده است.' : '۱۳۰ سکه؛ با تبلیغ دو برابر می‌شود.', icon: 'gift', c1: AppColor.orange, c2: AppColor.danger, button: claimed ? 'دریافت شد' : 'دریافت', onTap: onDaily),
      const SizedBox(height: 14),
      const SectionTitle(title: 'مأموریت‌های روزانه', hint: 'امروز'),
      MissionProgressCard(title: '۳ مرحله امروز', subtitle: 'امروز ۳ مرحله کامل کن و پاداش بگیر.', value: (state.gamesDone / 3).clamp(0, 1).toDouble(), icon: 'target', c1: AppColor.green, c2: AppColor.cyan),
      const SizedBox(height: 12),
      MissionProgressCard(title: '۳ بازی مختلف', subtitle: '${state.playedGames.length.clamp(0, 3)}/3 بازی مختلف انجام شده.', value: (state.playedGames.length / 3).clamp(0, 1).toDouble(), icon: 'brain', c1: AppColor.cyan, c2: AppColor.green),
      const SizedBox(height: 12),
      QuestCard(title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه + ۱۰ انرژی تستی', icon: 'ad', c1: AppColor.primary, c2: AppColor.cyan, button: 'تماشا', onTap: onAd),
    ]);
  }
}

class ShopPage extends StatelessWidget {
  final PlayerState state;
  final void Function({int coins, int energy, int hints}) onBuy;
  final VoidCallback onAd;
  const ShopPage({super.key, required this.state, required this.onBuy, required this.onAd});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'فروشگاه چالشینو', subtitle: 'بسته‌های سکه و آیتم‌های بازی برای تست اقتصاد داخلی اضافه شدند.', icon: 'shop'),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: ShopStat(value: state.coins.toString(), label: 'سکه')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.energy.toString(), label: 'انرژی')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.hints.toString(), label: 'راهنما'))]),
      const SectionTitle(title: 'بسته‌های سکه', hint: 'اسکرول افقی'),
      SizedBox(
        height: 176,
        child: ListView(scrollDirection: Axis.horizontal, reverse: true, children: [
          ProductTile(title: '۱۰۰۰ سکه', subtitle: 'بسته شروع', icon: 'coin', c1: AppColor.orange, c2: const Color(0xFFFF9F43), onTap: () => onBuy(coins: 1000)),
          ProductTile(title: '۵۰ انرژی', subtitle: 'برای بازی بیشتر', icon: 'energy', c1: AppColor.cyan, c2: AppColor.primary, onTap: () => onBuy(energy: 50)),
          ProductTile(title: '۵ راهنما', subtitle: 'کمک داخل بازی', icon: 'riddle', c1: AppColor.green, c2: AppColor.cyan, onTap: () => onBuy(hints: 5)),
          ProductTile(title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه رایگان', icon: 'ad', c1: AppColor.primary, c2: AppColor.orange, onTap: onAd),
        ]),
      ),
      const SizedBox(height: 12),
      const HtmlNote(text: 'پرداخت واقعی در نسخه مارکتی فعال می‌شود. این بخش فعلاً تستی است.'),
    ]);
  }
}

class LeaguePage extends StatelessWidget {
  final PlayerState state;
  final LeagueRule league;
  const LeaguePage({super.key, required this.state, required this.league});
  @override
  Widget build(BuildContext context) {
    final next = leagueRules.firstWhere((l) => l.min > (state.xp + state.bestSpeed * 40 + state.correct * 10), orElse: () => leagueRules.last);
    final value = next == league ? 1.0 : ((state.xp + state.bestSpeed * 40 + state.correct * 10) / next.min).clamp(0, 1).toDouble();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      MiniHero(title: 'لیگ ${league.name}', subtitle: 'تا لیگ بعدی: XP ${next.min}', icon: 'medal', trailing: 'XP ${state.xp}'),
      const SizedBox(height: 12),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: htmlCard(colors: const [Color(0xFFFFF9E8), Colors.white, Color(0xFFF5FBFF)], radius: 30, border: AppColor.orange.withOpacity(.18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [const HtmlIconBox(icon: 'medal', size: 60, radius: 22, colors: [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Colors.white), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('لیگ فعلی تو: ${league.name}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 6), Text('پاداش سکه ×${league.coin} • XP ×${league.xp}', style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))]))]),
          const SizedBox(height: 16),
          HtmlProgress(value: value, colors: const [AppColor.orange, AppColor.cyan]),
        ]),
      ),
      const SectionTitle(title: 'رتبه‌بندی کامل', hint: 'نمونه تستی'),
      RankRow(name: 'بازیکن چالشینو', score: state.xp, active: true),
      const RankRow(name: 'هانا', score: 390),
      const RankRow(name: 'آرمان', score: 310),
      const RankRow(name: 'سارا', score: 280),
    ]);
  }
}

class ProfilePage extends StatelessWidget {
  final PlayerState state;
  const ProfilePage({super.key, required this.state});
  @override
  Widget build(BuildContext context) {
    final success = state.correct + state.wrong == 0 ? 0 : ((state.correct / (state.correct + state.wrong)) * 100).round();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'پروفایل کامل‌تر', subtitle: 'آمار، تنظیمات و دستاوردها', icon: 'profile'),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: ShopStat(value: state.gamesDone.toString(), label: 'بازی')), const SizedBox(width: 8), Expanded(child: ShopStat(value: '$success%', label: 'موفقیت')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.bestSpeed.toString(), label: 'رکورد سرعت'))]),
      const SectionTitle(title: 'دستاوردها', hint: 'مدال‌ها'),
      if (state.achievements.isEmpty) const HtmlNote(text: 'هنوز مدالی نگرفتی. چند بازی انجام بده تا مدال‌ها فعال شوند.') else ...state.achievements.map((a) => Padding(padding: const EdgeInsets.only(bottom: 10), child: QuestCard(title: a, subtitle: 'دستاورد فعال شده', icon: 'star', c1: AppColor.orange, c2: AppColor.primary, button: 'فعال', onTap: () {}))),
      const SectionTitle(title: 'تنظیمات بازی', hint: 'تستی'),
      const SettingsLikeCard(title: 'صدا', subtitle: 'برای نسخه Flutter به صداهای بازی وصل می‌شود.'),
      const SizedBox(height: 10),
      const SettingsLikeCard(title: 'لرزش', subtitle: 'برای لمس‌ها و جواب درست/غلط در موبایل.'),
    ]);
  }
}

class GamePage extends StatelessWidget {
  final GameDef game;
  final GameLevel level;
  final int levelNumber;
  final int totalLevels;
  final int hearts;
  final int correct;
  final int wrong;
  final int timeLeft;
  final int timeTotal;
  final int? selectedAnswer;
  final bool hintShown;
  final bool memoryPreview;
  final String wordAnswer;
  final List<int> wordPicked;
  final int speedScore;
  final int speedWrong;
  final VoidCallback onBack;
  final ValueChanged<int> onChoice;
  final ValueChanged<int> onWordLetter;
  final VoidCallback onWordBack;
  final VoidCallback onWordClear;
  final VoidCallback onWordSubmit;
  final VoidCallback onHint;

  const GamePage({
    super.key,
    required this.game,
    required this.level,
    required this.levelNumber,
    required this.totalLevels,
    required this.hearts,
    required this.correct,
    required this.wrong,
    required this.timeLeft,
    required this.timeTotal,
    required this.selectedAnswer,
    required this.hintShown,
    required this.memoryPreview,
    required this.wordAnswer,
    required this.wordPicked,
    required this.speedScore,
    required this.speedWrong,
    required this.onBack,
    required this.onChoice,
    required this.onWordLetter,
    required this.onWordBack,
    required this.onWordClear,
    required this.onWordSubmit,
    required this.onHint,
  });

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _gameHeader(),
      const SizedBox(height: 10),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF3FBFF), Color(0xFFFFF7EA)], radius: 26, border: AppColor.primary.withOpacity(.16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          _levelTop(),
          const SizedBox(height: 10),
          if (game.mode != 'speed') HtmlProgress(value: timeTotal <= 0 ? 0 : timeLeft / timeTotal, colors: [game.c1, game.c2], height: 10),
          if (game.mode != 'speed') const SizedBox(height: 10),
          if (game.mode == 'word') _wordBody() else if (game.mode == 'memory') _memoryBody() else if (game.mode == 'speed') _speedBody() else _choiceBody(),
          if (game.mode != 'speed') ...[
            const SizedBox(height: 10),
            if (hintShown) HtmlNote(text: 'راهنما: ${level.hint}'),
            const SizedBox(height: 10),
            Row(children: [Expanded(child: HtmlButton(label: 'راهنما', onTap: onHint, color1: AppColor.orange, color2: AppColor.danger, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'بازگشت', onTap: onBack, color1: AppColor.primary, color2: AppColor.violet, compact: true))]),
          ],
        ]),
      ),
    ]);
  }

  Widget _gameHeader() {
    return Row(children: [
      GestureDetector(onTap: onBack, child: Container(width: 42, height: 42, decoration: htmlCard(colors: const [Colors.white, Color(0xFFEFFBFF)], radius: 16, shadowOpacity: .12), child: const Center(child: Text('‹', style: TextStyle(fontSize: 30, color: AppColor.ink, fontWeight: FontWeight.w900))))),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(game.title, style: const TextStyle(fontSize: 18, color: AppColor.ink, fontWeight: FontWeight.w900)), Text(game.mode == 'speed' ? 'امتیاز: $speedScore • غلط: $speedWrong' : 'قلب‌ها: $hearts • درست: $correct • غلط: $wrong', style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))])),
      HtmlIconBox(icon: game.icon, size: 48, radius: 18, colors: [game.c1, game.c2], iconColor: Colors.white),
    ]);
  }

  Widget _levelTop() {
    final heartsRow = Row(mainAxisSize: MainAxisSize.min, children: List.generate(3, (i) => Padding(padding: const EdgeInsets.only(left: 4), child: Icon(Icons.favorite, size: 18, color: i < hearts ? AppColor.danger : AppColor.danger.withOpacity(.22)))));
    return Row(children: [
      MiniChip(text: game.mode == 'speed' ? '۴۵ ثانیه' : 'مرحله $levelNumber/$totalLevels'),
      const Spacer(),
      if (game.mode != 'speed') heartsRow,
      if (game.mode == 'speed') MiniChip(text: 'زمان $timeLeft'),
    ]);
  }

  Widget _questionBox(String text) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: htmlCard(colors: const [Color(0xFFEEF8FF), Color(0xFFF7F3FF), Color(0xFFFFF8ED)], radius: 24, border: AppColor.primary.withOpacity(.15), shadowOpacity: .10),
      child: Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, height: 1.8, fontWeight: FontWeight.w900, color: AppColor.ink)),
    );
  }

  Widget _choiceBody() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _questionBox(level.q),
      const SizedBox(height: 12),
      ...List.generate(level.options.length, (i) => Padding(
            padding: const EdgeInsets.only(bottom: 9),
            child: _choiceButton(i, level.options[i]),
          )),
    ]);
  }

  Widget _choiceButton(int index, String text) {
    final selected = selectedAnswer == index;
    final isGood = selected && index == level.answer;
    final isBad = selected && index != level.answer;
    final colors = isGood ? const [Color(0xFFE6FFF5), Color(0xFFF4FFFB)] : isBad ? const [Color(0xFFFFEEF3), Color(0xFFFFF8FA)] : const [Colors.white, Color(0xFFEAF7FF), Color(0xFFF2EEFF)];
    return GestureDetector(
      onTap: selectedAnswer == null ? () => onChoice(index) : null,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: htmlCard(colors: colors, radius: 20, border: isGood ? AppColor.green.withOpacity(.35) : isBad ? AppColor.danger.withOpacity(.35) : AppColor.primary.withOpacity(.14), shadowOpacity: .10),
        child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 15, height: 1.4, fontWeight: FontWeight.w900, color: isBad ? AppColor.danger : isGood ? AppColor.green : AppColor.ink)),
      ),
    );
  }

  Widget _wordBody() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _questionBox(level.q),
      const SizedBox(height: 10),
      Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 8, children: level.letters.map((x) => Container(width: 42, height: 42, alignment: Alignment.center, decoration: htmlCard(colors: const [Colors.white, Color(0xFFFFF2D9)], radius: 15, border: AppColor.orange.withOpacity(.22), shadowOpacity: .09), child: Text(x, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColor.ink)))).toList()),
      const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(12), decoration: htmlCard(colors: const [Colors.white, Color(0xFFF7F1FF)], radius: 18, shadowOpacity: .08), child: Text(wordAnswer.isEmpty ? 'جواب را بساز...' : wordAnswer, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppColor.ink))),
      const SizedBox(height: 10),
      Wrap(spacing: 7, runSpacing: 7, alignment: WrapAlignment.center, children: List.generate(level.letters.length, (i) {
        final used = wordPicked.contains(i);
        return GestureDetector(
          onTap: used ? null : () => onWordLetter(i),
          child: Opacity(opacity: used ? .36 : 1, child: Container(width: 40, height: 40, alignment: Alignment.center, decoration: htmlCard(colors: const [Colors.white, Color(0xFFEEF8FF)], radius: 14, shadowOpacity: .08), child: Text(level.letters[i], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColor.ink)))),
        );
      })),
      const SizedBox(height: 10),
      Row(children: [Expanded(child: HtmlButton(label: 'ثبت', onTap: onWordSubmit, color1: AppColor.green, color2: AppColor.cyan, compact: true)), const SizedBox(width: 7), Expanded(child: HtmlButton(label: 'حذف', onTap: onWordBack, color1: AppColor.orange, color2: AppColor.danger, compact: true)), const SizedBox(width: 7), Expanded(child: HtmlButton(label: 'پاک کن', onTap: onWordClear, color1: AppColor.primary, color2: AppColor.violet, compact: true))]),
    ]);
  }

  Widget _memoryBody() {
    if (memoryPreview) {
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _questionBox('این آیتم‌ها را به خاطر بسپار'),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: level.items.map((x) => MiniChip(text: x)).toList()),
        const SizedBox(height: 10),
        const HtmlNote(text: 'بعد از پایان زمان، آیتم‌ها مخفی می‌شوند.'),
      ]);
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _questionBox(level.q),
      const SizedBox(height: 12),
      ...List.generate(level.options.length, (i) => Padding(padding: const EdgeInsets.only(bottom: 9), child: _choiceButton(i, level.options[i]))),
    ]);
  }

  Widget _speedBody() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(children: [Expanded(child: ShopStat(value: timeLeft.toString(), label: 'زمان')), const SizedBox(width: 8), Expanded(child: ShopStat(value: speedScore.toString(), label: 'امتیاز')), const SizedBox(width: 8), Expanded(child: ShopStat(value: speedWrong.toString(), label: 'غلط'))]),
      const SizedBox(height: 10),
      HtmlProgress(value: timeTotal <= 0 ? 0 : timeLeft / timeTotal, colors: [game.c1, game.c2], height: 10),
      const SizedBox(height: 12),
      _questionBox(level.q),
      const SizedBox(height: 12),
      ...List.generate(level.options.length, (i) => Padding(padding: const EdgeInsets.only(bottom: 9), child: _choiceButton(i, level.options[i]))),
      const SizedBox(height: 8),
      HtmlButton(label: 'خروج', onTap: onBack, color1: AppColor.primary, color2: AppColor.violet, compact: true),
    ]);
  }
}

class ResultPage extends StatelessWidget {
  final GameDef game;
  final int correct;
  final int wrong;
  final int coins;
  final int xp;
  final VoidCallback onHome;
  final VoidCallback onReplay;
  final VoidCallback onAd;
  const ResultPage({super.key, required this.game, required this.correct, required this.wrong, required this.coins, required this.xp, required this.onHome, required this.onReplay, required this.onAd});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      MiniHero(title: 'نتیجه ${game.title}', subtitle: 'خلاصه عملکرد این بازی', icon: 'trophy'),
      const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(18), decoration: htmlCard(colors: const [Colors.white, Color(0xFFF3FBFF), Color(0xFFFFF8EE)], radius: 28, border: AppColor.primary.withOpacity(.15)), child: Column(children: [
        const HtmlIconBox(icon: 'trophy', size: 72, radius: 26, colors: [AppColor.cyan, AppColor.primary], iconColor: Colors.white),
        const SizedBox(height: 10),
        const Text('بازی کامل شد', style: TextStyle(fontSize: 22, color: AppColor.ink, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: ShopStat(value: correct.toString(), label: 'درست')), const SizedBox(width: 8), Expanded(child: ShopStat(value: wrong.toString(), label: 'غلط')), const SizedBox(width: 8), Expanded(child: ShopStat(value: coins.toString(), label: 'سکه'))]),
        const SizedBox(height: 8),
        Row(children: [Expanded(child: ShopStat(value: xp.toString(), label: 'XP')), const SizedBox(width: 8), Expanded(child: ShopStat(value: (correct + wrong).toString(), label: 'مرحله')), const SizedBox(width: 8), Expanded(child: ShopStat(value: game.energy.toString(), label: 'انرژی مصرفی'))]),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: HtmlButton(label: 'خانه', onTap: onHome, color1: AppColor.primary, color2: AppColor.violet, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'دوباره', onTap: onReplay, color1: AppColor.green, color2: AppColor.cyan, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'ادامه با تبلیغ', onTap: onAd, color1: AppColor.orange, color2: AppColor.danger, compact: true))]),
      ])),
    ]);
  }
}

class MiniHero extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final String? trailing;
  const MiniHero({super.key, required this.title, required this.subtitle, required this.icon, this.trailing});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 52, radius: 20, colors: const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)], iconColor: AppColor.primary),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, height: 1.45, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 5), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.7, fontWeight: FontWeight.w800, color: AppColor.muted))])),
        if (trailing != null) MiniChip(text: trailing!),
      ]),
    );
  }
}

class MissionProgressCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final double value;
  final String icon;
  final Color c1;
  final Color c2;
  const MissionProgressCard({super.key, required this.title, required this.subtitle, required this.value, required this.icon, required this.c1, required this.c2});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 54, radius: 20, colors: [c1, c2], iconColor: Colors.white),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 8), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.6, fontWeight: FontWeight.w800, color: AppColor.muted)), const SizedBox(height: 9), HtmlProgress(value: value, colors: [c1, c2])])),
      ]),
    );
  }
}

class QuestCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color c1;
  final Color c2;
  final String button;
  final VoidCallback onTap;
  const QuestCard({super.key, required this.title, required this.subtitle, required this.icon, required this.c1, required this.c2, required this.button, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 56, radius: 20, colors: [c1, c2], iconColor: Colors.white),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 6), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.7, fontWeight: FontWeight.w800, color: AppColor.muted))])),
        const SizedBox(width: 8),
        HtmlButton(label: button, onTap: onTap, color1: AppColor.green, color2: AppColor.cyan, compact: true),
      ]),
    );
  }
}

class ProductTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color c1;
  final Color c2;
  final VoidCallback onTap;
  const ProductTile({super.key, required this.title, required this.subtitle, required this.icon, required this.c1, required this.c2, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 148,
        margin: const EdgeInsets.only(left: 10),
        padding: const EdgeInsets.all(13),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF5FBFF)], radius: 24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          HtmlIconBox(icon: icon, size: 48, radius: 17, colors: [c1, c2], iconColor: Colors.white),
          const Spacer(),
          Text(title, style: const TextStyle(fontSize: 14.5, color: AppColor.ink, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text(subtitle, style: const TextStyle(fontSize: 11.5, color: AppColor.muted, fontWeight: FontWeight.w800, height: 1.5)),
        ]),
      ),
    );
  }
}

class RankRow extends StatelessWidget {
  final String name;
  final int score;
  final bool active;
  const RankRow({super.key, required this.name, required this.score, this.active = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: htmlCard(colors: active ? const [Color(0xFFEFFFF8), Color(0xFFF5FBFF)] : const [Colors.white, Color(0xFFF4FBFF)], radius: 24, border: active ? AppColor.green.withOpacity(.24) : null, shadowOpacity: .12),
      child: Row(children: [HtmlIconBox(icon: active ? 'profile' : 'star', size: 42, radius: 16), const SizedBox(width: 10), Expanded(child: Text(name, style: const TextStyle(fontSize: 14, color: AppColor.ink, fontWeight: FontWeight.w900))), MiniChip(text: '$score امتیاز')]),
    );
  }
}

class ShopStat extends StatelessWidget {
  final String value;
  final String label;
  const ShopStat({super.key, required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF0FBFF)], radius: 20, shadowOpacity: .10),
        child: Column(children: [Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 11.2, color: AppColor.muted, fontWeight: FontWeight.w800))]),
      );
}

class SettingsLikeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const SettingsLikeCard({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: htmlCard(radius: 22, shadowOpacity: .10),
        child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(fontSize: 11.5, height: 1.7, color: AppColor.muted, fontWeight: FontWeight.w800))])), const MiniChip(text: 'روشن')]),
      );
}

class HtmlNote extends StatelessWidget {
  final String text;
  const HtmlNote({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFF7FBFF)]), border: Border.all(color: AppColor.primary.withOpacity(.18)), borderRadius: BorderRadius.circular(22)),
        child: Text(text, style: const TextStyle(fontSize: 12, height: 1.8, fontWeight: FontWeight.w800, color: AppColor.muted)),
      );
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String hint;
  const SectionTitle({super.key, required this.title, required this.hint});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 14, 2, 10),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(title, style: const TextStyle(fontSize: 18, color: AppColor.ink, fontWeight: FontWeight.w900)), Text(hint, style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))]),
      );
}

class HtmlProgress extends StatelessWidget {
  final double value;
  final List<Color> colors;
  final double height;
  const HtmlProgress({super.key, required this.value, required this.colors, this.height = 9});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(99),
        child: Container(
          height: height,
          color: const Color(0xFFE8F2FB),
          child: Align(alignment: Alignment.centerRight, child: FractionallySizedBox(widthFactor: value.clamp(0, 1).toDouble(), child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: colors), borderRadius: BorderRadius.circular(99))))),
        ),
      );
}

class MiniChip extends StatelessWidget {
  final String text;
  const MiniChip({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFF0F8FF)]), border: Border.all(color: AppColor.cyan.withOpacity(.14)), borderRadius: BorderRadius.circular(999)),
        child: Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF344260))),
      );
}

class HtmlButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color1;
  final Color color2;
  final bool compact;
  const HtmlButton({super.key, required this.label, required this.onTap, required this.color1, required this.color2, this.compact = false});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: compact ? 11 : 16, vertical: compact ? 9 : 13),
          decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [color1, color2]), borderRadius: BorderRadius.circular(compact ? 16 : 19), boxShadow: [BoxShadow(color: const Color(0xFF374696).withOpacity(.15), blurRadius: 24, offset: const Offset(0, 12))]),
          child: Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: compact ? 11.5 : 14, fontWeight: FontWeight.w900, color: Colors.white)),
        ),
      );
}

class HtmlBottomNav extends StatelessWidget {
  final String active;
  final ValueChanged<String> onTap;
  const HtmlBottomNav({super.key, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('rewards', 'جایزه‌ها', 'gift'),
      ('league', 'لیگ', 'trophy'),
      ('home', 'خانه', 'home'),
      ('shop', 'فروشگاه', 'shop'),
      ('profile', 'پروفایل', 'profile'),
    ];
    return Container(
      color: Colors.transparent,
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: SizedBox(
        height: 94,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: items.map((it) {
            final selected = active == it.$1;
            final isHome = it.$1 == 'home';
            return Expanded(
              child: GestureDetector(
                onTap: () => onTap(it.$1),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  height: isHome ? 86 : 72,
                  margin: EdgeInsets.only(top: isHome ? 0 : 10, left: 5, right: 5),
                  decoration: BoxDecoration(
                    gradient: selected || isHome ? const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [AppColor.cyan, AppColor.primary, AppColor.orange]) : const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFEFFBFF)]),
                    borderRadius: BorderRadius.circular(isHome ? 28 : 20),
                    border: Border.all(color: selected || isHome ? Colors.white.withOpacity(.50) : AppColor.cyan.withOpacity(.14)),
                    boxShadow: [BoxShadow(color: const Color(0xFF374696).withOpacity(selected || isHome ? .22 : .12), blurRadius: selected || isHome ? 26 : 18, offset: const Offset(0, 10))],
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [HtmlSvgIcon(it.$3, size: isHome ? 31 : 25, color: selected || isHome ? Colors.white : const Color(0xFF5C6B82)), const SizedBox(height: 5), Text(it.$2, maxLines: 1, style: TextStyle(fontSize: isHome ? 12 : 11, color: selected || isHome ? Colors.white : const Color(0xFF53627B), fontWeight: FontWeight.w900))]),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class HtmlIconBox extends StatelessWidget {
  final String icon;
  final double size;
  final double radius;
  final List<Color>? colors;
  final Color iconColor;
  const HtmlIconBox({super.key, required this.icon, required this.size, required this.radius, this.colors, this.iconColor = AppColor.primary});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors ?? const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)]),
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: AppColor.primary.withOpacity(.16)),
          boxShadow: [BoxShadow(color: const Color(0xFF4C56AA).withOpacity(.14), blurRadius: 24, offset: const Offset(0, 14))],
        ),
        child: Center(child: HtmlSvgIcon(icon, size: size * .55, color: iconColor)),
      );
}

class HtmlSvgIcon extends StatelessWidget {
  final String name;
  final double size;
  final Color color;
  const HtmlSvgIcon(this.name, {super.key, required this.size, required this.color});
  @override
  Widget build(BuildContext context) {
    final path = svgPaths[name] ?? svgPaths['star']!;
    final svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">$path</svg>';
    return SvgPicture.string(svg, width: size, height: size, colorFilter: ColorFilter.mode(color, BlendMode.srcIn));
  }
}

const svgPaths = <String, String>{
  'brain': r'''<path d="M9 6.4c-2.1.2-3.6 1.8-3.6 3.8 0 1 .4 1.9 1 2.5-.8.6-1.3 1.5-1.3 2.6 0 1.8 1.5 3.3 3.3 3.3h1.1V6.4Z"/><path d="M15 6.4c2.1.2 3.6 1.8 3.6 3.8 0 1-.4 1.9-1 2.5.8.6 1.3 1.5 1.3 2.6 0 1.8-1.5 3.3-3.3 3.3h-1.1V6.4Z"/><path d="M9.5 9.5H7.8M14.5 9.5h1.7M9.5 13H7.6M14.5 13h1.9M9.5 16.4H8.2M14.5 16.4h1.3"/>''',
  'coin': r'''<circle cx="12" cy="12" r="8"/><path d="M9 10.2c.7-1 2-1.5 3.3-1.2 1.5.3 2.7 1.5 2.7 3s-1.2 2.7-2.7 3c-1.3.3-2.6-.2-3.3-1.2"/><path d="M8.5 12h6"/>''',
  'energy': r'''<path d="M13 2.8 5.5 13h5.2L9.8 21.2 18.5 10h-5.3L13 2.8Z"/>''',
  'profile': r'''<circle cx="12" cy="8" r="3.6"/><path d="M4.8 20c1.2-4.2 13.2-4.2 14.4 0"/>''',
  'home': r'''<path d="M3.5 11.2 12 4l8.5 7.2"/><path d="M6.2 10.5v9h11.6v-9"/><path d="M10 19.5v-5h4v5"/>''',
  'gift': r'''<path d="M4.5 9h15v11h-15z"/><path d="M3.5 9h17V6.2h-17z"/><path d="M12 6.2V20"/><path d="M12 6.2C10.8 3 7.3 3.2 7.3 5.4c0 1.5 2.2 1.8 4.7.8ZM12 6.2c1.2-3.2 4.7-3 4.7-.8 0 1.5-2.2 1.8-4.7.8Z"/>''',
  'trophy': r'''<path d="M8 4h8v4.8c0 2.2-1.8 4-4 4s-4-1.8-4-4V4Z"/><path d="M8 6H5.2c0 3.8 2 5.4 4.3 5.6M16 6h2.8c0 3.8-2 5.4-4.3 5.6M12 12.8v3.8M8.8 20h6.4M10 16.6h4"/>''',
  'shop': r'''<path d="M5.2 9.5h13.6l-1 10H6.2l-1-10Z"/><path d="M8.5 9.5V8a3.5 3.5 0 0 1 7 0v1.5"/><path d="M4 9.5h16"/>''',
  'riddle': r'''<path d="M9 18h6M9.5 21h5"/><path d="M8.2 14.5c-1.3-1.1-2-2.7-2-4.4a5.8 5.8 0 0 1 11.6 0c0 1.7-.7 3.3-2 4.4-.8.7-1.1 1.4-1.2 2H9.4c-.1-.6-.4-1.3-1.2-2Z"/><path d="M10.8 10.3c.2-1.8 2.8-1.7 2.8.1 0 1.3-1.6 1.4-1.6 2.6M12 15h.1"/>''',
  'word': r'''<path d="M5 18 9.3 6h1.4L15 18M6.5 14h7"/><path d="M17 8h2.5M17 12h2.5M17 16h2.5"/>''',
  'speed': r'''<circle cx="12" cy="13" r="7"/><path d="M9 3h6M12 13V9M12 13l3 2"/>''',
  'logic': r'''<path d="M8 4h4v4H8zM12 8h4v4h-4zM8 12h4v4H8zM12 16h4v4h-4z"/><path d="M12 6h2M10 10h2M12 14h2"/>''',
  'picture': r'''<path d="M3.5 12s3.2-5.2 8.5-5.2 8.5 5.2 8.5 5.2-3.2 5.2-8.5 5.2S3.5 12 3.5 12Z"/><circle cx="12" cy="12" r="2.8"/>''',
  'ad': r'''<rect x="4" y="6" width="16" height="12" rx="3"/><path d="m10 10 5 2.5-5 2.5Z"/>''',
  'target': r'''<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1.2"/>''',
  'medal': r'''<path d="M8 3h8l-2 5h-4L8 3Z"/><circle cx="12" cy="14" r="5"/><path d="M12 11.5v4.8M9.8 14h4.4"/>''',
  'star': r'''<path d="m12 3 2.4 5 5.5.8-4 3.9.9 5.5-4.8-2.6-4.8 2.6.9-5.5-4-3.9 5.5-.8L12 3Z"/>''',
  'check': r'''<path d="m5 12 4 4 10-10"/>''',
  'truefalse': r'''<path d="m4 7 4 4 5-7"/><path d="M14 8h6M14 12h6M5 18h14"/>''',
  'yesno': r'''<path d="m5 12 4 4 10-10"/><path d="M4 5h16M4 19h16"/>''',
  'typo': r'''<path d="M5 6h14M7 6v12M17 6v12"/><path d="M8 18h3M15 18h3"/>''',
};
