import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ChaleshinoApp());
}

class AppColor {
  static const bg = Color(0xFFE8EEF9);
  static const paper = Color(0xFFFFFEFA);
  static const ink = Color(0xFF18243B);
  static const muted = Color(0xFF66758F);
  static const primary = Color(0xFF6C63FF);
  static const violet = Color(0xFF8F6CFF);
  static const cyan = Color(0xFF14C8D8);
  static const green = Color(0xFF18BF8F);
  static const orange = Color(0xFFFFB84D);
  static const danger = Color(0xFFFF5C7A);
}

List<BoxShadow> htmlShadow({double opacity = .18, double blur = 34, Offset offset = const Offset(0, 18)}) => [
      BoxShadow(color: const Color(0xFF374696).withOpacity(opacity), blurRadius: blur, offset: offset),
      BoxShadow(color: Colors.white.withOpacity(.78), blurRadius: 0, offset: const Offset(0, 1)),
    ];

BoxDecoration htmlCard({
  List<Color> colors = const [Colors.white, Color(0xFFF4FBFF)],
  double radius = 30,
  Color? border,
  double shadowOpacity = .18,
}) {
  return BoxDecoration(
    gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors),
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: border ?? AppColor.cyan.withOpacity(.13)),
    boxShadow: htmlShadow(opacity: shadowOpacity),
  );
}

class ChaleshinoApp extends StatelessWidget {
  const ChaleshinoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'چالشینو',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Tahoma',
        scaffoldBackgroundColor: AppColor.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColor.primary),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: ChaleshinoRoot()),
    );
  }
}

class GameDef {
  final String id;
  final String title;
  final String description;
  final String icon;
  final int energy;
  final Color c1;
  final Color c2;
  final List<String> questions;

  const GameDef(this.id, this.title, this.description, this.icon, this.energy, this.c1, this.c2, this.questions);
}

const games = <GameDef>[
  GameDef('riddle', 'چیستان', 'به معماها سریع جواب بده و سکه بگیر.', 'riddle', 3, Color(0xFF14C8D8), Color(0xFF18BF8F), ['چیزی که هرچه بیشتر برداری، بزرگ‌تر می‌شود؟', 'کدام ماه ۲۸ روز دارد؟', 'آن چیست که پا ندارد ولی راه می‌رود؟']),
  GameDef('word', 'حدس کلمه', 'با حروف داده‌شده جواب درست را بساز.', 'word', 4, Color(0xFF6C63FF), Color(0xFF8F6CFF), ['از آسمان می‌بارد و زمین را خیس می‌کند.', 'برای خواندن از آن استفاده می‌کنیم.', 'محل زندگی انسان.']),
  GameDef('memory', 'حافظه سریع', 'ترتیب نمایش را به خاطر بسپار.', 'brain', 4, Color(0xFFFFB84D), Color(0xFFFF5C7A), ['آیتم دوم چه بود؟', 'کدام مورد در لیست بود؟', 'ترتیب درست کدام است؟']),
  GameDef('speed', 'چالش سرعتی', 'در زمان کم بیشترین جواب درست را بده.', 'speed', 5, Color(0xFF14C8D8), Color(0xFF6C63FF), ['جواب سریع را انتخاب کن.', 'کدام گزینه درست است؟', 'رکوردت را بهتر کن.']),
  GameDef('logic', 'معمای منطقی', 'با دقت فکر کن و جواب بده.', 'logic', 5, Color(0xFF18BF8F), Color(0xFF14C8D8), ['اگر همه الف‌ها ب باشند، نتیجه چیست؟', 'عدد بعدی دنباله را پیدا کن.', 'کدام گزینه منطقی‌تر است؟']),
  GameDef('picture', 'معمای تصویری', 'از روی تصویر و نشانه جواب را پیدا کن.', 'picture', 4, Color(0xFF8F6CFF), Color(0xFFFFB84D), ['این نشانه به چه چیزی اشاره دارد؟', 'کدام تصویر با جواب هماهنگ است؟', 'رابطه بین نشانه‌ها چیست؟']),
];

class PlayerState {
  int coins;
  int energy;
  int xp;
  int hints;
  int gamesDone;
  int correct;
  int wrong;
  int ads;
  Set<String> achievements;

  PlayerState({this.coins = 970, this.energy = 50, this.xp = 0, this.hints = 3, this.gamesDone = 0, this.correct = 0, this.wrong = 0, this.ads = 0, Set<String>? achievements}) : achievements = achievements ?? <String>{};

  Map<String, dynamic> toJson() => {
        'coins': coins,
        'energy': energy,
        'xp': xp,
        'hints': hints,
        'gamesDone': gamesDone,
        'correct': correct,
        'wrong': wrong,
        'ads': ads,
        'achievements': achievements.toList(),
      };

  factory PlayerState.fromJson(Map<String, dynamic> json) => PlayerState(
        coins: json['coins'] ?? 970,
        energy: json['energy'] ?? 50,
        xp: json['xp'] ?? 0,
        hints: json['hints'] ?? 3,
        gamesDone: json['gamesDone'] ?? 0,
        correct: json['correct'] ?? 0,
        wrong: json['wrong'] ?? 0,
        ads: json['ads'] ?? 0,
        achievements: Set<String>.from(json['achievements'] ?? const []),
      );
}

class ChaleshinoRoot extends StatefulWidget {
  const ChaleshinoRoot({super.key});

  @override
  State<ChaleshinoRoot> createState() => _ChaleshinoRootState();
}

class _ChaleshinoRootState extends State<ChaleshinoRoot> {
  PlayerState state = PlayerState();
  String tab = 'home';
  GameDef? activeGame;
  int qIndex = 0;
  int hearts = 3;
  int runCorrect = 0;
  int runWrong = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('chaleshino_flutter_v5_state');
    if (saved == null) return;
    try {
      setState(() => state = PlayerState.fromJson(jsonDecode(saved)));
    } catch (_) {}
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('chaleshino_flutter_v5_state', jsonEncode(state.toJson()));
  }

  void openTab(String next) => setState(() {
        tab = next;
        activeGame = null;
      });

  void startGame(GameDef game) {
    if (state.energy < game.energy) {
      _toast('انرژی کافی نیست');
      return;
    }
    setState(() {
      state.energy -= game.energy;
      activeGame = game;
      tab = 'game';
      qIndex = 0;
      hearts = 3;
      runCorrect = 0;
      runWrong = 0;
    });
    _save();
  }

  void answer(bool ok) {
    setState(() {
      if (ok) {
        runCorrect++;
        state.correct++;
        state.coins += 18;
        state.xp += 22;
      } else {
        runWrong++;
        state.wrong++;
        hearts = math.max(0, hearts - 1);
      }
      if (hearts <= 0 || qIndex >= 2) {
        state.gamesDone++;
        if (state.gamesDone >= 3) state.achievements.add('۳ بازی انجام‌شده');
        if (state.correct >= 10) state.achievements.add('۱۰ جواب درست');
        if (state.xp >= 450) state.achievements.add('رسیدن به لیگ بعدی');
        tab = 'result';
      } else {
        qIndex++;
      }
    });
    _save();
  }

  void claimDaily() {
    setState(() {
      state.coins += 130;
      state.energy += 10;
      state.achievements.add('دریافت جایزه روزانه');
    });
    _save();
    _toast('جایزه روزانه دریافت شد');
  }

  void watchAd() {
    setState(() {
      state.ads++;
      state.coins += 150;
      state.energy += 10;
      state.achievements.add('تماشای تبلیغ جایزه‌دار');
    });
    _save();
    _toast('۱۵۰ سکه و ۱۰ انرژی اضافه شد');
  }

  void buy({int coins = 0, int energy = 0, int hints = 0}) {
    setState(() {
      state.coins += coins;
      state.energy += energy;
      state.hints += hints;
    });
    _save();
    _toast('بسته اضافه شد');
  }

  void _toast(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: AppColor.ink, fontWeight: FontWeight.w900)),
        backgroundColor: Colors.white,
        behavior: SnackBarBehavior.floating,
        elevation: 18,
        margin: const EdgeInsets.fromLTRB(34, 0, 34, 104),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: AppColor.cyan.withOpacity(.16))),
        duration: const Duration(milliseconds: 1100),
      ),
    );
  }

  Widget _page() {
    switch (tab) {
      case 'shop':
        return ShopPage(state: state, onBuy: buy, onAd: watchAd);
      case 'rewards':
        return RewardsPage(state: state, onDaily: claimDaily, onAd: watchAd);
      case 'league':
        return LeaguePage(state: state);
      case 'profile':
        return ProfilePage(state: state);
      case 'game':
        return GamePage(game: activeGame ?? games.first, qIndex: qIndex, hearts: hearts, correct: runCorrect, wrong: runWrong, onBack: () => openTab('home'), onAnswer: answer);
      case 'result':
        return ResultPage(game: activeGame ?? games.first, correct: runCorrect, wrong: runWrong, onHome: () => openTab('home'), onReplay: () => startGame(activeGame ?? games.first), onAd: watchAd);
      default:
        return HomePage(state: state, onStart: startGame, onAd: watchAd);
    }
  }

  @override
  Widget build(BuildContext context) {
    final showNav = tab != 'game' && tab != 'result';
    return Scaffold(
      backgroundColor: AppColor.bg,
      bottomNavigationBar: showNav ? HtmlBottomNav(active: tab, onTap: openTab) : null,
      body: HtmlBackground(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Column(
              children: [
                SafeArea(bottom: false, child: TopBar(state: state, onProfile: () => openTab('profile'))),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 160),
                    child: ListView(
                      key: ValueKey(tab),
                      padding: EdgeInsets.fromLTRB(16, tab == 'home' ? 6 : 14, 16, showNav ? 26 : 20),
                      children: [_page()],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HtmlBackground extends StatelessWidget {
  final Widget child;
  const HtmlBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFE4EBF7), Color(0xFFF1F6FF), Color(0xFFE7E1FF)], stops: [0, .46, 1]),
      ),
      child: Stack(
        children: [
          Positioned(top: -70, right: -70, child: CircleBlob(size: 220, color: AppColor.primary.withOpacity(.23))),
          Positioned(top: 58, left: -82, child: CircleBlob(size: 204, color: AppColor.cyan.withOpacity(.24))),
          Positioned(bottom: -115, left: 80, child: CircleBlob(size: 250, color: AppColor.orange.withOpacity(.20))),
          CustomPaint(painter: HtmlGridPainter(), size: Size.infinite),
          child,
        ],
      ),
    );
  }
}

class CircleBlob extends StatelessWidget {
  final double size;
  final Color color;
  const CircleBlob({super.key, required this.size, required this.color});
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: BoxDecoration(color: color, shape: BoxShape.circle));
}

class HtmlGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p1 = Paint()..color = AppColor.primary.withOpacity(.052)..strokeWidth = 1;
    final p2 = Paint()..color = AppColor.cyan.withOpacity(.052)..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 34) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p1);
    }
    for (double x = 0; x < size.width; x += 34) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p2);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class TopBar extends StatelessWidget {
  final PlayerState state;
  final VoidCallback onProfile;
  const TopBar({super.key, required this.state, required this.onProfile});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                HtmlIconBox(icon: 'brain', size: 48, radius: 18, colors: const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)], iconColor: AppColor.primary),
                const SizedBox(width: 10),
                const Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('چالشینو', style: TextStyle(fontSize: 22, height: 1.05, fontWeight: FontWeight.w900, color: AppColor.ink)),
                      SizedBox(height: 4),
                      Text('نسخه تستی v52', style: TextStyle(fontSize: 11, color: Color(0xFF6D7893), fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Wrap(
            textDirection: TextDirection.ltr,
            spacing: 7,
            runSpacing: 7,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              GestureDetector(onTap: onProfile, child: HtmlIconBox(icon: 'profile', size: 44, radius: 18, colors: const [Colors.white, Color(0xFFEFFBFF)], iconColor: AppColor.primary)),
              WalletPill(icon: 'energy', value: state.energy.toString()),
              WalletPill(icon: 'coin', value: state.coins.toString()),
            ],
          ),
        ],
      ),
    );
  }
}

class WalletPill extends StatelessWidget {
  final String icon;
  final String value;
  const WalletPill({super.key, required this.icon, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFEFFBFF)]),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColor.cyan.withOpacity(.16)),
        boxShadow: [BoxShadow(color: const Color(0xFF374696).withOpacity(.15), blurRadius: 24, offset: const Offset(0, 12))],
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [HtmlSvgIcon(icon, size: 18, color: icon == 'coin' ? AppColor.orange : AppColor.primary), const SizedBox(width: 6), Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: AppColor.ink))]),
    );
  }
}

class HomePage extends StatelessWidget {
  final PlayerState state;
  final ValueChanged<GameDef> onStart;
  final VoidCallback onAd;
  const HomePage({super.key, required this.state, required this.onStart, required this.onAd});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SizedBox(
        height: 106,
        child: ListView(
          scrollDirection: Axis.horizontal,
          reverse: true,
          padding: const EdgeInsets.only(bottom: 10),
          children: [
            HomeAdCard(title: 'تبلیغ ویدئویی جایزه‌دار', subtitle: 'Placement واقعی ثبت شد؛ در HTML فعلاً شبیه‌سازی می‌شود.', icon: 'ad', action: 'تماشا', onTap: onAd),
            const SizedBox(width: 12),
            const HomeAdCard(title: 'تبلیغ بنری', subtitle: 'جایگاه بنری واقعی برای نسخه اندروید آماده شد.', icon: 'gift'),
            const SizedBox(width: 12),
            const HomeAdCard(title: 'بنر دوم تستی', subtitle: 'اسکرول افقی بنرها برای اتصال SDK حفظ شد.', icon: 'star'),
          ],
        ),
      ),
      GamesFrame(onStart: onStart),
      const SizedBox(height: 12),
      const SectionTitle(title: 'مسیر امروز', hint: 'مأموریت روزانه'),
      MissionProgressCard(title: '۳ بازی انجام بده', subtitle: '${state.gamesDone.clamp(0, 3)}/3 بازی ثبت شده', value: (state.gamesDone / 3).clamp(0, 1).toDouble(), icon: 'target', c1: AppColor.green, c2: AppColor.cyan),
      const SizedBox(height: 12),
      MissionProgressCard(title: '۱۰ جواب درست', subtitle: '${state.correct.clamp(0, 10)}/10 جواب درست', value: (state.correct / 10).clamp(0, 1).toDouble(), icon: 'brain', c1: AppColor.orange, c2: AppColor.danger),
    ]);
  }
}

class HomeAdCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final String? action;
  final VoidCallback? onTap;
  const HomeAdCard({super.key, required this.title, required this.subtitle, required this.icon, this.action, this.onTap});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: action == null ? 248 : 292,
      padding: const EdgeInsets.all(12),
      decoration: htmlCard(colors: const [Color(0xFFFFF8EA), Colors.white, Color(0xFFEEFBFF)], radius: 27, border: AppColor.cyan.withOpacity(.14), shadowOpacity: .14),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 46, radius: 17, colors: const [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Colors.white),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, color: AppColor.ink, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.3, color: Color(0xFF60708B), fontWeight: FontWeight.w800, height: 1.55))])),
        if (action != null) ...[const SizedBox(width: 8), HtmlButton(label: action!, onTap: onTap ?? () {}, color1: AppColor.green, color2: AppColor.cyan, compact: true)],
      ]),
    );
  }
}

class GamesFrame extends StatelessWidget {
  final ValueChanged<GameDef> onStart;
  const GamesFrame({super.key, required this.onStart});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: -4),
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 9),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white.withOpacity(.28), const Color(0xFFEEF8FF).withOpacity(.22)]),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withOpacity(.48)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SectionTitle(title: 'بازی‌ها', hint: 'اسکرول کن'),
        SizedBox(
          height: 206,
          child: ListView.separated(
            reverse: true,
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(8, 2, 8, 7),
            itemCount: games.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) => GameCard(game: games[index], onTap: () => onStart(games[index])),
          ),
        ),
      ]),
    );
  }
}

class GameCard extends StatelessWidget {
  final GameDef game;
  final VoidCallback onTap;
  const GameCard({super.key, required this.game, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 214,
        padding: const EdgeInsets.all(14),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF0FBFF)], radius: 26, border: AppColor.cyan.withOpacity(.13)),
        child: Stack(children: [
          Positioned(left: -34, bottom: -48, child: CircleBlob(size: 122, color: game.c1.withOpacity(.14))),
          Positioned.fill(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                HtmlIconBox(icon: game.icon, size: 52, radius: 18, colors: [game.c1, game.c2], iconColor: Colors.white),
                MiniChip(text: 'ادامه'),
              ]),
              const SizedBox(height: 8),
              Text(game.title, style: const TextStyle(fontSize: 16.5, height: 1.35, fontWeight: FontWeight.w900, color: AppColor.ink)),
              const SizedBox(height: 5),
              Text(game.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.2, height: 1.6, fontWeight: FontWeight.w700, color: AppColor.muted)),
              const SizedBox(height: 8),
              HtmlProgress(value: .28, colors: [game.c1, game.c2], height: 8),
              const Spacer(),
              Row(children: [MiniChip(text: '${game.energy} انرژی'), const SizedBox(width: 6), MiniChip(text: 'لیگ برنزی')]),
            ]),
          ),
        ]),
      ),
    );
  }
}

class RewardsPage extends StatelessWidget {
  final PlayerState state;
  final VoidCallback onDaily;
  final VoidCallback onAd;
  const RewardsPage({super.key, required this.state, required this.onDaily, required this.onAd});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'جایزه‌ها و مأموریت‌ها', subtitle: 'مأموریت‌های روزانه و هفتگی با لیگ فعلی هماهنگ شده‌اند.', icon: 'gift'),
      const SizedBox(height: 14),
      QuestCard(title: 'جایزه روزانه', subtitle: '۱۳۰ سکه؛ با تبلیغ دو برابر می‌شود.', icon: 'gift', c1: AppColor.orange, c2: AppColor.danger, button: 'دریافت', onTap: onDaily),
      const SizedBox(height: 14),
      const SectionTitle(title: 'مأموریت‌های روزانه', hint: 'امروز'),
      MissionProgressCard(title: '۳ مرحله امروز', subtitle: 'امروز ۳ مرحله کامل کن و پاداش بگیر.', value: (state.gamesDone / 3).clamp(0, 1).toDouble(), icon: 'target', c1: AppColor.green, c2: AppColor.cyan),
      const SizedBox(height: 12),
      MissionProgressCard(title: '۳ بازی مختلف', subtitle: 'امروز حداقل ۳ نوع بازی مختلف انجام بده.', value: (state.gamesDone / 3).clamp(0, 1).toDouble(), icon: 'brain', c1: AppColor.cyan, c2: AppColor.green),
      const SizedBox(height: 12),
      QuestCard(title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه + ۱۰ انرژی تستی', icon: 'ad', c1: AppColor.primary, c2: AppColor.cyan, button: 'تماشا', onTap: onAd),
    ]);
  }
}

class ShopPage extends StatelessWidget {
  final PlayerState state;
  final void Function({int coins, int energy, int hints}) onBuy;
  final VoidCallback onAd;
  const ShopPage({super.key, required this.state, required this.onBuy, required this.onAd});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'فروشگاه چالشینو', subtitle: 'بسته‌های سکه و آیتم‌های بازی برای تست اقتصاد داخلی اضافه شدند.', icon: 'shop'),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: ShopStat(value: state.coins.toString(), label: 'سکه')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.energy.toString(), label: 'انرژی')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.hints.toString(), label: 'راهنما'))]),
      const SectionTitle(title: 'بسته‌های سکه', hint: 'اسکرول افقی'),
      SizedBox(
        height: 176,
        child: ListView(scrollDirection: Axis.horizontal, reverse: true, children: [
          ProductTile(title: '۱۰۰۰ سکه', subtitle: 'بسته شروع', icon: 'coin', c1: AppColor.orange, c2: const Color(0xFFFF9F43), onTap: () => onBuy(coins: 1000)),
          ProductTile(title: '۵۰ انرژی', subtitle: 'برای بازی بیشتر', icon: 'energy', c1: AppColor.cyan, c2: AppColor.primary, onTap: () => onBuy(energy: 50)),
          ProductTile(title: '۵ راهنما', subtitle: 'کمک داخل بازی', icon: 'riddle', c1: AppColor.green, c2: AppColor.cyan, onTap: () => onBuy(hints: 5)),
          ProductTile(title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه رایگان', icon: 'ad', c1: AppColor.primary, c2: AppColor.orange, onTap: onAd),
        ]),
      ),
      const SizedBox(height: 12),
      const HtmlNote(text: 'پرداخت واقعی در نسخه مارکتی فعال می‌شود. این بخش فعلاً تستی است.'),
    ]);
  }
}

class LeaguePage extends StatelessWidget {
  final PlayerState state;
  const LeaguePage({super.key, required this.state});
  @override
  Widget build(BuildContext context) {
    final value = (state.xp / 450).clamp(0, 1).toDouble();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      MiniHero(title: 'لیگ برنزی', subtitle: 'تا لیگ بعدی: XP 450', icon: 'medal', trailing: 'XP ${state.xp}'),
      const SizedBox(height: 12),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: htmlCard(colors: const [Color(0xFFFFF9E8), Colors.white, Color(0xFFF5FBFF)], radius: 30, border: AppColor.orange.withOpacity(.18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [const HtmlIconBox(icon: 'medal', size: 60, radius: 22, colors: [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Colors.white), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [Text('لیگ فعلی تو', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColor.ink)), SizedBox(height: 6), Text('سختی آسان • پاداش ×۱.۱۵', style: TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))]))]),
          const SizedBox(height: 16),
          HtmlProgress(value: value, colors: const [AppColor.orange, AppColor.cyan]),
        ]),
      ),
      const SectionTitle(title: 'رتبه‌بندی کامل', hint: 'نمونه تستی'),
      RankRow(name: 'بازیکن چالشینو', score: state.xp, active: true),
      const RankRow(name: 'هانا', score: 390),
      const RankRow(name: 'آرمان', score: 310),
      const RankRow(name: 'سارا', score: 280),
    ]);
  }
}

class ProfilePage extends StatelessWidget {
  final PlayerState state;
  const ProfilePage({super.key, required this.state});
  @override
  Widget build(BuildContext context) {
    final success = state.correct + state.wrong == 0 ? 0 : ((state.correct / (state.correct + state.wrong)) * 100).round();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'پروفایل کامل‌تر', subtitle: 'آمار، تنظیمات و دستاوردها', icon: 'profile'),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: ShopStat(value: state.gamesDone.toString(), label: 'بازی')), const SizedBox(width: 8), Expanded(child: ShopStat(value: '$success%', label: 'موفقیت')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.xp.toString(), label: 'XP'))]),
      const SectionTitle(title: 'دستاوردها', hint: 'مدال‌ها'),
      if (state.achievements.isEmpty) const HtmlNote(text: 'هنوز مدالی نگرفتی. چند بازی انجام بده تا مدال‌ها فعال شوند.') else ...state.achievements.map((a) => Padding(padding: const EdgeInsets.only(bottom: 10), child: QuestCard(title: a, subtitle: 'دستاورد فعال شده', icon: 'star', c1: AppColor.orange, c2: AppColor.primary, button: 'فعال', onTap: () {}))),
      const SectionTitle(title: 'تنظیمات بازی', hint: 'تستی'),
      const SettingsLikeCard(title: 'صدا', subtitle: 'برای نسخه Flutter به صداهای بازی وصل می‌شود.'),
      const SizedBox(height: 10),
      const SettingsLikeCard(title: 'لرزش', subtitle: 'برای لمس‌ها و جواب درست/غلط در موبایل.'),
    ]);
  }
}

class GamePage extends StatelessWidget {
  final GameDef game;
  final int qIndex;
  final int hearts;
  final int correct;
  final int wrong;
  final VoidCallback onBack;
  final ValueChanged<bool> onAnswer;
  const GamePage({super.key, required this.game, required this.qIndex, required this.hearts, required this.correct, required this.wrong, required this.onBack, required this.onAnswer});
  @override
  Widget build(BuildContext context) {
    final question = game.questions[qIndex % game.questions.length];
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(children: [
        GestureDetector(onTap: onBack, child: Container(width: 42, height: 42, decoration: htmlCard(colors: const [Colors.white, Color(0xFFEFFBFF)], radius: 16, shadowOpacity: .12), child: const Center(child: Text('‹', style: TextStyle(fontSize: 30, color: AppColor.ink, fontWeight: FontWeight.w900))))),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(game.title, style: const TextStyle(fontSize: 18, color: AppColor.ink, fontWeight: FontWeight.w900)), Text('قلب‌ها: $hearts • درست: $correct • غلط: $wrong', style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))])),
        HtmlIconBox(icon: game.icon, size: 48, radius: 18, colors: [game.c1, game.c2], iconColor: Colors.white),
      ]),
      const SizedBox(height: 14),
      Container(padding: const EdgeInsets.all(18), decoration: htmlCard(colors: const [Color(0xFFEEF8FF), Color(0xFFF7F3FF), Color(0xFFFFF8ED)], radius: 26, border: AppColor.primary.withOpacity(.18)), child: Text(question, textAlign: TextAlign.center, style: const TextStyle(fontSize: 19, height: 1.9, fontWeight: FontWeight.w900, color: AppColor.ink))),
      const SizedBox(height: 14),
      HtmlButton(label: 'جواب درست', onTap: () => onAnswer(true), color1: AppColor.green, color2: AppColor.cyan),
      const SizedBox(height: 10),
      HtmlButton(label: 'جواب غلط', onTap: () => onAnswer(false), color1: AppColor.danger, color2: AppColor.orange),
    ]);
  }
}

class ResultPage extends StatelessWidget {
  final GameDef game;
  final int correct;
  final int wrong;
  final VoidCallback onHome;
  final VoidCallback onReplay;
  final VoidCallback onAd;
  const ResultPage({super.key, required this.game, required this.correct, required this.wrong, required this.onHome, required this.onReplay, required this.onAd});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      MiniHero(title: 'نتیجه ${game.title}', subtitle: 'خلاصه عملکرد این بازی', icon: 'trophy'),
      const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(18), decoration: htmlCard(colors: const [Colors.white, Color(0xFFF3FBFF), Color(0xFFFFF8EE)], radius: 28, border: AppColor.primary.withOpacity(.15)), child: Column(children: [
        const HtmlIconBox(icon: 'trophy', size: 72, radius: 26, colors: [AppColor.cyan, AppColor.primary], iconColor: Colors.white),
        const SizedBox(height: 10),
        const Text('بازی کامل شد', style: TextStyle(fontSize: 22, color: AppColor.ink, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: ShopStat(value: correct.toString(), label: 'درست')), const SizedBox(width: 8), Expanded(child: ShopStat(value: wrong.toString(), label: 'غلط')), const SizedBox(width: 8), Expanded(child: ShopStat(value: '${correct * 18}', label: 'سکه'))]),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: HtmlButton(label: 'خانه', onTap: onHome, color1: AppColor.primary, color2: AppColor.violet, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'دوباره', onTap: onReplay, color1: AppColor.green, color2: AppColor.cyan, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'تبلیغ', onTap: onAd, color1: AppColor.orange, color2: AppColor.danger, compact: true))]),
      ])),
    ]);
  }
}

class MiniHero extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final String? trailing;
  const MiniHero({super.key, required this.title, required this.subtitle, required this.icon, this.trailing});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 52, radius: 20, colors: const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)], iconColor: AppColor.primary),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, height: 1.45, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 5), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.7, fontWeight: FontWeight.w800, color: AppColor.muted))])),
        if (trailing != null) MiniChip(text: trailing!),
      ]),
    );
  }
}

class MissionProgressCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final double value;
  final String icon;
  final Color c1;
  final Color c2;
  const MissionProgressCard({super.key, required this.title, required this.subtitle, required this.value, required this.icon, required this.c1, required this.c2});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 54, radius: 20, colors: [c1, c2], iconColor: Colors.white),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 8), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.6, fontWeight: FontWeight.w800, color: AppColor.muted)), const SizedBox(height: 9), HtmlProgress(value: value, colors: [c1, c2])])),
      ]),
    );
  }
}

class QuestCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color c1;
  final Color c2;
  final String button;
  final VoidCallback onTap;
  const QuestCard({super.key, required this.title, required this.subtitle, required this.icon, required this.c1, required this.c2, required this.button, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 56, radius: 20, colors: [c1, c2], iconColor: Colors.white),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 6), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.7, fontWeight: FontWeight.w800, color: AppColor.muted))])),
        const SizedBox(width: 8),
        HtmlButton(label: button, onTap: onTap, color1: AppColor.green, color2: AppColor.cyan, compact: true),
      ]),
    );
  }
}

class ProductTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color c1;
  final Color c2;
  final VoidCallback onTap;
  const ProductTile({super.key, required this.title, required this.subtitle, required this.icon, required this.c1, required this.c2, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 148,
        margin: const EdgeInsets.only(left: 10),
        padding: const EdgeInsets.all(13),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF5FBFF)], radius: 24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          HtmlIconBox(icon: icon, size: 48, radius: 17, colors: [c1, c2], iconColor: Colors.white),
          const Spacer(),
          Text(title, style: const TextStyle(fontSize: 14.5, color: AppColor.ink, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text(subtitle, style: const TextStyle(fontSize: 11.5, color: AppColor.muted, fontWeight: FontWeight.w800, height: 1.5)),
        ]),
      ),
    );
  }
}

class RankRow extends StatelessWidget {
  final String name;
  final int score;
  final bool active;
  const RankRow({super.key, required this.name, required this.score, this.active = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: htmlCard(colors: active ? const [Color(0xFFEFFFF8), Color(0xFFF5FBFF)] : const [Colors.white, Color(0xFFF4FBFF)], radius: 24, border: active ? AppColor.green.withOpacity(.24) : null, shadowOpacity: .12),
      child: Row(children: [HtmlIconBox(icon: active ? 'profile' : 'star', size: 42, radius: 16), const SizedBox(width: 10), Expanded(child: Text(name, style: const TextStyle(fontSize: 14, color: AppColor.ink, fontWeight: FontWeight.w900))), MiniChip(text: '$score امتیاز')]),
    );
  }
}

class ShopStat extends StatelessWidget {
  final String value;
  final String label;
  const ShopStat({super.key, required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF0FBFF)], radius: 20, shadowOpacity: .10),
        child: Column(children: [Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 11.2, color: AppColor.muted, fontWeight: FontWeight.w800))]),
      );
}

class SettingsLikeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const SettingsLikeCard({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: htmlCard(radius: 22, shadowOpacity: .10),
        child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(fontSize: 11.5, height: 1.7, color: AppColor.muted, fontWeight: FontWeight.w800))])), const MiniChip(text: 'روشن')]),
      );
}

class HtmlNote extends StatelessWidget {
  final String text;
  const HtmlNote({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFF7FBFF)]), border: Border.all(color: AppColor.primary.withOpacity(.18)), borderRadius: BorderRadius.circular(22)),
        child: Text(text, style: const TextStyle(fontSize: 12, height: 1.8, fontWeight: FontWeight.w800, color: AppColor.muted)),
      );
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String hint;
  const SectionTitle({super.key, required this.title, required this.hint});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 14, 2, 10),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(title, style: const TextStyle(fontSize: 18, color: AppColor.ink, fontWeight: FontWeight.w900)), Text(hint, style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))]),
      );
}

class HtmlProgress extends StatelessWidget {
  final double value;
  final List<Color> colors;
  final double height;
  const HtmlProgress({super.key, required this.value, required this.colors, this.height = 9});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(99),
        child: Container(
          height: height,
          color: const Color(0xFFE8F2FB),
          child: Align(alignment: Alignment.centerRight, child: FractionallySizedBox(widthFactor: value.clamp(0, 1).toDouble(), child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: colors), borderRadius: BorderRadius.circular(99))))),
        ),
      );
}

class MiniChip extends StatelessWidget {
  final String text;
  const MiniChip({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFF0F8FF)]), border: Border.all(color: AppColor.cyan.withOpacity(.14)), borderRadius: BorderRadius.circular(999)),
        child: Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF344260))),
      );
}

class HtmlButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color1;
  final Color color2;
  final bool compact;
  const HtmlButton({super.key, required this.label, required this.onTap, required this.color1, required this.color2, this.compact = false});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: compact ? 11 : 16, vertical: compact ? 9 : 13),
          decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [color1, color2]), borderRadius: BorderRadius.circular(compact ? 16 : 19), boxShadow: [BoxShadow(color: const Color(0xFF374696).withOpacity(.15), blurRadius: 24, offset: const Offset(0, 12))]),
          child: Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: compact ? 11.5 : 14, fontWeight: FontWeight.w900, color: Colors.white)),
        ),
      );
}

class HtmlBottomNav extends StatelessWidget {
  final String active;
  final ValueChanged<String> onTap;
  const HtmlBottomNav({super.key, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('rewards', 'جایزه‌ها', 'gift'),
      ('league', 'لیگ', 'trophy'),
      ('home', 'خانه', 'home'),
      ('shop', 'فروشگاه', 'shop'),
      ('profile', 'پروفایل', 'profile'),
    ];
    return Container(
      color: Colors.transparent,
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: SizedBox(
        height: 94,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: items.map((it) {
            final selected = active == it.$1;
            final isHome = it.$1 == 'home';
            return Expanded(
              child: GestureDetector(
                onTap: () => onTap(it.$1),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  height: isHome ? 86 : 72,
                  margin: EdgeInsets.only(top: isHome ? 0 : 10, left: 5, right: 5),
                  decoration: BoxDecoration(
                    gradient: selected || isHome ? const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [AppColor.cyan, AppColor.primary, AppColor.orange]) : const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFEFFBFF)]),
                    borderRadius: BorderRadius.circular(isHome ? 28 : 20),
                    border: Border.all(color: selected || isHome ? Colors.white.withOpacity(.50) : AppColor.cyan.withOpacity(.14)),
                    boxShadow: [BoxShadow(color: const Color(0xFF374696).withOpacity(selected || isHome ? .22 : .12), blurRadius: selected || isHome ? 26 : 18, offset: const Offset(0, 10))],
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [HtmlSvgIcon(it.$3, size: isHome ? 31 : 25, color: selected || isHome ? Colors.white : const Color(0xFF5C6B82)), const SizedBox(height: 5), Text(it.$2, maxLines: 1, style: TextStyle(fontSize: isHome ? 12 : 11, color: selected || isHome ? Colors.white : const Color(0xFF53627B), fontWeight: FontWeight.w900))]),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class HtmlIconBox extends StatelessWidget {
  final String icon;
  final double size;
  final double radius;
  final List<Color>? colors;
  final Color iconColor;
  const HtmlIconBox({super.key, required this.icon, required this.size, required this.radius, this.colors, this.iconColor = AppColor.primary});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors ?? const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)]),
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: AppColor.primary.withOpacity(.16)),
          boxShadow: [BoxShadow(color: const Color(0xFF4C56AA).withOpacity(.14), blurRadius: 24, offset: const Offset(0, 14))],
        ),
        child: Center(child: HtmlSvgIcon(icon, size: size * .55, color: iconColor)),
      );
}

class HtmlSvgIcon extends StatelessWidget {
  final String name;
  final double size;
  final Color color;
  const HtmlSvgIcon(this.name, {super.key, required this.size, required this.color});
  @override
  Widget build(BuildContext context) {
    final path = svgPaths[name] ?? svgPaths['star']!;
    final svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">$path</svg>';
    return SvgPicture.string(svg, width: size, height: size, colorFilter: ColorFilter.mode(color, BlendMode.srcIn));
  }
}

const svgPaths = <String, String>{
  'brain': r'''<path d="M9 6.4c-2.1.2-3.6 1.8-3.6 3.8 0 1 .4 1.9 1 2.5-.8.6-1.3 1.5-1.3 2.6 0 1.8 1.5 3.3 3.3 3.3h1.1V6.4Z"/><path d="M15 6.4c2.1.2 3.6 1.8 3.6 3.8 0 1-.4 1.9-1 2.5.8.6 1.3 1.5 1.3 2.6 0 1.8-1.5 3.3-3.3 3.3h-1.1V6.4Z"/><path d="M9.5 9.5H7.8M14.5 9.5h1.7M9.5 13H7.6M14.5 13h1.9M9.5 16.4H8.2M14.5 16.4h1.3"/>''',
  'coin': r'''<circle cx="12" cy="12" r="8"/><path d="M9 10.2c.7-1 2-1.5 3.3-1.2 1.5.3 2.7 1.5 2.7 3s-1.2 2.7-2.7 3c-1.3.3-2.6-.2-3.3-1.2"/><path d="M8.5 12h6"/>''',
  'energy': r'''<path d="M13 2.8 5.5 13h5.2L9.8 21.2 18.5 10h-5.3L13 2.8Z"/>''',
  'profile': r'''<circle cx="12" cy="8" r="3.6"/><path d="M4.8 20c1.2-4.2 13.2-4.2 14.4 0"/>''',
  'home': r'''<path d="M3.5 11.2 12 4l8.5 7.2"/><path d="M6.2 10.5v9h11.6v-9"/><path d="M10 19.5v-5h4v5"/>''',
  'gift': r'''<path d="M4.5 9h15v11h-15z"/><path d="M3.5 9h17V6.2h-17z"/><path d="M12 6.2V20"/><path d="M12 6.2C10.8 3 7.3 3.2 7.3 5.4c0 1.5 2.2 1.8 4.7.8ZM12 6.2c1.2-3.2 4.7-3 4.7-.8 0 1.5-2.2 1.8-4.7.8Z"/>''',
  'trophy': r'''<path d="M8 4h8v4.8c0 2.2-1.8 4-4 4s-4-1.8-4-4V4Z"/><path d="M8 6H5.2c0 3.8 2 5.4 4.3 5.6M16 6h2.8c0 3.8-2 5.4-4.3 5.6M12 12.8v3.8M8.8 20h6.4M10 16.6h4"/>''',
  'shop': r'''<path d="M5.2 9.5h13.6l-1 10H6.2l-1-10Z"/><path d="M8.5 9.5V8a3.5 3.5 0 0 1 7 0v1.5"/><path d="M4 9.5h16"/>''',
  'riddle': r'''<path d="M9 18h6M9.5 21h5"/><path d="M8.2 14.5c-1.3-1.1-2-2.7-2-4.4a5.8 5.8 0 0 1 11.6 0c0 1.7-.7 3.3-2 4.4-.8.7-1.1 1.4-1.2 2H9.4c-.1-.6-.4-1.3-1.2-2Z"/><path d="M10.8 10.3c.2-1.8 2.8-1.7 2.8.1 0 1.3-1.6 1.4-1.6 2.6M12 15h.1"/>''',
  'word': r'''<path d="M5 18 9.3 6h1.4L15 18M6.5 14h7"/><path d="M17 8h2.5M17 12h2.5M17 16h2.5"/>''',
  'speed': r'''<circle cx="12" cy="13" r="7"/><path d="M9 3h6M12 13V9M12 13l3 2"/>''',
  'logic': r'''<path d="M8 4h4v4H8zM12 8h4v4h-4zM8 12h4v4H8zM12 16h4v4h-4z"/><path d="M12 6h2M10 10h2M12 14h2"/>''',
  'picture': r'''<path d="M3.5 12s3.2-5.2 8.5-5.2 8.5 5.2 8.5 5.2-3.2 5.2-8.5 5.2S3.5 12 3.5 12Z"/><circle cx="12" cy="12" r="2.8"/>''',
  'ad': r'''<rect x="4" y="6" width="16" height="12" rx="3"/><path d="m10 10 5 2.5-5 2.5Z"/>''',
  'target': r'''<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1.2"/>''',
  'medal': r'''<path d="M8 3h8l-2 5h-4L8 3Z"/><circle cx="12" cy="14" r="5"/><path d="M12 11.5v4.8M9.8 14h4.4"/>''',
  'star': r'''<path d="m12 3 2.4 5 5.5.8-4 3.9.9 5.5-4.8-2.6-4.8 2.6.9-5.5-4-3.9 5.5-.8L12 3Z"/>''',
  'check': r'''<path d="m5 12 4 4 10-10"/>''',
};
