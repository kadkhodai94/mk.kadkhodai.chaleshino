import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ChaleshinoApp());
}

class C {
  static const bg = Color(0xFFE8EEF9);
  static const ink = Color(0xFF18243B);
  static const muted = Color(0xFF66758F);
  static const primary = Color(0xFF6C63FF);
  static const primarySoft = Color(0xFF8F6CFF);
  static const cyan = Color(0xFF14C8D8);
  static const green = Color(0xFF18BF8F);
  static const orange = Color(0xFFFFB84D);
  static const danger = Color(0xFFFF5C7A);
  static const blueGrey = Color(0xFF60708C);
}

List<BoxShadow> htmlShadow({double opacity = .18, double blur = 34, Offset offset = const Offset(0, 18)}) => [
      BoxShadow(color: const Color(0xFF374696).withOpacity(opacity), blurRadius: blur, offset: offset),
      BoxShadow(color: Colors.white.withOpacity(.94), blurRadius: 0, offset: const Offset(0, 1)),
    ];

BoxDecoration softCard({List<Color>? colors, double radius = 30, Color? borderColor}) {
  return BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: colors ?? const [Colors.white, Color(0xFFF4FBFF)],
    ),
    border: Border.all(color: borderColor ?? C.cyan.withOpacity(.13)),
    borderRadius: BorderRadius.circular(radius),
    boxShadow: htmlShadow(),
  );
}

BoxDecoration pillDecoration() => BoxDecoration(
      gradient: const LinearGradient(colors: [Colors.white, Color(0xFFEFFBFF)], begin: Alignment.topLeft, end: Alignment.bottomRight),
      border: Border.all(color: C.cyan.withOpacity(.16)),
      borderRadius: BorderRadius.circular(999),
      boxShadow: [BoxShadow(color: const Color(0xFF374696).withOpacity(.15), blurRadius: 24, offset: const Offset(0, 12))],
    );

class ChaleshinoApp extends StatelessWidget {
  const ChaleshinoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'چالشینو',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Tahoma',
        scaffoldBackgroundColor: C.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: C.primary),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: Root()),
    );
  }
}

class AppStateData {
  int coins;
  int energy;
  int xp;
  int hints;
  int streak;
  int totalGames;
  int totalCorrect;
  int totalWrong;
  int adsWatched;
  bool sound;
  bool vibration;
  bool lightMode;
  bool skipTutorial;
  Set<String> achievements;

  AppStateData({
    this.coins = 970,
    this.energy = 50,
    this.xp = 0,
    this.hints = 3,
    this.streak = 0,
    this.totalGames = 0,
    this.totalCorrect = 0,
    this.totalWrong = 0,
    this.adsWatched = 0,
    this.sound = true,
    this.vibration = true,
    this.lightMode = false,
    this.skipTutorial = false,
    Set<String>? achievements,
  }) : achievements = achievements ?? <String>{};

  Map<String, dynamic> toJson() => {
        'coins': coins,
        'energy': energy,
        'xp': xp,
        'hints': hints,
        'streak': streak,
        'totalGames': totalGames,
        'totalCorrect': totalCorrect,
        'totalWrong': totalWrong,
        'adsWatched': adsWatched,
        'sound': sound,
        'vibration': vibration,
        'lightMode': lightMode,
        'skipTutorial': skipTutorial,
        'achievements': achievements.toList(),
      };

  factory AppStateData.fromJson(Map<String, dynamic> json) => AppStateData(
        coins: json['coins'] ?? 970,
        energy: json['energy'] ?? 50,
        xp: json['xp'] ?? 0,
        hints: json['hints'] ?? 3,
        streak: json['streak'] ?? 0,
        totalGames: json['totalGames'] ?? 0,
        totalCorrect: json['totalCorrect'] ?? 0,
        totalWrong: json['totalWrong'] ?? 0,
        adsWatched: json['adsWatched'] ?? 0,
        sound: json['sound'] ?? true,
        vibration: json['vibration'] ?? true,
        lightMode: json['lightMode'] ?? false,
        skipTutorial: json['skipTutorial'] ?? false,
        achievements: Set<String>.from(json['achievements'] ?? const []),
      );
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  AppStateData data = AppStateData();
  String screen = 'home';
  GameDef? activeGame;
  int currentQ = 0;
  int correct = 0;
  int wrong = 0;
  int hearts = 3;
  String? lastResult;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('chaleshino_v4_state');
    if (saved != null) {
      try {
        setState(() => data = AppStateData.fromJson(jsonDecode(saved)));
      } catch (_) {}
    }
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('chaleshino_v4_state', jsonEncode(data.toJson()));
  }

  void go(String tab) => setState(() {
        screen = tab;
        activeGame = null;
      });

  void startGame(GameDef g) {
    if (data.energy < g.energy) {
      _toast('انرژی کافی نیست');
      return;
    }
    setState(() {
      data.energy -= g.energy;
      activeGame = g;
      screen = 'game';
      currentQ = 0;
      correct = 0;
      wrong = 0;
      hearts = 3;
      lastResult = null;
    });
    _save();
  }

  void answer(bool ok) {
    setState(() {
      if (ok) {
        correct++;
        data.coins += activeGame?.coinReward ?? 12;
        data.xp += 18;
        lastResult = 'درست بود، عالیه!';
      } else {
        wrong++;
        hearts = math.max(0, hearts - 1);
        lastResult = 'اشتباه بود، مرحله بعدی.';
      }
      if (hearts <= 0 || currentQ >= 4) {
        data.totalGames++;
        data.totalCorrect += correct;
        data.totalWrong += wrong;
        _unlockAchievements();
        screen = 'result';
      } else {
        currentQ++;
      }
    });
    _save();
  }

  void _unlockAchievements() {
    if (correct >= 3) data.achievements.add('سه جواب درست در یک بازی');
    if (data.totalGames >= 5) data.achievements.add('۵ بازی کامل');
    if (data.xp >= 450) data.achievements.add('ورود به لیگ بعدی');
    if (data.adsWatched >= 1) data.achievements.add('تماشای تبلیغ جایزه‌دار');
  }

  void claimDaily() {
    setState(() {
      data.streak++;
      data.coins += 120;
      data.energy += 10;
    });
    _save();
    _toast('جایزه روزانه دریافت شد');
  }

  void watchAdReward() {
    setState(() {
      data.adsWatched++;
      data.coins += 150;
      data.energy += 10;
      data.achievements.add('تماشای تبلیغ جایزه‌دار');
    });
    _save();
    _toast('۱۵۰ سکه و ۱۰ انرژی اضافه شد');
  }

  void buy(String title, int cost, {int coins = 0, int energy = 0, int hints = 0}) {
    setState(() {
      data.coins += coins;
      data.energy += energy;
      data.hints += hints;
    });
    _save();
    _toast('$title فعال شد');
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, textAlign: TextAlign.center),
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.white,
        elevation: 20,
        margin: const EdgeInsets.only(left: 32, right: 32, bottom: 95),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: C.cyan.withOpacity(.14))),
        duration: const Duration(milliseconds: 1200),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: OriginalBackground(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Stack(
              children: [
                Column(
                  children: [
                    SafeArea(bottom: false, child: TopBar(data: data, onProfile: () => go('profile'))),
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 122),
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 200),
                          child: _body(),
                        ),
                      ),
                    ),
                  ],
                ),
                Align(alignment: Alignment.bottomCenter, child: SafeArea(top: false, child: NavBar(active: screen, onTap: go))),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _body() {
    switch (screen) {
      case 'shop':
        return ShopPage(key: const ValueKey('shop'), data: data, onBuy: buy, onAd: watchAdReward);
      case 'rewards':
        return RewardsPage(key: const ValueKey('rewards'), data: data, onDaily: claimDaily, onAd: watchAdReward);
      case 'league':
        return LeaguePage(key: const ValueKey('league'), data: data);
      case 'profile':
        return ProfilePage(key: const ValueKey('profile'), data: data, onToggle: (field, value) {
          setState(() {
            if (field == 'sound') data.sound = value;
            if (field == 'vibration') data.vibration = value;
            if (field == 'light') data.lightMode = value;
            if (field == 'skip') data.skipTutorial = value;
          });
          _save();
        });
      case 'game':
        return GamePage(key: const ValueKey('game'), game: activeGame ?? games.first, qIndex: currentQ, correct: correct, wrong: wrong, hearts: hearts, lastResult: lastResult, onBack: () => go('home'), onAnswer: answer);
      case 'result':
        return ResultPage(key: const ValueKey('result'), game: activeGame ?? games.first, correct: correct, wrong: wrong, onReplay: () => startGame(activeGame ?? games.first), onHome: () => go('home'), onAd: () {
          watchAdReward();
          startGame(activeGame ?? games.first);
        });
      default:
        return HomePage(key: const ValueKey('home'), data: data, onStart: startGame, onAd: watchAdReward);
    }
  }
}

class OriginalBackground extends StatelessWidget {
  final Widget child;
  const OriginalBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFE4EBF7), Color(0xFFF1F6FF), Color(0xFFE7E1FF)],
          stops: [0, .46, 1],
        ),
      ),
      child: Stack(
        children: [
          Positioned(top: -70, right: -72, child: HtmlBubble(size: 220, color: C.primary.withOpacity(.22))),
          Positioned(top: 58, left: -78, child: HtmlBubble(size: 200, color: C.cyan.withOpacity(.24))),
          Positioned(bottom: -118, left: 82, child: HtmlBubble(size: 250, color: C.orange.withOpacity(.20))),
          CustomPaint(painter: GridPainter(), size: Size.infinite),
          child,
        ],
      ),
    );
  }
}

class HtmlBubble extends StatelessWidget {
  final double size;
  final Color color;
  const HtmlBubble({super.key, required this.size, required this.color});
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color));
}

class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p1 = Paint()..color = C.primary.withOpacity(.045)..strokeWidth = 1;
    final p2 = Paint()..color = C.cyan.withOpacity(.045)..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 34) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p1);
    }
    for (double x = 0; x < size.width; x += 34) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p2);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class TopBar extends StatelessWidget {
  final AppStateData data;
  final VoidCallback onProfile;
  const TopBar({super.key, required this.data, required this.onProfile});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                const HtmlIconBox(icon: 'brain', size: 48, radius: 18),
                const SizedBox(width: 10),
                Flexible(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                    Text('چالشینو', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: C.ink, height: 1.1)),
                    SizedBox(height: 4),
                    Text('نسخه تستی v52', style: TextStyle(fontSize: 11, color: Color(0xFF6D7893))),
                  ]),
                ),
              ],
            ),
          ),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              WalletPill(icon: 'coin', text: data.coins.toString()),
              WalletPill(icon: 'energy', text: data.energy.toString()),
              GestureDetector(onTap: onProfile, child: const HtmlIconBox(icon: 'profile', size: 44, radius: 18)),
            ],
          ),
        ],
      ),
    );
  }
}

class WalletPill extends StatelessWidget {
  final String icon;
  final String text;
  const WalletPill({super.key, required this.icon, required this.text});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: pillDecoration(),
      child: Row(mainAxisSize: MainAxisSize.min, children: [HtmlSvgIcon(icon, size: 18, color: C.primary), const SizedBox(width: 6), Text(text, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12, color: C.ink))]),
    );
  }
}

class HomePage extends StatelessWidget {
  final AppStateData data;
  final ValueChanged<GameDef> onStart;
  final VoidCallback onAd;
  const HomePage({super.key, required this.data, required this.onStart, required this.onAd});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const HomePlainHead(),
      HomeLevelCard(data: data),
      NativeAdCard(onTap: onAd),
      const SectionTitle(title: 'بازی‌ها', hint: 'اسکرول کن'),
      SizedBox(
        height: 220,
        child: ListView.separated(
          reverse: true,
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.only(bottom: 22, top: 6, left: 2, right: 2),
          itemBuilder: (context, i) => GameCard(game: games[i], onTap: () => onStart(games[i]), index: i),
          separatorBuilder: (_, __) => const SizedBox(width: 16),
          itemCount: games.length,
        ),
      ),
      const SectionTitle(title: 'مسیر امروز', hint: 'مأموریت روزانه'),
      MissionCard(data: data),
      const SizedBox(height: 22),
    ]);
  }
}

class HomePlainHead extends StatelessWidget {
  const HomePlainHead({super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 4, 2, 12),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.end, children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(color: const Color(0xFFF0EFFF), borderRadius: BorderRadius.circular(999), border: Border.all(color: C.primary.withOpacity(.16)), boxShadow: [BoxShadow(color: C.primary.withOpacity(.09), blurRadius: 16, offset: const Offset(0, 8))]),
            child: Row(children: const [HtmlSvgIcon('star', size: 16, color: C.primary), SizedBox(width: 6), Text('چالش روزانه', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: C.primary))]),
          ),
          const Text('آماده‌ای؟\nبازی رو شروع کن', textAlign: TextAlign.right, style: TextStyle(fontSize: 22, height: 1.55, fontWeight: FontWeight.w900, color: C.ink)),
        ]),
      );
}

class HomeLevelCard extends StatelessWidget {
  final AppStateData data;
  const HomeLevelCard({super.key, required this.data});
  @override
  Widget build(BuildContext context) {
    final progress = (data.xp / 450).clamp(0, 1).toDouble();
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(14),
      decoration: softCard(colors: const [Colors.white, Color(0xFFF3FBFF), Color(0xFFF6F1FF)], radius: 28),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [Text('لیگ برنزی', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: C.ink)), SizedBox(height: 4), Text('تا لیگ بعدی: 450 XP', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: C.muted))])),
          const HtmlIconBox(icon: 'trophy', size: 58, radius: 22, colors: [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Colors.white),
        ]),
        const SizedBox(height: 12),
        ProgressBar(value: progress, colors: const [C.primary, C.cyan]),
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          MiniChip(text: 'XP ${data.xp}', icon: 'star'),
          Text('${data.xp}/450 ثبت شده', style: const TextStyle(fontSize: 12, color: C.muted, fontWeight: FontWeight.w900)),
        ]),
      ]),
    );
  }
}

class NativeAdCard extends StatelessWidget {
  final VoidCallback onTap;
  const NativeAdCard({super.key, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 18, top: 10),
        padding: const EdgeInsets.all(13),
        decoration: softCard(colors: const [Color(0xFFF0F8FF), Colors.white, Color(0xFFF6F1FF)], radius: 28),
        child: Row(children: const [
          HtmlIconBox(icon: 'ad', size: 52, radius: 18, colors: [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Color(0xFF633C00)),
          SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('جایگاه تبلیغ Adivery', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: C.ink)), SizedBox(height: 4), Text('آماده اتصال به تبلیغ واقعی', style: TextStyle(fontSize: 12, height: 1.8, color: C.muted))])),
          HtmlSvgIcon('home', size: 22, color: C.blueGrey),
        ]),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String hint;
  const SectionTitle({super.key, required this.title, required this.hint});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 16, 2, 10),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(title, style: const TextStyle(fontSize: 18, color: C.ink, fontWeight: FontWeight.w900)), Text(hint, style: const TextStyle(fontSize: 12, color: Color(0xFF6D7893)))]),
      );
}

class GameCard extends StatelessWidget {
  final GameDef game;
  final int index;
  final VoidCallback onTap;
  const GameCard({super.key, required this.game, required this.index, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final colors = index % 3 == 1 ? const [Colors.white, Color(0xFFF3F1FF)] : index % 3 == 2 ? const [Colors.white, Color(0xFFFFF8EB)] : const [Colors.white, Color(0xFFF0FBFF)];
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 244,
        child: Stack(children: [
          Container(
            height: 188,
            padding: const EdgeInsets.all(16),
            decoration: softCard(colors: colors, radius: 30),
            child: Stack(children: [
              Positioned(left: -35, bottom: -45, child: Container(width: 120, height: 120, decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [game.c1.withOpacity(.18), game.c2.withOpacity(.18)])))),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [HtmlIconBox(icon: game.icon, size: 58, radius: 22, colors: [game.c1, game.c2], iconColor: Colors.white), GameTag(text: '⚡ ${game.energy}')]),
                const SizedBox(height: 12),
                Text(game.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: C.ink)),
                const SizedBox(height: 7),
                Text(game.desc, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.2, height: 1.8, color: C.muted)),
                const Spacer(),
                ProgressBar(value: (index + 1) / games.length, colors: [game.c1, game.c2]),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }
}

class MissionCard extends StatelessWidget {
  final AppStateData data;
  const MissionCard({super.key, required this.data});
  @override
  Widget build(BuildContext context) {
    final progress = (data.totalGames / 3).clamp(0, 1).toDouble();
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: softCard(radius: 30),
      child: Row(children: [
        const HtmlIconBox(icon: 'target', size: 52, radius: 20, colors: [Color(0xFF22D3B6), Color(0xFF14C8D8)], iconColor: Colors.white),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('۳ بازی انجام بده', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: C.ink)), const SizedBox(height: 8), ProgressBar(value: progress, colors: const [C.green, C.cyan]), const SizedBox(height: 8), Text('${data.totalGames.clamp(0, 3)}/3 بازی ثبت شده', style: const TextStyle(fontSize: 12, color: C.muted, fontWeight: FontWeight.w900))])),
      ]),
    );
  }
}

class RewardsPage extends StatelessWidget {
  final AppStateData data;
  final VoidCallback onDaily;
  final VoidCallback onAd;
  const RewardsPage({super.key, required this.data, required this.onDaily, required this.onAd});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const MiniHero(title: 'جایزه‌ها', subtitle: 'پاداش روزانه، مأموریت‌ها و تبلیغ جایزه‌دار', icon: 'gift'),
        const SizedBox(height: 16),
        QuestCard(title: 'جایزه روزانه', subtitle: 'هر روز وارد شو و جایزه بگیر', icon: 'gift', c1: C.orange, c2: const Color(0xFFFF9F43), button: 'دریافت', onTap: onDaily),
        const SizedBox(height: 12),
        QuestCard(title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه + ۱۰ انرژی', icon: 'ad', c1: C.primary, c2: C.cyan, button: 'تماشا', onTap: onAd),
        const SectionTitle(title: 'مأموریت‌ها', hint: 'روزانه / هفتگی'),
        QuestCard(title: '۳ بازی انجام بده', subtitle: '${data.totalGames}/3 بازی ثبت شده', icon: 'target', c1: C.green, c2: C.cyan, button: 'برو', onTap: () {}),
        const SizedBox(height: 12),
        QuestCard(title: '۵ جواب درست بزن', subtitle: '${data.totalCorrect}/5 جواب درست', icon: 'check', c1: C.primarySoft, c2: C.primary, button: 'شروع', onTap: () {}),
      ]);
}

class ShopPage extends StatelessWidget {
  final AppStateData data;
  final void Function(String, int, {int coins, int energy, int hints}) onBuy;
  final VoidCallback onAd;
  const ShopPage({super.key, required this.data, required this.onBuy, required this.onAd});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const MiniHero(title: 'فروشگاه', subtitle: 'بسته‌های سکه، انرژی و راهنما', icon: 'shop'),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: ShopStat(value: data.coins.toString(), label: 'سکه')), const SizedBox(width: 9), Expanded(child: ShopStat(value: data.energy.toString(), label: 'انرژی')), const SizedBox(width: 9), Expanded(child: ShopStat(value: data.hints.toString(), label: 'راهنما'))]),
        const SectionTitle(title: 'بسته‌های ویژه', hint: 'اسکرول افقی'),
        SizedBox(height: 174, child: ListView(scrollDirection: Axis.horizontal, reverse: true, children: [
          ProductTile(title: '۱۰۰۰ سکه', subtitle: 'بسته شروع', icon: 'coin', c1: C.orange, c2: const Color(0xFFFF9F43), onTap: () => onBuy('۱۰۰۰ سکه', 0, coins: 1000)),
          ProductTile(title: '۵۰ انرژی', subtitle: 'برای بازی بیشتر', icon: 'energy', c1: C.cyan, c2: C.primary, onTap: () => onBuy('۵۰ انرژی', 0, energy: 50)),
          ProductTile(title: '۵ راهنما', subtitle: 'کمک داخل بازی', icon: 'riddle', c1: C.green, c2: C.cyan, onTap: () => onBuy('۵ راهنما', 0, hints: 5)),
          ProductTile(title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه رایگان', icon: 'ad', c1: C.primary, c2: C.orange, onTap: onAd),
        ])),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFF7FBFF)]), border: Border.all(color: C.primary.withOpacity(.22), style: BorderStyle.solid), borderRadius: BorderRadius.circular(22)), child: const Text('پرداخت واقعی در نسخه مارکتی فعال می‌شود. این بخش فعلاً تستی است.', style: TextStyle(fontSize: 12, height: 1.8, color: C.muted, fontWeight: FontWeight.w800))),
      ]);
}

class LeaguePage extends StatelessWidget {
  final AppStateData data;
  const LeaguePage({super.key, required this.data});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const MiniHero(title: 'لیگ فعلی تو', subtitle: 'فعلاً در لیگ برنزی هستی', icon: 'trophy'),
        const SizedBox(height: 14),
        Container(padding: const EdgeInsets.all(18), decoration: softCard(colors: const [Color(0xFFFFF9E8), Colors.white], radius: 30), child: Column(children: [
          const HtmlIconBox(icon: 'trophy', size: 60, radius: 22, colors: [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Colors.white),
          const SizedBox(height: 10),
          const Text('لیگ برنزی', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: C.ink)),
          const SizedBox(height: 8),
          Text('XP فعلی: ${data.xp} / 450', style: const TextStyle(fontSize: 13, color: C.muted, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          ProgressBar(value: (data.xp / 450).clamp(0, 1).toDouble(), colors: const [C.orange, C.cyan]),
        ])),
        const SectionTitle(title: 'رتبه‌بندی', hint: 'نمونه تستی'),
        RankRow(name: 'تو', score: data.xp, active: true),
        const RankRow(name: 'کاربر ۱', score: 390),
        const RankRow(name: 'کاربر ۲', score: 310),
        const RankRow(name: 'کاربر ۳', score: 280),
      ]);
}

class ProfilePage extends StatelessWidget {
  final AppStateData data;
  final void Function(String, bool) onToggle;
  const ProfilePage({super.key, required this.data, required this.onToggle});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const MiniHero(title: 'پروفایل', subtitle: 'آمار، تنظیمات و دستاوردها', icon: 'profile'),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(18), decoration: softCard(radius: 30), child: Row(children: [
          const HtmlIconBox(icon: 'profile', size: 64, radius: 24),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('بازیکن چالشینو', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: C.ink)), Text('XP ${data.xp} • ${data.coins} سکه', style: const TextStyle(fontSize: 12, color: C.muted, height: 1.8))])),
        ])),
        const SectionTitle(title: 'آمار', hint: 'ذخیره‌شده'),
        Row(children: [Expanded(child: ShopStat(value: data.totalGames.toString(), label: 'بازی')), const SizedBox(width: 10), Expanded(child: ShopStat(value: data.totalCorrect.toString(), label: 'درست')), const SizedBox(width: 10), Expanded(child: ShopStat(value: data.totalWrong.toString(), label: 'غلط'))]),
        const SectionTitle(title: 'دستاوردها', hint: 'مدال‌ها'),
        if (data.achievements.isEmpty) const HtmlNote(text: 'هنوز مدالی نگرفتی. چند بازی انجام بده تا مدال‌ها فعال شوند.') else ...data.achievements.map((e) => Padding(padding: const EdgeInsets.only(bottom: 10), child: QuestCard(title: e, subtitle: 'دستاورد فعال شده', icon: 'star', c1: C.orange, c2: C.primary, button: 'فعال', onTap: () {}))),
        const SectionTitle(title: 'تنظیمات', hint: 'بازی'),
        SettingTile(title: 'صدا', value: data.sound, onChanged: (v) => onToggle('sound', v)),
        SettingTile(title: 'لرزش', value: data.vibration, onChanged: (v) => onToggle('vibration', v)),
        SettingTile(title: 'حالت سبک', value: data.lightMode, onChanged: (v) => onToggle('light', v)),
        SettingTile(title: 'رد کردن آموزش سریع', value: data.skipTutorial, onChanged: (v) => onToggle('skip', v)),
      ]);
}

class GamePage extends StatelessWidget {
  final GameDef game;
  final int qIndex;
  final int correct;
  final int wrong;
  final int hearts;
  final String? lastResult;
  final VoidCallback onBack;
  final ValueChanged<bool> onAnswer;
  const GamePage({super.key, required this.game, required this.qIndex, required this.correct, required this.wrong, required this.hearts, required this.lastResult, required this.onBack, required this.onAnswer});
  @override
  Widget build(BuildContext context) {
    final q = game.questions[qIndex % game.questions.length];
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(children: [
        GestureDetector(onTap: onBack, child: Container(width: 42, height: 42, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFEFFBFF)]), border: Border.all(color: C.cyan.withOpacity(.16)), borderRadius: BorderRadius.circular(16), boxShadow: htmlShadow(opacity: .12, blur: 24, offset: const Offset(0, 12))), child: const Center(child: Text('‹', style: TextStyle(fontSize: 30, color: C.ink))))),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(game.title, style: const TextStyle(fontSize: 18, color: C.ink, fontWeight: FontWeight.w900)), Text('قلب‌ها: $hearts • درست: $correct • غلط: $wrong', style: const TextStyle(fontSize: 12, color: C.muted))])),
        HtmlIconBox(icon: game.icon, size: 48, radius: 18, colors: [game.c1, game.c2], iconColor: Colors.white),
      ]),
      const SizedBox(height: 14),
      Container(padding: const EdgeInsets.all(16), decoration: softCard(colors: const [Color(0xFFEEF8FF), Color(0xFFF7F3FF), Color(0xFFFFF8ED)], radius: 26, borderColor: C.primary.withOpacity(.18)), child: Text(q.text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 19, height: 1.9, fontWeight: FontWeight.w900, color: C.ink))),
      const SizedBox(height: 14),
      ...q.options.map((o) => Padding(padding: const EdgeInsets.only(bottom: 10), child: ChoiceButton(text: o, onTap: () => onAnswer(o == q.answer)))),
      if (lastResult != null) HtmlNote(text: lastResult!),
    ]);
  }
}

class ResultPage extends StatelessWidget {
  final GameDef game;
  final int correct;
  final int wrong;
  final VoidCallback onReplay;
  final VoidCallback onHome;
  final VoidCallback onAd;
  const ResultPage({super.key, required this.game, required this.correct, required this.wrong, required this.onReplay, required this.onHome, required this.onAd});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        MiniHero(title: 'نتیجه بازی', subtitle: game.title, icon: 'trophy'),
        const SizedBox(height: 14),
        Container(padding: const EdgeInsets.all(18), decoration: softCard(radius: 30), child: Column(children: [
          const HtmlIconBox(icon: 'target', size: 64, radius: 24, colors: [C.green, C.cyan], iconColor: Colors.white),
          const SizedBox(height: 12),
          Text('درست: $correct    غلط: $wrong', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: C.ink)),
          const SizedBox(height: 8),
          Text('سکه و XP بر اساس عملکردت ثبت شد.', style: const TextStyle(fontSize: 12, color: C.muted, fontWeight: FontWeight.w800)),
        ])),
        const SizedBox(height: 14),
        Row(children: [Expanded(child: GradientAction(text: 'دوباره بازی کن', onTap: onReplay)), const SizedBox(width: 10), Expanded(child: GradientAction(text: 'خانه', onTap: onHome, secondary: true))]),
        const SizedBox(height: 10),
        GradientAction(text: 'ادامه با تبلیغ', onTap: onAd, colors: const [C.orange, C.cyan]),
      ]);
}

class MiniHero extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  const MiniHero({super.key, required this.title, required this.subtitle, required this.icon});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(18),
        decoration: softCard(colors: const [Colors.white, Color(0xFFF4FBFF)], radius: 30),
        child: Row(children: [HtmlIconBox(icon: icon, size: 56, radius: 20), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: C.ink)), const SizedBox(height: 7), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.8, color: C.muted))]))]),
      );
}

class QuestCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color c1;
  final Color c2;
  final String button;
  final VoidCallback onTap;
  const QuestCard({super.key, required this.title, required this.subtitle, required this.icon, required this.c1, required this.c2, required this.button, required this.onTap});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(18),
        decoration: softCard(radius: 30),
        child: Row(children: [HtmlIconBox(icon: icon, size: 52, radius: 20, colors: [c1, c2], iconColor: Colors.white), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15, color: C.ink, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.8, color: C.muted))])), const SizedBox(width: 8), GradientAction(text: button, onTap: onTap, compact: true, colors: [c1, c2])]),
      );
}

class ShopStat extends StatelessWidget {
  final String value;
  final String label;
  const ShopStat({super.key, required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFEEFAFF)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(20), border: Border.all(color: C.cyan.withOpacity(.14)), boxShadow: htmlShadow(opacity: .1, blur: 17, offset: const Offset(0, 9))),
        child: Column(children: [Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: C.ink)), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 10.5, color: C.muted, fontWeight: FontWeight.w900))]),
      );
}

class ProductTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color c1;
  final Color c2;
  final VoidCallback onTap;
  const ProductTile({super.key, required this.title, required this.subtitle, required this.icon, required this.c1, required this.c2, required this.onTap});
  @override
  Widget build(BuildContext context) => Container(
        width: 228,
        margin: const EdgeInsets.only(left: 12, top: 4, bottom: 14),
        padding: const EdgeInsets.all(13),
        decoration: softCard(radius: 24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [HtmlIconBox(icon: icon, size: 48, radius: 17, colors: [c1, c2], iconColor: Colors.white), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15, color: C.ink, fontWeight: FontWeight.w900)), Text(subtitle, style: const TextStyle(fontSize: 12, color: C.muted))]))]), const Spacer(), GradientAction(text: 'فعال‌سازی', onTap: onTap, compact: true, colors: [c1, c2])]),
      );
}

class RankRow extends StatelessWidget {
  final String name;
  final int score;
  final bool active;
  const RankRow({super.key, required this.name, required this.score, this.active = false});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: softCard(colors: active ? const [Color(0xFFF0EFFF), Colors.white] : null, radius: 22),
        child: Row(children: [const HtmlIconBox(icon: 'profile', size: 42, radius: 16), const SizedBox(width: 10), Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink))), Text('$score XP', style: const TextStyle(fontWeight: FontWeight.w900, color: C.muted))]),
      );
}

class SettingTile extends StatelessWidget {
  final String title;
  final bool value;
  final ValueChanged<bool> onChanged;
  const SettingTile({super.key, required this.title, required this.value, required this.onChanged});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: softCard(radius: 22),
        child: Row(children: [Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: C.ink))), Switch(value: value, onChanged: onChanged, activeColor: C.primary)]),
      );
}

class ChoiceButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const ChoiceButton({super.key, required this.text, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFF1F8FF)], begin: Alignment.topLeft, end: Alignment.bottomRight), border: Border.all(color: C.cyan.withOpacity(.14)), borderRadius: BorderRadius.circular(20), boxShadow: htmlShadow(opacity: .09, blur: 16, offset: const Offset(0, 8))),
          child: Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: C.ink)),
        ),
      );
}

class HtmlNote extends StatelessWidget {
  final String text;
  const HtmlNote({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(12), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFF7FBFF)]), borderRadius: BorderRadius.circular(22), border: Border.all(color: C.primary.withOpacity(.22))), child: Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, height: 1.8, color: C.muted, fontWeight: FontWeight.w900)));
}

class GradientAction extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  final bool compact;
  final bool secondary;
  final List<Color>? colors;
  const GradientAction({super.key, required this.text, required this.onTap, this.compact = false, this.secondary = false, this.colors});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: compact ? const EdgeInsets.symmetric(horizontal: 12, vertical: 10) : const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
          decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: secondary ? const [Colors.white, Color(0xFFEFFBFF)] : (colors ?? const [Color(0xFF7F78FF), C.primary])), border: Border.all(color: secondary ? C.cyan.withOpacity(.16) : Colors.white.withOpacity(.45)), borderRadius: BorderRadius.circular(compact ? 17 : 19), boxShadow: htmlShadow(opacity: .15, blur: 24, offset: const Offset(0, 14))),
          child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: compact ? 12 : 13, fontWeight: FontWeight.w900, color: secondary ? C.ink : Colors.white)),
        ),
      );
}

class ProgressBar extends StatelessWidget {
  final double value;
  final List<Color> colors;
  const ProgressBar({super.key, required this.value, required this.colors});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(999),
        child: Container(height: 9, color: const Color(0xFFE8F2FB), alignment: Alignment.centerRight, child: FractionallySizedBox(widthFactor: value.clamp(0, 1), alignment: Alignment.centerRight, child: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: colors))))),
      );
}

class MiniChip extends StatelessWidget {
  final String text;
  final String icon;
  const MiniChip({super.key, required this.text, required this.icon});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: pillDecoration(), child: Row(mainAxisSize: MainAxisSize.min, children: [HtmlSvgIcon(icon, size: 15, color: C.primary), const SizedBox(width: 6), Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: C.ink))]));
}

class GameTag extends StatelessWidget {
  final String text;
  const GameTag({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: pillDecoration(), child: Text(text, style: const TextStyle(fontSize: 11, color: C.ink, fontWeight: FontWeight.w900)));
}

class HtmlIconBox extends StatelessWidget {
  final String icon;
  final double size;
  final double radius;
  final List<Color>? colors;
  final Color iconColor;
  const HtmlIconBox({super.key, required this.icon, this.size = 48, this.radius = 18, this.colors, this.iconColor = const Color(0xFF4D48A8)});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors ?? const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)]),
          color: Colors.white,
          border: Border.all(color: C.primary.withOpacity(.16)),
          borderRadius: BorderRadius.circular(radius),
          boxShadow: [BoxShadow(color: const Color(0xFF4C56AA).withOpacity(.14), blurRadius: 24, offset: const Offset(0, 14))],
        ),
        child: Center(child: HtmlSvgIcon(icon, size: size * .52, color: iconColor)),
      );
}

class HtmlSvgIcon extends StatelessWidget {
  final String name;
  final double size;
  final Color color;
  const HtmlSvgIcon(this.name, {super.key, this.size = 24, this.color = C.ink});
  @override
  Widget build(BuildContext context) {
    final path = iconPaths[name] ?? iconPaths['brain']!;
    return SvgPicture.string('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">$path</svg>', width: size, height: size, colorFilter: ColorFilter.mode(color, BlendMode.srcIn));
  }
}

class NavBar extends StatelessWidget {
  final String active;
  final ValueChanged<String> onTap;
  const NavBar({super.key, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final items = [
      ('rewards', 'جایزه‌ها', 'gift'),
      ('league', 'لیگ', 'trophy'),
      ('home', 'خانه', 'home'),
      ('shop', 'فروشگاه', 'shop'),
      ('profile', 'پروفایل', 'profile'),
    ];
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 13),
      decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [C.bg.withOpacity(0), const Color(0xFFEFF6FF).withOpacity(.95), Colors.white], stops: const [0, .28, 1]), boxShadow: [BoxShadow(color: const Color(0xFF4C56AA).withOpacity(.10), blurRadius: 26, offset: const Offset(0, -12))]),
      child: Row(children: [for (final it in items) Expanded(child: NavItem(keyName: it.$1, title: it.$2, icon: it.$3, active: active == it.$1 || (active == 'game' && it.$1 == 'home') || (active == 'result' && it.$1 == 'home'), home: it.$1 == 'home', onTap: () => onTap(it.$1)))]),
    );
  }
}

class NavItem extends StatelessWidget {
  final String keyName;
  final String title;
  final String icon;
  final bool active;
  final bool home;
  final VoidCallback onTap;
  const NavItem({super.key, required this.keyName, required this.title, required this.icon, required this.active, required this.home, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final isHome = home;
    final gradient = isHome
        ? const [Color(0xFF20D9C2), C.primary, C.orange]
        : active
            ? const [Color(0xFF7F78FF), C.primary]
            : const [Colors.white, Color(0xFFEFFBFF)];
    return GestureDetector(
      onTap: onTap,
      child: Transform.translate(
        offset: Offset(0, isHome ? (active ? -11 : -8) : (active ? -3 : 0)),
        child: Center(
          child: Container(
            width: isHome ? 68 : double.infinity,
            height: isHome ? 70 : 56,
            margin: EdgeInsets.symmetric(horizontal: isHome ? 2 : 3),
            padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
              border: Border.all(color: isHome ? Colors.white.withOpacity(.64) : C.cyan.withOpacity(.13)),
              borderRadius: BorderRadius.circular(isHome ? 28 : 18),
              boxShadow: isHome ? [BoxShadow(color: const Color(0xFF4C56AA).withOpacity(.31), blurRadius: 40, offset: const Offset(0, 24)), BoxShadow(color: C.primary.withOpacity(.08), spreadRadius: 7, blurRadius: 0)] : [BoxShadow(color: const Color(0xFF4C56AA).withOpacity(.10), blurRadius: 16, offset: const Offset(0, 9))],
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [HtmlSvgIcon(icon, size: isHome ? 29 : 23, color: active || isHome ? Colors.white : C.blueGrey), const SizedBox(height: 3), Text(title, style: TextStyle(fontSize: isHome ? 11 : 10, fontWeight: FontWeight.w900, color: active || isHome ? Colors.white : C.blueGrey))]),
          ),
        ),
      ),
    );
  }
}

class GameDef {
  final String title;
  final String desc;
  final String icon;
  final Color c1;
  final Color c2;
  final int energy;
  final int coinReward;
  final List<Question> questions;
  const GameDef(this.title, this.desc, this.icon, this.c1, this.c2, this.energy, this.coinReward, this.questions);
}

class Question {
  final String text;
  final List<String> options;
  final String answer;
  const Question(this.text, this.options, this.answer);
}

const games = <GameDef>[
  GameDef('چیستان', 'به معماها سریع جواب بده و سکه بگیر.', 'riddle', C.cyan, Color(0xFF22D3B6), 3, 12, [Question('آن چیست که هرچه از آن برداری بزرگ‌تر می‌شود؟', ['چاله', 'کوه', 'آب', 'نور'], 'چاله'), Question('کدام چیز بی‌زبان حرف می‌زند؟', ['کتاب', 'سنگ', 'در', 'آتش'], 'کتاب')]),
  GameDef('حدس کلمه', 'با حروف داده‌شده جواب را بساز.', 'word', C.primary, C.primarySoft, 3, 14, [Question('کلمه مرتبط با یادگیری را انتخاب کن.', ['کتاب', 'نمک', 'باران', 'مار'], 'کتاب'), Question('کلمه مرتبط با سرعت را انتخاب کن.', ['ساعت', 'سنگ', 'پنجره', 'دیوار'], 'ساعت')]),
  GameDef('غلط‌یاب', 'گزینه نادرست را پیدا کن.', 'typo', Color(0xFFFB7185), C.orange, 4, 16, [Question('کدام گزینه غلط املایی دارد؟', ['کتاب', 'مدرسه', 'غلط', 'خاهان'], 'خاهان'), Question('کدام کلمه درست نیست؟', ['خانه', 'باران', 'آفتاب', 'صداا'], 'صداا')]),
  GameDef('معمای منطقی', 'با منطق جواب درست را انتخاب کن.', 'logic', C.green, C.cyan, 4, 18, [Question('اگر همه الف‌ها ب هستند و همه ب‌ها ج، الف چیست؟', ['ج', 'الف', 'هیچکدام', 'ب فقط'], 'ج'), Question('عدد بعدی ۲،۴،۸،۱۶ چیست؟', ['۳۲', '۲۰', '۲۴', '۳۰'], '۳۲')]),
  GameDef('درست یا غلط', 'درستی جمله‌ها را سریع تشخیص بده.', 'truefalse', C.primary, C.green, 2, 10, [Question('خورشید از شرق طلوع می‌کند.', ['درست', 'غلط'], 'درست'), Question('یخ گرم‌تر از آب جوش است.', ['درست', 'غلط'], 'غلط')]),
  GameDef('حافظه سریع', 'جای کارت‌ها را به خاطر بسپار.', 'brain', C.orange, C.primary, 5, 22, [Question('کدام گزینه نماد هدف بود؟', ['هدف', 'خانه', 'سکه', 'فروشگاه'], 'هدف'), Question('کدام گزینه نماد جایزه بود؟', ['هدیه', 'لیگ', 'پروفایل', 'انرژی'], 'هدیه')]),
];

const Map<String, String> iconPaths = {
  'brain': '<path d="M9 6.4c-2.1.2-3.6 1.8-3.6 3.8 0 1 .4 1.9 1 2.5-.8.6-1.3 1.5-1.3 2.6 0 1.8 1.5 3.3 3.3 3.3h1.1V6.4Z"/><path d="M15 6.4c2.1.2 3.6 1.8 3.6 3.8 0 1-.4 1.9-1 2.5.8.6 1.3 1.5 1.3 2.6 0 1.8-1.5 3.3-3.3 3.3h-1.1V6.4Z"/><path d="M9.5 9.5H7.8M14.5 9.5h1.7M9.5 13H7.6M14.5 13h1.9M9.5 16.4H8.2M14.5 16.4h1.3"/>',
  'coin': '<circle cx="12" cy="12" r="8"/><path d="M9 10.2c.7-1 2-1.5 3.3-1.2 1.5.3 2.7 1.5 2.7 3s-1.2 2.7-2.7 3c-1.3.3-2.6-.2-3.3-1.2"/><path d="M8.5 12h6"/>',
  'energy': '<path d="M13 2.8 5.5 13h5.2L9.8 21.2 18.5 10h-5.3L13 2.8Z"/>',
  'profile': '<circle cx="12" cy="8" r="3.6"/><path d="M4.8 20c1.2-4.2 13.2-4.2 14.4 0"/>',
  'home': '<path d="M3.5 11.2 12 4l8.5 7.2"/><path d="M6.2 10.5v9h11.6v-9"/><path d="M10 19.5v-5h4v5"/>',
  'gift': '<path d="M4.5 9h15v11h-15z"/><path d="M3.5 9h17V6.2h-17z"/><path d="M12 6.2V20"/><path d="M12 6.2C10.8 3 7.3 3.2 7.3 5.4c0 1.5 2.2 1.8 4.7.8ZM12 6.2c1.2-3.2 4.7-3 4.7-.8 0 1.5-2.2 1.8-4.7.8Z"/>',
  'trophy': '<path d="M8 4h8v4.8c0 2.2-1.8 4-4 4s-4-1.8-4-4V4Z"/><path d="M8 6H5.2c0 3.8 2 5.4 4.3 5.6M16 6h2.8c0 3.8-2 5.4-4.3 5.6M12 12.8v3.8M8.8 20h6.4M10 16.6h4"/>',
  'shop': '<path d="M5.2 9.5h13.6l-1 10H6.2l-1-10Z"/><path d="M8.5 9.5V8a3.5 3.5 0 0 1 7 0v1.5"/><path d="M4 9.5h16"/>',
  'riddle': '<path d="M9 18h6M9.5 21h5"/><path d="M8.2 14.5c-1.3-1.1-2-2.7-2-4.4a5.8 5.8 0 0 1 11.6 0c0 1.7-.7 3.3-2 4.4-.8.7-1.1 1.4-1.2 2H9.4c-.1-.6-.4-1.3-1.2-2Z"/><path d="M10.8 10.3c.2-1.8 2.8-1.7 2.8.1 0 1.3-1.6 1.4-1.6 2.6M12 15h.1"/>',
  'word': '<path d="M5 18 9.3 6h1.4L15 18M6.5 14h7"/><path d="M17 8h2.5M17 12h2.5M17 16h2.5"/>',
  'typo': '<path d="m5 18 1-4.2L16.8 3l3.2 3.2L9.2 17 5 18Z"/><path d="M14.8 5 18 8.2M4 21h16"/>',
  'logic': '<path d="M8 4h4v4H8zM12 8h4v4h-4zM8 12h4v4H8zM12 16h4v4h-4z"/><path d="M12 6h2M10 8v2M12 14h2M14 12v2"/>',
  'truefalse': '<path d="M4.5 12.5 8.7 16.7 18.8 6.6"/><path d="M5.5 5.5 18.5 18.5"/><path d="M18.5 5.5 5.5 18.5"/>',
  'ad': '<rect x="4" y="6" width="16" height="12" rx="3"/><path d="m10 10 5 2.5-5 2.5Z"/>',
  'target': '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>',
  'star': '<path d="m12 3 2.4 5 5.5.8-4 3.9.9 5.5-4.8-2.6-4.8 2.6.9-5.5-4-3.9 5.5-.8L12 3Z"/>',
  'check': '<path d="m5 12 4 4 10-10"/>',
};
