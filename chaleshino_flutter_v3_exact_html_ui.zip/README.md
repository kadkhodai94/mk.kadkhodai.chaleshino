# چالشینو Flutter v3 - Exact HTML UI

این نسخه از روی نسخه HTML v52 بازسازی شده و هدف آن نزدیک‌تر شدن UI Flutter به UI اختصاصی HTML است.

ویژگی‌ها:
- Flutter Native، بدون WebView
- بازسازی صفحه اصلی بر اساس ساختار HTML v52
- Topbar، Wallet، تبلیغات افقی، کارت‌های بازی، مسیر پیشرفت و منوی پایین نزدیک‌تر به نسخه HTML
- حفظ منطق بازی‌ها، ذخیره‌سازی آفلاین و Mock Adivery
- آماده Build با GitHub Actions

نکته: Adivery SDK واقعی هنوز وصل نشده و جایگاه‌ها به صورت Mock حفظ شده‌اند تا Build خراب نشود.
