import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ChaleshinoApp());
}

class AppColor {
  static const bg = Color(0xFFE8EEF9);
  static const paper = Color(0xFFFFFEFA);
  static const ink = Color(0xFF18243B);
  static const muted = Color(0xFF66758F);
  static const primary = Color(0xFF6C63FF);
  static const violet = Color(0xFF8F6CFF);
  static const cyan = Color(0xFF14C8D8);
  static const green = Color(0xFF18BF8F);
  static const orange = Color(0xFFFFB84D);
  static const danger = Color(0xFFFF5C7A);
}

List<BoxShadow> htmlShadow({double opacity = .18, double blur = 34, Offset offset = const Offset(0, 18)}) => [
      BoxShadow(color: const Color(0xFF374696).withOpacity(opacity), blurRadius: blur, offset: offset),
      BoxShadow(color: Colors.white.withOpacity(.78), blurRadius: 0, offset: const Offset(0, 1)),
    ];

BoxDecoration htmlCard({
  List<Color> colors = const [Colors.white, Color(0xFFF4FBFF)],
  double radius = 30,
  Color? border,
  double shadowOpacity = .18,
}) {
  return BoxDecoration(
    gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors),
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: border ?? AppColor.cyan.withOpacity(.13)),
    boxShadow: htmlShadow(opacity: shadowOpacity),
  );
}

class ChaleshinoApp extends StatelessWidget {
  const ChaleshinoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'چالشینو',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Tahoma',
        scaffoldBackgroundColor: AppColor.bg,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColor.primary),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: ChaleshinoRoot()),
    );
  }
}


class GameLevel {
  final String q;
  final List<String> options;
  final int answer;
  final String hint;
  final String difficulty;
  final String? word;
  final List<String> letters;
  final List<String> items;

  const GameLevel({
    required this.q,
    this.options = const [],
    this.answer = 0,
    this.hint = 'با دقت گزینه‌ها را مقایسه کن.',
    this.difficulty = 'easy',
    this.word,
    this.letters = const [],
    this.items = const [],
  });
}

class GameDef {
  final String id;
  final String title;
  final String description;
  final String icon;
  final int energy;
  final Color c1;
  final Color c2;
  final String mode;
  final List<GameLevel> levels;

  const GameDef(this.id, this.title, this.description, this.icon, this.energy, this.c1, this.c2, this.mode, this.levels);
}

const games = <GameDef>[
  GameDef('riddle', 'چیستان', 'چیستان‌های زمان‌دار با جواب گزینه‌ای.', 'riddle', 1, const Color(0xFFFFCF6D), const Color(0xFFFF9F43), 'choice', [
    GameLevel(q: 'آن چیست که هرچه از آن برداری، بزرگ‌تر می‌شود؟', options: ['کتاب', 'سایه', 'چاله', 'شمع'], answer: 2, hint: 'از زمین برداشتن آن را عمیق‌تر می‌کند.', difficulty: 'easy'),
    GameLevel(q: 'بی‌زبان است اما با همه حرف می‌زند.', options: ['کتاب', 'ساعت', 'سنگ', 'باد'], answer: 0, hint: 'صفحه دارد و پیام می‌دهد.', difficulty: 'easy'),
    GameLevel(q: 'همیشه جلو توست اما دیده نمی‌شود.', options: ['سایه', 'آینه', 'آینده', 'گذشته'], answer: 2, hint: 'هنوز به آن نرسیده‌ای.', difficulty: 'easy'),
    GameLevel(q: 'پر از سوراخ است ولی آب را نگه می‌دارد.', options: ['شیشه', 'سبد', 'اسفنج', 'کاغذ'], answer: 2, hint: 'برای شستن استفاده می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'پا ندارد ولی راه می‌رود.', options: ['رود', 'ساعت', 'کفش', 'مداد'], answer: 1, hint: 'زمان را جلو می‌برد.', difficulty: 'easy'),
    GameLevel(q: 'هرچه بیشتر خشک کند، خودش خیس‌تر می‌شود.', options: ['باد', 'حوله', 'آتش', 'آفتاب'], answer: 1, hint: 'بعد از شستن کاربرد دارد.', difficulty: 'easy'),
    GameLevel(q: 'مال توست اما دیگران بیشتر استفاده می‌کنند.', options: ['اسم', 'کیف', 'خانه', 'دفتر'], answer: 0, hint: 'مردم با آن صدایت می‌زنند.', difficulty: 'easy'),
    GameLevel(q: 'گردن دارد ولی سر ندارد.', options: ['درخت', 'پنجره', 'بطری', 'قاشق'], answer: 2, hint: 'برای نوشیدنی است.', difficulty: 'easy'),
    GameLevel(q: 'هرچه بیشتر باشد، کمتر می‌بینی.', options: ['تاریکی', 'نور', 'باران', 'دود'], answer: 0, hint: 'نبودن نور است.', difficulty: 'easy'),
    GameLevel(q: 'صبح چهار پا، ظهر دو پا و شب سه پا دارد.', options: ['انسان', 'میز', 'سایه', 'حیوان'], answer: 0, hint: 'مراحل عمر را می‌گوید.', difficulty: 'easy'),
    GameLevel(q: 'کلید دارد ولی قفل باز نمی‌کند.', options: ['کیف', 'پیانو', 'در', 'ماشین'], answer: 1, hint: 'با انگشت نواخته می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'هرچه جلوتر می‌رود کوتاه‌تر می‌شود.', options: ['شمع', 'درخت', 'نخ', 'راه'], answer: 0, hint: 'با سوختن کم می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'بی‌جان است اما اگر بیفتد می‌شکند و اگر گرم شود نرم می‌شود.', options: ['کاغذ', 'چوب', 'سنگ', 'یخ'], answer: 3, hint: 'از آب ساخته می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'خانه دارد اما در آن زندگی نمی‌کند.', options: ['حلزون', 'پرنده', 'کتاب', 'ماهی'], answer: 0, hint: 'خانه‌اش همراه اوست.', difficulty: 'medium'),
    GameLevel(q: 'دوست دارد همه را ببیند اما خودش را نه.', options: ['پنجره', 'دوربین', 'چشم', 'آینه'], answer: 3, hint: 'تصویر را نشان می‌دهد.', difficulty: 'medium'),
    GameLevel(q: 'همه آن را دارند اما هیچ‌کس نمی‌تواند نگهش دارد.', options: ['سکه', 'زمان', 'خانه', 'قلم'], answer: 1, hint: 'همیشه می‌گذرد.', difficulty: 'medium'),
    GameLevel(q: 'بدون بال پرواز می‌کند.', options: ['ماهی', 'سنگ', 'درخت', 'باد'], answer: 3, hint: 'دیده نمی‌شود اما حس می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'وقتی اسمش را می‌بری، می‌شکند.', options: ['شیشه', 'سکوت', 'قول', 'یخ'], answer: 1, hint: 'با حرف‌زدن از بین می‌رود.', difficulty: 'medium'),
    GameLevel(q: 'با شکستن بهتر کار می‌کند.', options: ['مداد', 'سنگ', 'تخم مرغ', 'لیوان'], answer: 2, hint: 'برای پخت‌وپز باز می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'هرچه بیشتر بخورد بزرگ‌تر می‌شود، ولی آب نابودش می‌کند.', options: ['ابر', 'آتش', 'گیاه', 'ماهی'], answer: 1, hint: 'با سوخت زیاد می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'در روز می‌آید و شب می‌رود، اما پا ندارد.', options: ['سایه', 'ستاره', 'ابر', 'ماه'], answer: 0, hint: 'با نور ساخته می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'لباس ندارد اما همیشه پوشیده است.', options: ['پیاز', 'دفتر', 'کفش', 'سیب'], answer: 0, hint: 'لایه‌های زیادی دارد.', difficulty: 'medium'),
    GameLevel(q: 'بالا می‌رود اما پایین نمی‌آید.', options: ['سن', 'توپ', 'قیمت', 'باد'], answer: 0, hint: 'هر سال بیشتر می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'دست دارد اما نمی‌تواند بگیرد.', options: ['صندلی', 'ساعت', 'عروسک', 'درخت'], answer: 1, hint: 'عقربه دارد.', difficulty: 'medium'),
    GameLevel(q: 'چشم دارد اما نمی‌بیند.', options: ['چراغ', 'پنجره', 'آینه', 'سوزن'], answer: 3, hint: 'برای دوختن استفاده می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'تاج دارد اما پادشاه نیست.', options: ['درخت', 'خروس', 'کوه', 'کتاب'], answer: 1, hint: 'صبح‌ها صدایش شنیده می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'راه دارد ولی پا ندارد.', options: ['ساعت', 'رود', 'نقشه', 'قطار'], answer: 2, hint: 'مسیر را نشان می‌دهد.', difficulty: 'hard'),
    GameLevel(q: 'همه جا می‌رود اما از جایش تکان نمی‌خورد.', options: ['جاده', 'باد', 'ابر', 'سایه'], answer: 0, hint: 'مسیر حرکت دیگران است.', difficulty: 'hard'),
    GameLevel(q: 'هرچه بیشتر پر شود سبک‌تر به نظر می‌آید.', options: ['جعبه', 'بادکنک', 'لیوان', 'کیسه'], answer: 1, hint: 'با هوا پر می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'بی‌صدا می‌آید اما همه چیز را خیس می‌کند.', options: ['باران', 'آفتاب', 'باد', 'برف'], answer: 0, hint: 'از آسمان می‌بارد.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی هرچه بیشتر داشته باشی، کمتر می‌ترسی؟', options: ['خواب', 'دانش', 'سکه', 'کفش'], answer: 1, hint: 'آگاهی اعتماد می‌دهد.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی روی آب می‌ماند اما شنا بلد نیست؟', options: ['ماهی', 'سنگ', 'دفتر', 'قایق'], answer: 3, hint: 'برای عبور از آب است.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی همیشه جواب می‌دهد اما سؤال نمی‌پرسد؟', options: ['کتاب', 'قلم', 'زنگ', 'ساعت'], answer: 2, hint: 'با فشار صدا می‌دهد.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی اگر آن را نگه داری، ممکن است از دست برود؟', options: ['کاغذ', 'سکه', 'چراغ', 'قول'], answer: 3, hint: 'باید به آن عمل کرد.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی با خواندن زیاد تمام نمی‌شود؟', options: ['دانش', 'کتاب', 'مداد', 'دفتر'], answer: 0, hint: 'هرچه یاد بگیری بیشتر می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی بدون دهان خبر می‌دهد؟', options: ['رادیو', 'چراغ', 'کاغذ', 'پرنده'], answer: 1, hint: 'با روشن و خاموش شدن پیام می‌دهد.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی هم در خانه است هم در مدرسه و حرف می‌زند؟', options: ['کتاب', 'صندلی', 'مداد', 'پنجره'], answer: 0, hint: 'دانش را منتقل می‌کند.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی اگر عقب بمانی، از تو جلو می‌زند؟', options: ['زمان', 'باد', 'دوست', 'سایه'], answer: 0, hint: 'منتظر نمی‌ماند.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی همیشه روی زمین است اما سقف را می‌بیند؟', options: ['دیوار', 'در', 'پنجره', 'فرش'], answer: 3, hint: 'در اتاق پهن می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی با فکر کردن روشن‌تر می‌شود؟', options: ['ذهن', 'چراغ', 'آتش', 'ماه'], answer: 0, hint: 'برای حل معما لازم است.', difficulty: 'hard'),
    GameLevel(q: 'چه چیزی زیاد شود، سکوت کمتر می‌شود؟', options: ['سایه', 'نور', 'خواب', 'صدا'], answer: 3, hint: 'با شنیدن مرتبط است.', difficulty: 'expert'),
    GameLevel(q: 'چه چیزی اگر تندتر برود، دیرتر می‌فهمی؟', options: ['آرامش', 'تمرکز', 'دقت', 'عجله'], answer: 3, hint: 'باعث اشتباه می‌شود.', difficulty: 'expert'),
    GameLevel(q: 'چه چیزی در بازی کم شود، خطر باخت بیشتر می‌شود؟', options: ['قلب', 'سکه', 'لیگ', 'راهنما'], answer: 0, hint: 'جان مرحله است.', difficulty: 'expert'),
    GameLevel(q: 'چه چیزی در بازی خرج می‌شود اما دوباره پر می‌شود؟', options: ['زمان', 'اسم', 'رتبه', 'انرژی'], answer: 3, hint: 'برای شروع مرحله لازم است.', difficulty: 'expert'),
    GameLevel(q: 'چه چیزی تو را در جدول بالا می‌برد؟', options: ['اشتباه', 'امتیاز', 'قفل', 'زمان'], answer: 1, hint: 'برای لیگ مهم است.', difficulty: 'expert'),
    GameLevel(q: 'چه چیزی اگر درست جواب دهی بیشتر می‌شود؟', options: ['XP', 'قلب', 'غلط', 'جریمه'], answer: 0, hint: 'امتیاز تجربه است.', difficulty: 'expert'),
    GameLevel(q: 'چه چیزی کمکت می‌کند جواب را پیدا کنی اما خرج دارد؟', options: ['آیکن', 'قلب', 'باکس', 'راهنما'], answer: 3, hint: 'در مرحله فعال می‌شود.', difficulty: 'expert'),
    GameLevel(q: 'چه چیزی با هر برد به تو نزدیک‌تر می‌شود؟', options: ['ریست', 'باخت', 'لیگ بعدی', 'خروج'], answer: 2, hint: 'هدف پیشرفت است.', difficulty: 'expert'),
    GameLevel(q: 'چه چیزی در پایان بازی عملکردت را نشان می‌دهد؟', options: ['خانه', 'فروشگاه', 'نتیجه', 'تنظیمات'], answer: 2, hint: 'بعد از بازی نمایش داده می‌شود.', difficulty: 'expert'),
    GameLevel(q: 'چه چیزی اگر تکراری نباشد بازی عادلانه‌تر می‌شود؟', options: ['سکه', 'آیکن', 'سؤال', 'رنگ'], answer: 2, hint: 'بانک سؤال باید متنوع باشد.', difficulty: 'expert'),
  ]),
  GameDef('word', 'حدس کلمه', 'کلمه را از حروف به‌هم‌ریخته بساز.', 'word', 1, const Color(0xFF14C8D8), const Color(0xFF6C63FF), 'word', [
    GameLevel(q: 'این حروف را مرتب کن:', word: 'باران', letters: ['ن', 'ب', 'ا', 'ا', 'ر'], hint: 'از آسمان می‌بارد', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'شیشه', letters: ['ش', 'ش', 'ی', 'ه'], hint: 'شفاف است', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'کتاب', letters: ['ت', 'ا', 'ب', 'ک'], hint: 'برای خواندن', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'معلم', letters: ['م', 'ل', 'م', 'ع'], hint: 'در مدرسه', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'انسان', letters: ['ن', 'ا', 'ا', 'ن', 'س'], hint: 'ما هستیم', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'ایران', letters: ['ا', 'ن', 'ر', 'ی', 'ا'], hint: 'نام کشور', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'درخت', letters: ['خ', 'ر', 'د', 'ت'], hint: 'ریشه و شاخه دارد', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'بازی', letters: ['ز', 'ا', 'ی', 'ب'], hint: 'سرگرمی', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'دانه', letters: ['ن', 'ه', 'ا', 'د'], hint: 'از آن گیاه رشد می‌کند', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'خانه', letters: ['ن', 'ا', 'خ', 'ه'], hint: 'محل زندگی', difficulty: 'easy'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'چالش', letters: ['ل', 'ا', 'چ', 'ش'], hint: 'کار سخت و جذاب', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'سکه', letters: ['ه', 'س', 'ک'], hint: 'جایزه بازی', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'انرژی', letters: ['ی', 'ژ', 'ر', 'ن', 'ا'], hint: 'برای ادامه بازی', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'مرحله', letters: ['ل', 'ه', 'م', 'ح', 'ر'], hint: 'بخش بازی', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'پنجره', letters: ['ه', 'پ', 'ج', 'ر', 'ن'], hint: 'رو به بیرون باز می‌شود', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'کارگاه', letters: ['ا', 'ر', 'ک', 'گ', 'ه', 'ا'], hint: 'محل کار فنی', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'مداد', letters: ['ا', 'د', 'م', 'د'], hint: 'برای نوشتن', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'تصویر', letters: ['و', 'ت', 'ر', 'ص', 'ی'], hint: 'چیزی که دیده می‌شود', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'راهنما', letters: ['ر', 'م', 'ا', 'ه', 'ن', 'ا'], hint: 'کمک در مرحله', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'قهرمان', letters: ['ن', 'ر', 'ق', 'ا', 'ه', 'م'], hint: 'برنده اصلی', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'پاداش', letters: ['ا', 'ش', 'ا', 'پ', 'د'], hint: 'بعد از موفقیت', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'تمرکز', letters: ['ک', 'ز', 'ت', 'ر', 'م'], hint: 'برای حل معما لازم است', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'هوشیار', letters: ['ی', 'ر', 'ه', 'ش', 'و', 'ا'], hint: 'آماده و دقیق', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'رتبه', letters: ['ه', 'ب', 'ر', 'ت'], hint: 'جایگاه در لیگ', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'پیروزی', letters: ['و', 'ر', 'ی', 'پ', 'ز', 'ی'], hint: 'نتیجه برد', difficulty: 'medium'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'سرعت', letters: ['ت', 'ع', 'ر', 'س'], hint: 'در چالش زمانی مهم است', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'اشتباه', letters: ['ا', 'ت', 'ه', 'ب', 'ا', 'ش'], hint: 'جواب نادرست', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'منطق', letters: ['ط', 'ق', 'م', 'ن'], hint: 'برای معما لازم است', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'جایزه', letters: ['ج', 'ا', 'ز', 'ی', 'ه'], hint: 'هدیه بازی', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'تجربه', letters: ['ه', 'ج', 'ب', 'ر', 'ت'], hint: 'XP بازی', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'حافظه', letters: ['ظ', 'ح', 'ف', 'ا', 'ه'], hint: 'یادآوری آیتم‌ها', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'چیستان', letters: ['ا', 'ی', 'ت', 'ن', 'س', 'چ'], hint: 'سؤال فکری کوتاه', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'درستی', letters: ['س', 'ی', 'ر', 'ت', 'د'], hint: 'جواب صحیح', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'نقره‌ای', letters: ['ا', 'ی', 'ر', 'ق', 'ه', 'ن'], hint: 'یکی از لیگ‌ها', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'طلایی', letters: ['ی', 'ط', 'ل', 'ا', 'ی'], hint: 'لیگ بعدی', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'الماسی', letters: ['م', 'ا', 'ل', 'ا', 'ی', 'س'], hint: 'لیگ سخت‌تر', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'افسانه‌ای', letters: ['ف', 'ا', 'ا', 'ا', 'ه', 'ی', 'س', 'ن'], hint: 'بالاترین لیگ', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'مسابقه', letters: ['ب', 'س', 'ا', 'ه', 'م', 'ق'], hint: 'رقابت بین بازیکن‌ها', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'پروفایل', letters: ['ا', 'ر', 'ل', 'ف', 'ی', 'پ', 'و'], hint: 'صفحه مشخصات', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'فروشگاه', letters: ['و', 'ش', 'ه', 'ر', 'ا', 'ف', 'گ'], hint: 'محل خرید بسته‌ها', difficulty: 'hard'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'مأموریت', letters: ['ر', 'أ', 'و', 'م', 'ی', 'م', 'ت'], hint: 'کار روزانه بازی', difficulty: 'expert'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'امتیاز', letters: ['ا', 'ی', 'ت', 'م', 'ز', 'ا'], hint: 'عدد پیشرفت', difficulty: 'expert'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'رکورد', letters: ['ر', 'ک', 'و', 'د', 'ر'], hint: 'بهترین نتیجه', difficulty: 'expert'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'دقیق', letters: ['ق', 'د', 'ق', 'ی'], hint: 'بدون خطا', difficulty: 'expert'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'سریع', letters: ['ی', 'س', 'ر', 'ع'], hint: 'با زمان کم', difficulty: 'expert'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'تحلیل', letters: ['ح', 'ی', 'ل', 'ت', 'ل'], hint: 'فکر مرحله‌ای', difficulty: 'expert'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'راهبرد', letters: ['ا', 'ب', 'ر', 'ه', 'ر', 'د'], hint: 'روش بردن', difficulty: 'expert'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'نوآوری', letters: ['ن', 'و', 'ی', 'ر', 'و', 'آ'], hint: 'فکر تازه', difficulty: 'expert'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'استدلال', letters: ['ل', 'ت', 'ا', 'س', 'ل', 'ا', 'د'], hint: 'منطق قوی', difficulty: 'expert'),
    GameLevel(q: 'این حروف را مرتب کن:', word: 'فرزانگی', letters: ['ز', 'گ', 'ا', 'ف', 'ر', 'ی', 'ن'], hint: 'دانایی بالا', difficulty: 'expert'),
  ]),
  GameDef('truefalse', 'درست یا غلط', 'جمله را بخوان و سریع درست یا غلط را انتخاب کن.', 'truefalse', 1, const Color(0xFF8F6CFF), const Color(0xFFFFCF6D), 'choice', [
    GameLevel(q: 'در جواب غلط، قلب کم می‌شود.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'لیگ برنزی برای شروع بازی است.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'لیگ افسانه‌ای پایین‌ترین لیگ است.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'XP برای پیشرفت کاربر استفاده می‌شود.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'سکه هیچ کاربردی در بازی ندارد.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'انرژی برای شروع یا ادامه مرحله مهم است.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'راهنما باید بدون هزینه نامحدود باشد.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'جواب درست سکه و XP می‌دهد.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'چالش سرعتی زمان‌دار است.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'حافظه سریع به یادآوری نیاز دارد.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'درست یا غلط فقط یک گزینه دارد.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'بله یا خیر باید سریع جواب داده شود.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'سؤال‌های سخت پاداش بیشتری دارند.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'هرچه لیگ بالاتر باشد، سؤال‌ها آسان‌تر می‌شوند.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'مأموریت روزانه برای برگشت کاربر است.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'فروشگاه برای بسته‌های انرژی و راهنماست.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'نتیجه پایان بازی خلاصه عملکرد را نشان می‌دهد.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'قلب‌ها داخل یک بازی خودکار پر نمی‌شوند.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'باخت باید پیشرفت را کامل حذف کند.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'سؤال تکراری کیفیت بازی را کم می‌کند.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'نقره‌ای بعد از برنزی می‌آید.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'طلایی قبل از نقره‌ای است.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'الماسی از طلایی سخت‌تر است.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'افسانه‌ای سخت‌ترین لیگ است.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'پاداش روزانه فقط یک بار در روز گرفته می‌شود.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'medium'),
    GameLevel(q: 'تبلیغ جایزه‌دار می‌تواند سکه بدهد.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'جواب غلط باید همیشه سکه بدهد.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'مرحله بدون سؤال معنی ندارد.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'حافظه سریع نیازی به زمان نمایش ندارد.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'گزینه‌ها باید خوانا باشند.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'امتیاز لیگ با XP و رکورد بهتر می‌شود.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'در بازی خوب، قوانین باید ثابت باشند.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'تایمر برای فشار زمانی استفاده می‌شود.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'در لیگ بالاتر زمان باید منطقی‌تر سخت شود.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'راهنما جواب را کامل حذف می‌کند.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'سؤال تصویری با نشانه‌ها حل می‌شود.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'غلط‌یاب به دقت نوشتاری نیاز دارد.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'حدس کلمه با حروف ساخته می‌شود.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'معمای منطقی به رابطه بین گزینه‌ها توجه دارد.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'صفحه نتیجه نباید امتیاز را نشان دهد.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'hard'),
    GameLevel(q: 'پروفایل محل نمایش آمار کاربر است.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'expert'),
    GameLevel(q: 'جایزه‌ها و مأموریت‌ها یک بخش جدا دارند.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'expert'),
    GameLevel(q: 'سکه و انرژی همیشه باید منفی شوند.', options: ['درست', 'غلط'], answer: 1, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'expert'),
    GameLevel(q: 'پاداش لیگ روی سکه اثر می‌گذارد.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'expert'),
    GameLevel(q: 'XP بالاتر می‌تواند لیگ را تغییر دهد.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'expert'),
    GameLevel(q: 'گزینه‌های دوتایی خوانایی بازی را بهتر می‌کند.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'expert'),
    GameLevel(q: 'سؤال‌های ۵۰تایی بانک بازی را قوی‌تر می‌کند.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'expert'),
    GameLevel(q: 'بازی بدون ذخیره‌سازی پیشرفت ناقص است.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'expert'),
    GameLevel(q: 'آیکن‌ها باید با UI هماهنگ باشند.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'expert'),
    GameLevel(q: 'منطق بازی باید با نسخه HTML هماهنگ باشد.', options: ['درست', 'غلط'], answer: 0, hint: 'متن را با قانون بازی مقایسه کن.', difficulty: 'expert'),
  ]),
  GameDef('yesno', 'بله یا خیر', 'سؤال کوتاه را در ۵ ثانیه با بله یا خیر جواب بده.', 'yesno', 1, const Color(0xFF14C8D8), const Color(0xFF18BF8F), 'choice', [
    GameLevel(q: 'آیا جواب غلط قلب کم می‌کند؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'easy'),
    GameLevel(q: 'آیا لیگ برنزی سطح شروع است؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'easy'),
    GameLevel(q: 'آیا افسانه‌ای پایین‌ترین لیگ است؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'easy'),
    GameLevel(q: 'آیا XP برای پیشرفت لازم است؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'easy'),
    GameLevel(q: 'آیا راهنما باید هزینه داشته باشد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'easy'),
    GameLevel(q: 'آیا چالش سرعتی زمان‌دار است؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'easy'),
    GameLevel(q: 'آیا حافظه سریع به یادآوری آیتم‌ها نیاز دارد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'easy'),
    GameLevel(q: 'آیا سؤال تکراری خوب است؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'easy'),
    GameLevel(q: 'آیا سکه برای پاداش استفاده می‌شود؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'easy'),
    GameLevel(q: 'آیا انرژی بی‌نهایت است؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'easy'),
    GameLevel(q: 'آیا لیگ نقره‌ای بعد از برنزی است؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا طلایی از برنزی سخت‌تر است؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا الماسی از طلایی پایین‌تر است؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا پاداش روزانه باید ذخیره شود؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا فروشگاه برای خرید بسته‌هاست؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا جواب درست XP می‌دهد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا جواب غلط باید پاداش کامل بدهد؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا تایمر باید در بازی‌های سریع فعال باشد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا پروفایل آمار را نشان می‌دهد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا مأموریت روزانه بی‌هدف است؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا گزینه‌های کوچک‌تر در دو ستون خواناتر می‌شوند؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا صفحه بازی باید خیلی ریز باشد؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا قوانین باید از HTML حفظ شوند؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا سؤال‌ها باید بر اساس لیگ سخت شوند؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا راهنما می‌تواند زمان را کمی کمک کند؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'medium'),
    GameLevel(q: 'آیا اشتباه باعث کاهش قلب می‌شود؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا مرحله کامل‌شده باید جلو برود؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا پایان بازی باید نتیجه بدهد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا تبلیغ جایزه‌دار اجباری است؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا کاربر باید پیشرفت خود را ببیند؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا درست یا غلط دو گزینه دارد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا حدس کلمه گزینه‌ای معمولی است؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا غلط‌یاب با املا مرتبط است؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا معمای تصویری با نشانه حل می‌شود؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا شهربازی باید سؤال‌های جدا داشته باشد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا بانک ۵۰ سؤال برای هر بازی بهتر است؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا سکه منفی باید مجاز باشد؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا انرژی منفی باید مجاز باشد؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا رکورد سرعتی در پروفایل مهم است؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا لیگ روی پاداش اثر دارد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'hard'),
    GameLevel(q: 'آیا سؤال آسان باید در لیگ‌های اول بیشتر باشد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'expert'),
    GameLevel(q: 'آیا سؤال حرفه‌ای برای شروع مناسب است؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'expert'),
    GameLevel(q: 'آیا پاسخ درست باید فوری بررسی شود؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'expert'),
    GameLevel(q: 'آیا خروج از بازی باید ممکن باشد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'expert'),
    GameLevel(q: 'آیا قلب با شروع بازی جدید پر می‌شود؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'expert'),
    GameLevel(q: 'آیا قلب وسط همان بازی خودکار پر می‌شود؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'expert'),
    GameLevel(q: 'آیا مأموریت هفتگی ارزش نگه‌داشتن دارد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'expert'),
    GameLevel(q: 'آیا UI باید همان نسخه اختصاصی بماند؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'expert'),
    GameLevel(q: 'آیا منطق بازی‌ها باید با نسخه v52 یکی باشد؟', options: ['بله', 'خیر'], answer: 0, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'expert'),
    GameLevel(q: 'آیا سؤال بی‌جواب باید مرحله را نگه دارد؟', options: ['بله', 'خیر'], answer: 1, hint: 'سریع ولی دقیق جواب بده.', difficulty: 'expert'),
  ]),
  GameDef('picture', 'معمای تصویری', 'با نشانه‌های تصویری جواب درست را انتخاب کن.', 'picture', 1, const Color(0xFF18BF8F), const Color(0xFF14C8D8), 'choice', [
    GameLevel(q: '🪙 + 🏆 یعنی چه؟', options: ['غذا', 'باران', 'خواب', 'امتیاز لیگ'], answer: 3, hint: 'سکه و جام به رقابت مربوط است.', difficulty: 'easy'),
    GameLevel(q: '🧠 + 🎯 یعنی چه؟', options: ['تمرکز', 'خرید', 'باران', 'سفر'], answer: 0, hint: 'مغز و هدف یعنی دقت.', difficulty: 'easy'),
    GameLevel(q: '⚡ + ⏱ یعنی چه؟', options: ['آرامش', 'سرعت بازی', 'پروفایل', 'فروشگاه'], answer: 1, hint: 'انرژی و زمان نشانه سرعت است.', difficulty: 'easy'),
    GameLevel(q: '🏅 + ⭐ یعنی چه؟', options: ['رتبه ویژه', 'خروج', 'سؤال ساده', 'قفل'], answer: 0, hint: 'مدال و ستاره برای جایگاه بالاست.', difficulty: 'easy'),
    GameLevel(q: '❤️ + ⚡ یعنی چه؟', options: ['سفر', 'فروشگاه', 'عکس', 'ادامه بازی'], answer: 3, hint: 'قلب و انرژی برای ادامه‌اند.', difficulty: 'easy'),
    GameLevel(q: '📚 + ✏️ یعنی چه؟', options: ['باران', 'خواب', 'آموزش', 'ورزش'], answer: 2, hint: 'کتاب و مداد نشانه یادگیری است.', difficulty: 'easy'),
    GameLevel(q: '🎮 + 🧩 یعنی چه؟', options: ['غذا', 'بازی فکری', 'جاده', 'آب'], answer: 1, hint: 'بازی و پازل یعنی چالش ذهنی.', difficulty: 'easy'),
    GameLevel(q: '🛒 + 🪙 یعنی چه؟', options: ['سرعت', 'باران', 'درس', 'خرید با سکه'], answer: 3, hint: 'فروشگاه با سکه مرتبط است.', difficulty: 'easy'),
    GameLevel(q: '🎁 + 📅 یعنی چه؟', options: ['سایه', 'اشتباه', 'قفل', 'جایزه روزانه'], answer: 3, hint: 'هدیه و تقویم یعنی پاداش روز.', difficulty: 'easy'),
    GameLevel(q: '👤 + 📊 یعنی چه؟', options: ['ماشین', 'پروفایل آمار', 'غذا', 'پنجره'], answer: 1, hint: 'کاربر و نمودار یعنی آمار.', difficulty: 'easy'),
    GameLevel(q: '🔥 + 🧠 یعنی چه؟', options: ['چالش سخت', 'سبک', 'آرامش', 'خواب'], answer: 0, hint: 'آتش و مغز یعنی فشار ذهنی.', difficulty: 'medium'),
    GameLevel(q: '🏁 + ⏱ یعنی چه؟', options: ['آب', 'مسابقه سرعتی', 'کتاب', 'قفل'], answer: 1, hint: 'پرچم و زمان برای رقابت سریع است.', difficulty: 'medium'),
    GameLevel(q: '🔒 + ⭐ یعنی چه؟', options: ['قفل مرحله', 'خانه', 'پنجره', 'خوراکی'], answer: 0, hint: 'قفل و ستاره به مرحله مربوط‌اند.', difficulty: 'medium'),
    GameLevel(q: '🎯 + ✅ یعنی چه؟', options: ['فروشگاه', 'خروج', 'جواب درست', 'غلط'], answer: 2, hint: 'هدف و تیک یعنی موفقیت.', difficulty: 'medium'),
    GameLevel(q: '❌ + ❤️ یعنی چه؟', options: ['کم شدن قلب', 'آموزش', 'لیگ', 'پاداش'], answer: 0, hint: 'خطا و قلب یعنی جریمه.', difficulty: 'medium'),
    GameLevel(q: '💡 + 🪙 یعنی چه؟', options: ['خانه', 'سفر', 'راهنمای پولی', 'باران'], answer: 2, hint: 'لامپ و سکه یعنی کمک با هزینه.', difficulty: 'medium'),
    GameLevel(q: '📈 + XP یعنی چه؟', options: ['آب', 'افزایش تجربه', 'قفل', 'خواب'], answer: 1, hint: 'نمودار و XP یعنی رشد.', difficulty: 'medium'),
    GameLevel(q: '🏆 + 📈 یعنی چه؟', options: ['صعود لیگ', 'غذا', 'باران', 'کاغذ'], answer: 0, hint: 'جام و رشد یعنی رتبه بهتر.', difficulty: 'medium'),
    GameLevel(q: '🧠 + 👁 یعنی چه؟', options: ['فروشگاه', 'دقت دیداری', 'انرژی', 'خروج'], answer: 1, hint: 'مغز و چشم یعنی تشخیص.', difficulty: 'medium'),
    GameLevel(q: '🔤 + ❓ یعنی چه؟', options: ['حدس کلمه', 'باران', 'آینه', 'سرعت'], answer: 0, hint: 'حروف و سؤال یعنی کلمه.', difficulty: 'medium'),
    GameLevel(q: '🧩 + 🔢 یعنی چه؟', options: ['آواز', 'معمای منطقی', 'خوراکی', 'خرید'], answer: 1, hint: 'پازل و عدد یعنی منطق.', difficulty: 'medium'),
    GameLevel(q: '✍️ + ✅ یعنی چه؟', options: ['قفل', 'سفر', 'املای درست', 'خواب'], answer: 2, hint: 'نوشتن و تیک یعنی درست‌نویسی.', difficulty: 'medium'),
    GameLevel(q: '🧠 + 📝 یعنی چه؟', options: ['غذا', 'باران', 'سکه', 'حافظه و یادداشت'], answer: 3, hint: 'یادآوری با نوشتن مرتبط است.', difficulty: 'medium'),
    GameLevel(q: '🎡 + 🎯 یعنی چه؟', options: ['سایه', 'خانه', 'قفل', 'شهربازی چالشی'], answer: 3, hint: 'نماد شهربازی و هدف یعنی بازی ترکیبی.', difficulty: 'medium'),
    GameLevel(q: '⏳ + ❌ یعنی چه؟', options: ['اتمام زمان', 'قلب کامل', 'پاداش', 'فروشگاه'], answer: 0, hint: 'زمان و ضربدر یعنی فرصت تمام شد.', difficulty: 'medium'),
    GameLevel(q: '🪙 + 🎁 یعنی چه؟', options: ['آینه', 'خواب', 'آب', 'جایزه سکه'], answer: 3, hint: 'سکه و هدیه یعنی پاداش.', difficulty: 'hard'),
    GameLevel(q: '⚡ + 🛒 یعنی چه؟', options: ['سؤال', 'خرید انرژی', 'غلط', 'رتبه'], answer: 1, hint: 'انرژی و فروشگاه مرتبط‌اند.', difficulty: 'hard'),
    GameLevel(q: '❤️ + 🎁 یعنی چه؟', options: ['زمان', 'ادامه با جایزه', 'کاهش امتیاز', 'خروج'], answer: 1, hint: 'قلب و هدیه یعنی جبران.', difficulty: 'hard'),
    GameLevel(q: '🏅 + 📋 یعنی چه؟', options: ['قفل', 'آب', 'سفر', 'دستاورد'], answer: 3, hint: 'مدال و فهرست یعنی مدال‌ها.', difficulty: 'hard'),
    GameLevel(q: '📆 + 🎯 یعنی چه؟', options: ['باکس', 'خواب', 'مأموریت روزانه', 'قفل'], answer: 2, hint: 'تقویم و هدف یعنی کار روزانه.', difficulty: 'hard'),
    GameLevel(q: '🧠 + ⏱ یعنی چه؟', options: ['فروشگاه', 'فکر سریع', 'خانه', 'سفر'], answer: 1, hint: 'مغز و زمان یعنی سرعت فکر.', difficulty: 'hard'),
    GameLevel(q: '❓ + 🔍 یعنی چه؟', options: ['غذا', 'پیدا کردن جواب', 'سکه', 'خواب'], answer: 1, hint: 'سؤال و جستجو یعنی جواب.', difficulty: 'hard'),
    GameLevel(q: '⭐ + 📈 یعنی چه؟', options: ['باران', 'پیشرفت ویژه', 'آب', 'خروج'], answer: 1, hint: 'ستاره و رشد یعنی پیشرفت.', difficulty: 'hard'),
    GameLevel(q: '🛍 + 🎁 یعنی چه؟', options: ['بسته فروشگاه', 'اشتباه', 'حافظه', 'خانه'], answer: 0, hint: 'خرید و هدیه یعنی بسته.', difficulty: 'hard'),
    GameLevel(q: '🏠 + 🎮 یعنی چه؟', options: ['باران', 'خانه بازی', 'قفل', 'دفتر'], answer: 1, hint: 'خانه و بازی یعنی صفحه اصلی.', difficulty: 'hard'),
    GameLevel(q: '📊 + 🏆 یعنی چه؟', options: ['رتبه‌بندی', 'ماشین', 'خواب', 'غذا'], answer: 0, hint: 'نمودار و جام یعنی جدول.', difficulty: 'hard'),
    GameLevel(q: '🧠 + 🧩 + ⏱ یعنی چه؟', options: ['باران', 'خانه', 'خرید', 'چالش ذهنی زمان‌دار'], answer: 3, hint: 'سه نشانه با هم بازی فکری سریع‌اند.', difficulty: 'hard'),
    GameLevel(q: '✅ + 🪙 + XP یعنی چه؟', options: ['قفل', 'خروج', 'غلط', 'پاداش جواب درست'], answer: 3, hint: 'جواب درست پاداش می‌دهد.', difficulty: 'hard'),
    GameLevel(q: '❌ + ❤️ - یعنی چه؟', options: ['خرید', 'آموزش', 'جریمه اشتباه', 'پاداش کامل'], answer: 2, hint: 'اشتباه قلب را کم می‌کند.', difficulty: 'hard'),
    GameLevel(q: '🎯 + 3 یعنی چه؟', options: ['سه مأموریت', 'باران', 'خانه', 'خواب'], answer: 0, hint: 'هدف با عدد یعنی تعداد مأموریت.', difficulty: 'hard'),
    GameLevel(q: '🏆 + 450XP یعنی چه؟', options: ['مداد', 'قفل فروشگاه', 'آب', 'لیگ بعدی'], answer: 3, hint: 'عدد XP برای صعود است.', difficulty: 'expert'),
    GameLevel(q: '👁 + 🖼 یعنی چه؟', options: ['معمای تصویری', 'لیگ', 'سریع', 'سکه'], answer: 0, hint: 'چشم و تصویر یعنی دیدن نشانه.', difficulty: 'expert'),
    GameLevel(q: '🔤 + 🧠 یعنی چه؟', options: ['قفل', 'فروشگاه', 'کلمه فکری', 'روزانه'], answer: 2, hint: 'حرف و مغز یعنی حدس کلمه.', difficulty: 'expert'),
    GameLevel(q: '🧠 + 📌 یعنی چه؟', options: ['آب', 'به‌خاطر سپاری', 'آینه', 'خرید'], answer: 1, hint: 'سنجاق یعنی نگه‌داشتن در ذهن.', difficulty: 'expert'),
    GameLevel(q: '⚙️ + 🎮 یعنی چه؟', options: ['سفر', 'پاداش', 'قفل', 'تنظیمات بازی'], answer: 3, hint: 'چرخ‌دنده و بازی تنظیمات است.', difficulty: 'expert'),
    GameLevel(q: '🎉 + 🏁 یعنی چه؟', options: ['قفل', 'اشتباه', 'پایان موفق', 'زمان کم'], answer: 2, hint: 'جشن و خط پایان یعنی اتمام.', difficulty: 'expert'),
    GameLevel(q: '🪙 + 📈 یعنی چه؟', options: ['کاهش قلب', 'افزایش سکه', 'خروج', 'غلط'], answer: 1, hint: 'سکه و رشد یعنی بیشتر شدن.', difficulty: 'expert'),
    GameLevel(q: '❤️ + 0 یعنی چه؟', options: ['پاداش', 'قفل', 'راهنما', 'پایان قلب‌ها'], answer: 3, hint: 'وقتی قلب تمام شود بازی پایان می‌گیرد.', difficulty: 'expert'),
    GameLevel(q: '🧠 + 50 یعنی چه؟', options: ['خواب', 'سفر', 'بانک سؤال بزرگ', 'فروشگاه'], answer: 2, hint: 'عدد ۵۰ به تعداد سؤال‌ها اشاره دارد.', difficulty: 'expert'),
    GameLevel(q: '🎡 + 50 یعنی چه؟', options: ['خروج', '۵۰ سؤال شهربازی', 'خانه', 'قفل'], answer: 1, hint: 'شهربازی هم سؤال مستقل دارد.', difficulty: 'expert'),
  ]),
  GameDef('typo', 'غلط‌یاب', 'گزینه درست‌تر را انتخاب کن.', 'typo', 1, const Color(0xFFFF7D9B), const Color(0xFFFF5C7A), 'choice', [
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['امتیازز', 'امتیاذ', 'امطیاز', 'امتیاز'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['پیشنهاد', 'پیشنهادد', 'پشنهاد', 'پیشنهات'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['تمرکزز', 'تمرگز', 'تمرکز', 'تمرکوز'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['حرفه ایی', 'حرفه‌ایی', 'حرفهی', 'حرفه‌ای'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['پاداص', 'پاداشش', 'پاداش', 'پاداشه'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['رتبهبندیی', 'رتبه بندیی', 'ردبه‌بندی', 'رتبه‌بندی'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['انرجی', 'انرژیی', 'انرژی', 'انرژِی'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['موفکیت', 'موفقییت', 'موفغیت', 'موفقیت'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['راهنماا', 'راحنما', 'راه نماا', 'راهنما'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['مرحلا', 'محلهه', 'مرحله', 'مرهله'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['جواب درستت', 'جواب دورست', 'جواب دروست', 'جواب درست'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['ازمونن', 'آزمون‌ن', 'آزمونن', 'آزمون'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['مسولیت پزیری', 'مسئولیت‌پذیری', 'مسئولیت‌پذیریی', 'مسئولیت پدیری'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['استدلال', 'اصتدلال', 'استدلالل', 'استدلاله'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['هوشیاری', 'هوشیاریی', 'هشیاریی', 'حوشیاری'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['چالشینوو', 'چالشیننو', 'چالشینو', 'چالیشنو'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['فروشگا', 'فروشگاهه', 'فروشگاح', 'فروشگاه'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['جایزها', 'جایزه‌ها', 'جایزه هاا', 'جایزه‌حا'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['پروفایل', 'پروفایلل', 'پروفائیل', 'پروفایبل'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['مأموریتت', 'مأموریت', 'معموریت', 'ماموریتت'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['دستآورد', 'دستاورذ', 'دستاورد', 'دستاوردد'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['افثانه‌ای', 'افسانهی', 'افسانه‌ای', 'افسانه ایی'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['الماسیی', 'الماصسی', 'الماسی', 'الماصی'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['طلائیی', 'تلایی', 'طلاییی', 'طلایی'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['نغره‌ای', 'نقره ایی', 'نقره‌ای', 'نقرهی'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['برنزیی', 'برنزی', 'برنزیه', 'برنضی'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['زمانبندیی', 'زمان بندیه', 'زمان‌بندیی', 'زمان‌بندی'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['حافضه سریع', 'حافظه سریع', 'حافظه سریه', 'حافظه صریع'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['غلت‌یاب', 'غلط یابب', 'غلطیابب', 'غلط‌یاب'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['معمای منطغی', 'معمای منطقیی', 'معمای منطقی', 'معما منطقیی'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['معمای تصویی', 'معما تصویری', 'معمای تصویریی', 'معمای تصویری'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['حدص کلمه', 'حدس کلمه‌ه', 'حدس کلمه', 'حدس کلمهه'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['درست یا غلط', 'درست یا غلت', 'دروست یا غلط', 'درست یا غلطط'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['بله یا خیر', 'بله یا خیل', 'بله یا خێر', 'بله یا خیرر'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['چالش سرعتی', 'چالش سرعتیه', 'چالش سرعتیی', 'چالش صرعتی'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['شهر بازیی', 'شهرباضی', 'شهر بازیه', 'شهربازی'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['ذخیره سازیی', 'ذخیره‌سازی', 'ذخیره‌صازی', 'زخیره‌سازی'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['پاداش روزانه', 'پاداش روزانی', 'پاداش روزانح', 'پاداش روزانهه'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['امتیاز تجربح', 'امطیاز تجربه', 'امتیاز تجربه‌ه', 'امتیاز تجربه'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['راهنمای مرحله', 'راحمای مرحله', 'راهنمای مرحلهه', 'راهنمای مرحلا'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'hard'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['قلب‌ها', 'غلب‌ها', 'قلب‌هاا', 'قلبهاا'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'expert'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['سکها', 'سکه‌ها', 'سکه‌هاا', 'سکحه‌ها'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'expert'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['گذینه‌ها', 'گزینها', 'گزینه‌ها', 'گزینه هاا'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'expert'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['پاسخ صحیع', 'پاصخ صحیح', 'پاسخ صحیح', 'پاسخ صحیحح'], answer: 2, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'expert'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['ختای نوشتاری', 'خطای نوشتاری', 'خطای نوشتاریی', 'خطای نوشتری'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'expert'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['جدول لیغ', 'جدول لیگ', 'جدول لیگگ', 'جدول لیگه'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'expert'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['نتیجه بازیی', 'نتیجه بازی', 'نتیجه باضی', 'نتیجح بازی'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'expert'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['شروع بازی', 'شروع بازیی', 'شروه بازی', 'شروع باضی'], answer: 0, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'expert'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['ادامه مرحلهه', 'ادامه مرحلا', 'ادامه مرهله', 'ادامه مرحله'], answer: 3, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'expert'),
    GameLevel(q: 'کدام نوشتار درست‌تر است؟', options: ['پایان باضی', 'پایان بازی', 'پایان بازه', 'پایان بازیی'], answer: 1, hint: 'گزینه‌ای را بزن که از نظر نوشتاری صحیح‌تر است.', difficulty: 'expert'),
  ]),
  GameDef('logic', 'معمای منطقی', 'سؤال‌های کوتاه و فکری با انتخاب جواب.', 'logic', 1, const Color(0xFF6C63FF), const Color(0xFF14C8D8), 'choice', [
    GameLevel(q: 'اگر ۲ مرحله انجام دهی و یکی دیگر بروی، چند مرحله شده؟', options: ['۴', '۲', '۱', '۳'], answer: 3, hint: '۲ + ۱', difficulty: 'easy'),
    GameLevel(q: 'عدد بعدی چیست؟ ۲، ۴، ۸، ۱۶، ؟', options: ['۳۲', '۱۸', '۲۴', '۳۰'], answer: 0, hint: 'هر بار دو برابر می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'کدام گزینه با بقیه فرق دارد؟', options: ['ماشین', 'پرتقال', 'گلابی', 'سیب'], answer: 0, hint: 'سه گزینه میوه‌اند.', difficulty: 'easy'),
    GameLevel(q: 'اگر ۵ پرنده روی شاخه باشند و ۲ تا بپرند، چندتا می‌ماند؟', options: ['۵', '۳', '۲', '۷'], answer: 1, hint: '۵ منهای ۲', difficulty: 'easy'),
    GameLevel(q: 'کدام عدد زوج است؟', options: ['۲۳', '۳۵', '۱۷', '۴۲'], answer: 3, hint: 'بر ۲ بخش‌پذیر است.', difficulty: 'easy'),
    GameLevel(q: 'در کلمه «کتابخانه» چند حرف «ا» داریم؟', options: ['۲', '۱', '۴', '۳'], answer: 0, hint: 'کتابخانه دو «ا» دارد.', difficulty: 'easy'),
    GameLevel(q: 'عدد گمشده: ۳، ۶، ۹، ۱۲، ؟', options: ['۱۶', '۱۴', '۱۵', '۱۸'], answer: 2, hint: 'هر بار ۳ اضافه شده.', difficulty: 'easy'),
    GameLevel(q: 'کدام از نظر زمان طولانی‌تر است؟', options: ['یک لحظه', 'یک دقیقه', 'یک ثانیه', 'یک ساعت'], answer: 3, hint: 'ساعت بزرگ‌تر است.', difficulty: 'easy'),
    GameLevel(q: 'اگر علی از سارا بلندتر و سارا از رضا بلندتر باشد، چه کسی بلندتر است؟', options: ['رضا', 'نامشخص', 'علی', 'سارا'], answer: 2, hint: 'ترتیب را مقایسه کن.', difficulty: 'easy'),
    GameLevel(q: 'اگر ۱۰ سکه داری و ۳ تا خرج کنی، چند می‌ماند؟', options: ['۱۳', '۷', '۶', '۸'], answer: 1, hint: '۱۰ منهای ۳', difficulty: 'easy'),
    GameLevel(q: 'عدد بعدی: ۱، ۱، ۲، ۳، ۵، ؟', options: ['۸', '۶', '۱۰', '۷'], answer: 0, hint: 'الگوی فیبوناچی ساده است.', difficulty: 'medium'),
    GameLevel(q: 'اگر یک مرحله ۳ قلب داشته باشد و دو اشتباه کنی، چند قلب می‌ماند؟', options: ['۳', '۱', '۰', '۲'], answer: 1, hint: 'هر اشتباه یک قلب.', difficulty: 'medium'),
    GameLevel(q: 'کدام کوچک‌تر است؟', options: ['سانتی‌متر', 'کیلومتر', 'متر', 'هیچکدام'], answer: 0, hint: 'کوچک‌ترین واحد در گزینه‌ها.', difficulty: 'medium'),
    GameLevel(q: 'در یک مسابقه اگر نفر دوم را رد کنی، چندم می‌شوی؟', options: ['آخر', 'سوم', 'اول', 'دوم'], answer: 3, hint: 'جای نفر دوم را می‌گیری.', difficulty: 'medium'),
    GameLevel(q: 'اگر ۴ بسته هرکدام ۵ سکه بدهد، مجموع چند سکه است؟', options: ['۲۵', '۱۵', '۲۰', '۹'], answer: 2, hint: '۴ ضربدر ۵', difficulty: 'medium'),
    GameLevel(q: 'کدام عدد اول است؟', options: ['۱۳', '۱۲', '۲۱', '۱۵'], answer: 0, hint: 'فقط بر ۱ و خودش بخش‌پذیر است.', difficulty: 'medium'),
    GameLevel(q: 'اگر امروز شنبه باشد، سه روز بعد چه روزی است؟', options: ['جمعه', 'سه‌شنبه', 'چهارشنبه', 'دوشنبه'], answer: 1, hint: 'یکشنبه، دوشنبه، سه‌شنبه.', difficulty: 'medium'),
    GameLevel(q: 'نصف ۱۸ چند است؟', options: ['۹', '۱۰', '۸', '۶'], answer: 0, hint: '۱۸ تقسیم بر ۲', difficulty: 'medium'),
    GameLevel(q: 'کدام گزینه نتیجه تلاش مداوم است؟', options: ['حذف', 'اشتباه', 'پیشرفت', 'توقف'], answer: 2, hint: 'تلاش باعث رشد می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'اگر تایمر ۲۰ ثانیه باشد و ۵ ثانیه بگذرد، چند ثانیه می‌ماند؟', options: ['۵', '۱۰', '۲۰', '۱۵'], answer: 3, hint: '۲۰ منهای ۵', difficulty: 'medium'),
    GameLevel(q: 'اگر ۳ سؤال درست و ۱ غلط داشته باشی، مجموع پاسخ‌ها چند است؟', options: ['۲', '۳', '۵', '۴'], answer: 3, hint: 'درست و غلط را جمع کن.', difficulty: 'medium'),
    GameLevel(q: 'کدام عدد مضرب ۵ است؟', options: ['۴۲', '۳۸', '۴۷', '۴۵'], answer: 3, hint: 'به ۵ یا ۰ ختم می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'در ردیف ۲، ۵، ۸، ۱۱ عدد بعدی چیست؟', options: ['۱۶', '۱۵', '۱۴', '۱۳'], answer: 2, hint: 'هر بار ۳ اضافه می‌شود.', difficulty: 'medium'),
    GameLevel(q: 'اگر ۶ انرژی داری و هر مرحله ۲ انرژی بخواهد، چند مرحله می‌توانی بروی؟', options: ['۶', '۴', '۳', '۲'], answer: 2, hint: '۶ تقسیم بر ۲', difficulty: 'medium'),
    GameLevel(q: 'کدام رابطه درست است؟', options: ['۶ > ۹', '۷ < ۳', '۹ > ۶', '۵ = ۸'], answer: 2, hint: '۹ از ۶ بزرگ‌تر است.', difficulty: 'medium'),
    GameLevel(q: 'اگر ۲ راهنما بخری و یکی مصرف کنی، چند راهنما می‌ماند؟', options: ['۱', '۰', '۲', '۳'], answer: 0, hint: '۲ منهای ۱', difficulty: 'hard'),
    GameLevel(q: 'کدام گزینه برای پاسخ سریع لازم‌تر است؟', options: ['تمرکز', 'حواس‌پرتی', 'عجله کور', 'بی‌دقتی'], answer: 0, hint: 'تمرکز کمک می‌کند.', difficulty: 'hard'),
    GameLevel(q: 'اگر ۵۰ سؤال داری و ۱۰ تا جواب دادی، چند سؤال مانده؟', options: ['۵۰', '۱۰', '۳۰', '۴۰'], answer: 3, hint: '۵۰ منهای ۱۰', difficulty: 'hard'),
    GameLevel(q: 'اگر لیگ با ۹۰۰ امتیاز شروع شود و تو ۸۵۰ داری، چند امتیاز کم داری؟', options: ['۹۰', '۵۰', '۱۵۰', '۴۰'], answer: 1, hint: '۹۰۰ منهای ۸۵۰', difficulty: 'hard'),
    GameLevel(q: 'اگر هر جواب درست ۱۴ سکه بدهد و ۳ درست بزنی، چند سکه می‌گیری؟', options: ['۴۲', '۴۰', '۵۰', '۳۴'], answer: 0, hint: '۱۴ ضربدر ۳', difficulty: 'hard'),
    GameLevel(q: 'کدام ترتیب لیگ درست است؟', options: ['الماسی، برنزی، طلایی', 'برنزی، نقره‌ای، طلایی', 'نقره‌ای، طلایی، برنزی', 'طلایی، برنزی، نقره‌ای'], answer: 1, hint: 'از پایین به بالا.', difficulty: 'hard'),
    GameLevel(q: 'کدام عدد بین ۲۰ و ۳۰ است؟', options: ['۲۶', '۳۰', '۳۲', '۱۸'], answer: 0, hint: '۲۶ در بازه است.', difficulty: 'hard'),
    GameLevel(q: 'اگر سه قلب داری و سه غلط بزنی، چه می‌شود؟', options: ['سکه دوبرابر می‌شود', 'بازی تمام می‌شود', 'مرحله حذف می‌شود', 'قلب زیاد می‌شود'], answer: 1, hint: 'قلب صفر می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'در یک سؤال چهارگزینه‌ای چند انتخاب اصلی داریم؟', options: ['۳', '۴', '۲', '۵'], answer: 1, hint: 'چهارگزینه‌ای یعنی ۴ گزینه.', difficulty: 'hard'),
    GameLevel(q: 'اگر XP بیشتر شود، معمولاً چه رخ می‌دهد؟', options: ['کم شدن امتیاز', 'حذف حساب', 'خاموش شدن بازی', 'پیشرفت لیگ'], answer: 3, hint: 'XP برای رشد است.', difficulty: 'hard'),
    GameLevel(q: 'کدام گزینه با «حافظه» مرتبط‌تر است؟', options: ['پختن', 'دویدن', 'خریدن', 'یادآوری'], answer: 3, hint: 'حافظه یعنی یادآوری.', difficulty: 'hard'),
    GameLevel(q: 'اگر ۱۲ را به ۳ بخش مساوی تقسیم کنیم، هر بخش چند است؟', options: ['۴', '۳', '۶', '۵'], answer: 0, hint: '۱۲ تقسیم بر ۳', difficulty: 'hard'),
    GameLevel(q: 'کدام شکل چهار ضلع دارد؟', options: ['خط', 'دایره', 'مربع', 'مثلث'], answer: 2, hint: 'مربع چهار ضلع دارد.', difficulty: 'hard'),
    GameLevel(q: 'عدد قبل از ۱۰۰ چیست؟', options: ['۹۰', '۱۰۱', '۹۸', '۹۹'], answer: 3, hint: 'یک عدد کمتر.', difficulty: 'hard'),
    GameLevel(q: 'اگر یک مرحله سخت پاداش بیشتری بدهد، چرا؟', options: ['قلب نمی‌خواهد', 'بدون تایمر است', 'آسان‌تر است', 'ریسک بالاتر دارد'], answer: 3, hint: 'سختی بیشتر پاداش بیشتر دارد.', difficulty: 'hard'),
    GameLevel(q: 'کدام برای تحلیل بهتر است؟', options: ['رد کردن متن', 'خروج سریع', 'زدن تصادفی', 'خواندن دقیق سؤال'], answer: 3, hint: 'متن سؤال مهم است.', difficulty: 'expert'),
    GameLevel(q: 'اگر در سرعتی ۸ جواب درست بزنی، رکوردت چیست؟', options: ['۷', '۱۶', '۸', '۹'], answer: 2, hint: 'رکورد همان تعداد درست است.', difficulty: 'expert'),
    GameLevel(q: 'کدام عدد بزرگ‌تر است؟', options: ['۵۸', '۷۸', '۶۸', '۷۰'], answer: 1, hint: 'مقایسه دهگان و یکان.', difficulty: 'expert'),
    GameLevel(q: 'اگر ۲۰ انرژی داری و ۵ انرژی مصرف شود، چند می‌ماند؟', options: ['۵', '۱۰', '۱۵', '۲۵'], answer: 2, hint: '۲۰ منهای ۵', difficulty: 'expert'),
    GameLevel(q: 'کدام عبارت منطقی‌تر است؟', options: ['برای برد باید قوانین را بدانیم', 'اشتباه پاداش کامل دارد', 'سؤال بدون جواب است', 'قوانین مهم نیستند'], answer: 0, hint: 'شناخت قانون کمک می‌کند.', difficulty: 'expert'),
    GameLevel(q: 'اگر ۴ روز پشت سر هم بیایی، روز چندم است؟', options: ['۷', '۳', '۵', '۴'], answer: 3, hint: 'شمارش مستقیم.', difficulty: 'expert'),
    GameLevel(q: 'کدام بیشتر است: ۲۵ یا ۵۲؟', options: ['۵۰', '۲۵', '۵۲', '۲۲'], answer: 2, hint: 'دهگان ۵ بیشتر است.', difficulty: 'expert'),
    GameLevel(q: 'اگر سوال سخت ۲ انرژی بخواهد و ۴ انرژی داری، چند سؤال می‌توانی جواب دهی؟', options: ['۱', '۲', '۳', '۴'], answer: 1, hint: '۴ تقسیم بر ۲', difficulty: 'expert'),
    GameLevel(q: 'کدام نشانه پایان مرحله است؟', options: ['کم شدن نام', 'باز شدن فروشگاه', 'نمایش نتیجه', 'شروع تایمر'], answer: 2, hint: 'بعد از پایان نتیجه می‌آید.', difficulty: 'expert'),
    GameLevel(q: 'اگر همه گزینه‌ها کوچک و دوتایی شوند، چه چیزی بهتر می‌شود؟', options: ['خوانایی', 'سکه کم می‌شود', 'قلب زیاد می‌شود', 'بازی حذف می‌شود'], answer: 0, hint: 'چیدمان مرتب‌تر است.', difficulty: 'expert'),
  ]),
  GameDef('memory', 'حافظه سریع', 'چند آیتم را ببین و بعد از حافظه جواب بده.', 'brain', 1, const Color(0xFF30D5C8), const Color(0xFF6C63FF), 'memory', [
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['سیب', 'کتاب', 'ماه'], options: ['ماشین', 'سیب', 'ابر', 'کوه'], answer: 1, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'easy'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['قلم', 'ساعت', 'نان'], options: ['پنجره', 'نان', 'ساعت', 'قلم'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'easy'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['آب', 'درخت', 'توپ'], options: ['توپ', 'درخت', 'کتاب', 'آب'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'easy'),
    GameLevel(q: 'آیتم آخر چه بود؟', items: ['خورشید', 'مداد', 'کفش', 'باران'], options: ['باران', 'خورشید', 'کفش', 'مداد'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'easy'),
    GameLevel(q: 'کدام مورد در لیست بود؟', items: ['خانه', 'کلید', 'پنجره', 'چراغ'], options: ['صندلی', 'ماشین', 'درخت', 'کلید'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'easy'),
    GameLevel(q: 'آیتم سوم چه بود؟', items: ['ماهی', 'رود', 'سنگ', 'قایق'], options: ['قایق', 'ماهی', 'رود', 'سنگ'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'easy'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['زنبور', 'عسل', 'گل', 'باغ'], options: ['عسل', 'باغ', 'گل', 'کوه'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'easy'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['انرژی', 'سکه', 'قلب', 'لیگ'], options: ['لیگ', 'قلب', 'سکه', 'انرژی'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'easy'),
    GameLevel(q: 'آیتم چهارم چه بود؟', items: ['ابر', 'باران', 'چتر', 'خیابان', 'کفش'], options: ['کفش', 'خیابان', 'چتر', 'باران'], answer: 1, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'easy'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['کلاس', 'معلم', 'دفتر', 'دانش‌آموز', 'زنگ'], options: ['کتابخانه', 'دفتر', 'میز', 'گچ'], answer: 1, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'easy'),
    GameLevel(q: 'آیتم آخر چه بود؟', items: ['جام', 'مدال', 'ستاره', 'رتبه', 'امتیاز'], options: ['رتبه', 'امتیاز', 'جام', 'ستاره'], answer: 1, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['پرنده', 'شاخه', 'باد', 'آسمان', 'ابر'], options: ['شاخه', 'باد', 'دریا', 'آسمان'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'آیتم پنجم چه بود؟', items: ['تمرکز', 'سرعت', 'دقت', 'حافظه', 'رکورد', 'لیگ'], options: ['لیگ', 'دقت', 'حافظه', 'رکورد'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست بود؟', items: ['نقره‌ای', 'طلایی', 'الماسی', 'افسانه‌ای', 'برنزی', 'سطح'], options: ['آهنی', 'زمردی', 'یاقوتی', 'الماسی'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'آیتم سوم چه بود؟', items: ['خوراکی', 'نوشیدنی', 'سفر', 'خطر', 'قهرمانی', 'فکر'], options: ['خطر', 'سفر', 'نوشیدنی', 'فکر'], answer: 1, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['ساعت', 'پنجره', 'دفتر', 'چراغ', 'کلید', 'در'], options: ['چراغ', 'دفتر', 'کوه', 'کلید'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'آیتم ششم چه بود؟', items: ['استدلال', 'تحلیل', 'تمرکز', 'راهبرد', 'نوآوری', 'فرزانگی', 'چابکی'], options: ['راهبرد', 'چابکی', 'فرزانگی', 'نوآوری'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'آیتم هفتم چه بود؟', items: ['عدد', 'زمان', 'قلب', 'انرژی', 'سکه', 'XP', 'مرحله'], options: ['قلب', 'مرحله', 'XP', 'سکه'], answer: 1, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['باران', 'دریا', 'ابر', 'رود', 'قطره', 'موج', 'برف'], options: ['آتش', 'قطره', 'موج', 'برف'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'آیتم چهارم چه بود؟', items: ['کتاب', 'قلم', 'دفتر', 'کلاس', 'معلم', 'زنگ', 'درس'], options: ['کلاس', 'زنگ', 'معلم', 'دفتر'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['سکه', 'انرژی', 'قلب', 'لیگ', 'XP'], options: ['مرحله', 'انرژی', 'راهنما', 'پاداش'], answer: 1, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['انرژی', 'قلب', 'لیگ', 'XP', 'مرحله', 'راهنما'], options: ['قلب', 'راهنما', 'لیگ', 'انرژی'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['قلب', 'لیگ', 'XP', 'مرحله', 'راهنما', 'پاداش', 'رکورد'], options: ['قلب', 'لیگ', 'ابر', 'XP'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['لیگ', 'XP', 'مرحله', 'راهنما', 'پاداش'], options: ['مرحله', 'انرژی', 'قلب', 'سکه'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['XP', 'مرحله', 'راهنما', 'پاداش', 'رکورد', 'چالش'], options: ['راهنما', 'XP', 'مرحله', 'چالش'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'medium'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['مرحله', 'راهنما', 'پاداش', 'رکورد', 'چالش', 'تمرکز', 'سرعت'], options: ['ابر', 'راهنما', 'پاداش', 'مرحله'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['راهنما', 'پاداش', 'رکورد', 'چالش', 'تمرکز'], options: ['چالش', 'سکه', 'قلب', 'انرژی'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['پاداش', 'رکورد', 'چالش', 'تمرکز', 'سرعت', 'دقت'], options: ['دقت', 'چالش', 'رکورد', 'پاداش'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['رکورد', 'چالش', 'تمرکز', 'سرعت', 'دقت', 'حافظه', 'نتیجه'], options: ['تمرکز', 'چالش', 'ابر', 'رکورد'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['چالش', 'تمرکز', 'سرعت', 'دقت', 'حافظه'], options: ['حافظه', 'قلب', 'انرژی', 'سکه'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['تمرکز', 'سرعت', 'دقت', 'حافظه', 'نتیجه', 'فروشگاه'], options: ['تمرکز', 'دقت', 'سرعت', 'فروشگاه'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['سرعت', 'دقت', 'حافظه', 'نتیجه', 'فروشگاه', 'پروفایل', 'جایزه'], options: ['ابر', 'دقت', 'سرعت', 'حافظه'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['دقت', 'حافظه', 'نتیجه', 'فروشگاه', 'پروفایل'], options: ['قلب', 'انرژی', 'دقت', 'سکه'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['حافظه', 'نتیجه', 'فروشگاه', 'پروفایل', 'جایزه', 'مأموریت'], options: ['فروشگاه', 'مأموریت', 'حافظه', 'نتیجه'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['نتیجه', 'فروشگاه', 'پروفایل', 'جایزه', 'مأموریت', 'ستاره', 'مدال'], options: ['پروفایل', 'نتیجه', 'فروشگاه', 'ابر'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['فروشگاه', 'پروفایل', 'جایزه', 'مأموریت', 'ستاره'], options: ['قلب', 'سکه', 'انرژی', 'پروفایل'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['پروفایل', 'جایزه', 'مأموریت', 'ستاره', 'مدال', 'جام'], options: ['جام', 'پروفایل', 'مأموریت', 'جایزه'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['جایزه', 'مأموریت', 'ستاره', 'مدال', 'جام', 'رتبه', 'سؤال'], options: ['ستاره', 'مأموریت', 'جایزه', 'ابر'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['مأموریت', 'ستاره', 'مدال', 'جام', 'رتبه'], options: ['مدال', 'انرژی', 'قلب', 'سکه'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['ستاره', 'مدال', 'جام', 'رتبه', 'سؤال', 'گزینه'], options: ['گزینه', 'ستاره', 'مدال', 'جام'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['مدال', 'جام', 'رتبه', 'سؤال', 'گزینه', 'زمان', 'تایمر'], options: ['جام', 'مدال', 'رتبه', 'ابر'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'expert'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['جام', 'رتبه', 'سؤال', 'گزینه', 'زمان'], options: ['سکه', 'انرژی', 'گزینه', 'قلب'], answer: 2, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'expert'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['رتبه', 'سؤال', 'گزینه', 'زمان', 'تایمر', 'امتیاز'], options: ['سؤال', 'امتیاز', 'گزینه', 'رتبه'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'expert'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['سؤال', 'گزینه', 'زمان', 'تایمر', 'امتیاز', 'درست', 'غلط'], options: ['زمان', 'سؤال', 'گزینه', 'ابر'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'expert'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['گزینه', 'زمان', 'تایمر', 'امتیاز', 'درست'], options: ['انرژی', 'قلب', 'سکه', 'درست'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'expert'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['زمان', 'تایمر', 'امتیاز', 'درست', 'غلط', 'خانه'], options: ['زمان', 'خانه', 'امتیاز', 'تایمر'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'expert'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['تایمر', 'امتیاز', 'درست', 'غلط', 'خانه', 'آیکن', 'باکس'], options: ['ابر', 'امتیاز', 'تایمر', 'درست'], answer: 0, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'expert'),
    GameLevel(q: 'کدام مورد داخل لیست بود؟', items: ['امتیاز', 'درست', 'غلط', 'خانه', 'آیکن'], options: ['سکه', 'امتیاز', 'قلب', 'انرژی'], answer: 1, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'expert'),
    GameLevel(q: 'آیتم دوم چه بود؟', items: ['درست', 'غلط', 'خانه', 'آیکن', 'باکس', 'مسیر'], options: ['مسیر', 'خانه', 'درست', 'غلط'], answer: 3, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'expert'),
    GameLevel(q: 'کدام مورد در لیست نبود؟', items: ['غلط', 'خانه', 'آیکن', 'باکس', 'مسیر', 'روزانه', 'هفتگی'], options: ['غلط', 'ابر', 'آیکن', 'خانه'], answer: 1, hint: 'ترتیب یا وجود آیتم‌ها را به یاد بیاور.', difficulty: 'expert'),
  ]),
  GameDef('speed', 'چالش سرعتی', '۴۵ ثانیه سؤال سریع و رکوردی.', 'speed', 1, const Color(0xFFFFB84D), const Color(0xFFEF476F), 'speed', [
    GameLevel(q: '۲+۵؟', options: ['۶', '۹', '۷', '۸'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'easy'),
    GameLevel(q: 'پایتخت ایران؟', options: ['تبریز', 'تهران', 'شیراز', 'اصفهان'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'easy'),
    GameLevel(q: 'کدام زوج است؟', options: ['۱۲', '۱۵', '۹', '۷'], answer: 0, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'easy'),
    GameLevel(q: '۵×۳؟', options: ['۱۸', '۱۰', '۲۰', '۱۵'], answer: 3, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'easy'),
    GameLevel(q: 'رنگ برگ سالم؟', options: ['آبی', 'قرمز', 'سبز', 'مشکی'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'easy'),
    GameLevel(q: 'کدام حیوان پرواز می‌کند؟', options: ['اسب', 'پرنده', 'گوسفند', 'ماهی'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'easy'),
    GameLevel(q: '۱۰-۴؟', options: ['۸', '۷', '۵', '۶'], answer: 3, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'easy'),
    GameLevel(q: 'روز بعد از جمعه؟', options: ['چهارشنبه', 'شنبه', 'یکشنبه', 'پنج‌شنبه'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'easy'),
    GameLevel(q: 'کدام وسیله نوشتن است؟', options: ['قاشق', 'مداد', 'کفش', 'لیوان'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'easy'),
    GameLevel(q: '۳×۴؟', options: ['۱۴', '۱۲', '۹', '۱۰'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'easy'),
    GameLevel(q: 'آب در چند درجه یخ می‌زند؟', options: ['پنجاه', 'صفر', 'صد', 'ده'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: 'کدام برای دیدن است؟', options: ['پا', 'گوش', 'چشم', 'دست'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: '۲۰÷۵؟', options: ['۵', '۶', '۴', '۳'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: 'کدام بزرگ‌تر است؟', options: ['۱', '۹', '۲', '۴'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: 'کدام فصل گرم‌تر است؟', options: ['بهار', 'تابستان', 'زمستان', 'پاییز'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: 'کدام شکل سه ضلع دارد؟', options: ['مربع', 'مستطیل', 'مثلث', 'دایره'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: 'عدد بعد از ۱۹؟', options: ['۲۱', '۲۰', '۱۷', '۱۸'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: '۸+۶؟', options: ['۱۵', '۱۴', '۱۶', '۱۲'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: '۱۵-۷؟', options: ['۶', '۹', '۸', '۷'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: 'کدام عضو برای شنیدن است؟', options: ['زبان', 'گوش', 'چشم', 'دست'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: '۴×۶؟', options: ['۲۶', '۲۰', '۲۲', '۲۴'], answer: 3, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: '۳۰÷۶؟', options: ['۴', '۶', '۳', '۵'], answer: 3, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: 'کدام عدد فرد است؟', options: ['۱۲', '۱۴', '۱۱', '۱۶'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: 'عدد قبل از ۵۰؟', options: ['۴۹', '۴۸', '۵۱', '۵۲'], answer: 0, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: '۹+۹؟', options: ['۱۶', '۱۹', '۱۸', '۲۰'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'medium'),
    GameLevel(q: '۷×۲؟', options: ['۱۳', '۱۲', '۱۵', '۱۴'], answer: 3, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: '۱۰۰-۲۵؟', options: ['۶۵', '۷۰', '۷۵', '۸۰'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'کدام رنگ آسمان صاف است؟', options: ['آبی', 'سیاه', 'زرد', 'قرمز'], answer: 0, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'کدام خوراکی است؟', options: ['دفتر', 'کفش', 'نان', 'سنگ'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'کدام وسیله زمان است؟', options: ['کتاب', 'چکش', 'ساعت', 'مداد'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: '۶+۷؟', options: ['۱۲', '۱۴', '۱۱', '۱۳'], answer: 3, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: '۵۰÷۱۰؟', options: ['۶', '۴', '۵', '۱۰'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'کدام عدد کوچک‌تر است؟', options: ['۳', '۶', '۹', '۸'], answer: 0, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'کدام با بازی مرتبط است؟', options: ['مرحله', 'قابلمه', 'باران', 'دیوار'], answer: 0, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'کدام نشانه انرژی است؟', options: ['سنگ', 'برق', 'چوب', 'کاغذ'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: '۱۶÷۴؟', options: ['۳', '۵', '۴', '۶'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'عدد بعد از ۹۹؟', options: ['۹۸', '۱۰۱', '۹۰', '۱۰۰'], answer: 3, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'کدام برای خواندن است؟', options: ['کفش', 'لیوان', 'چکش', 'کتاب'], answer: 3, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'کدام برای نوشتن است؟', options: ['قاشق', 'ماشین', 'قلم', 'پنجره'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'کدام پاداش بازی است؟', options: ['خروج', 'غلط', 'قفل', 'سکه'], answer: 3, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'hard'),
    GameLevel(q: 'کدام برای ادامه لازم است؟', options: ['انرژی', 'کوه', 'ابر', 'دیوار'], answer: 0, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'expert'),
    GameLevel(q: 'کدام با رتبه مرتبط است؟', options: ['لیگ', 'باران', 'سفر', 'قاشق'], answer: 0, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'expert'),
    GameLevel(q: 'کدام یعنی تجربه؟', options: ['APK', 'ZIP', 'UI', 'XP'], answer: 3, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'expert'),
    GameLevel(q: 'کدام یعنی جان بازی؟', options: ['کتاب', 'قلب', 'دود', 'پنجره'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'expert'),
    GameLevel(q: 'کدام یعنی کمک؟', options: ['قفل', 'راهنما', 'غلط', 'خروج'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'expert'),
    GameLevel(q: 'کدام یعنی جواب صحیح؟', options: ['خواب', 'درست', 'غلط', 'باران'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'expert'),
    GameLevel(q: 'کدام یعنی پایان فرصت؟', options: ['اتمام زمان', 'شروع', 'پاداش کامل', 'فروشگاه'], answer: 0, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'expert'),
    GameLevel(q: 'کدام بازی با حروف است؟', options: ['شهربازی', 'حدس کلمه', 'پروفایل', 'فروشگاه'], answer: 1, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'expert'),
    GameLevel(q: 'کدام بازی با یادآوری است؟', options: ['لیگ', 'غلط‌یاب', 'حافظه سریع', 'پروفایل'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'expert'),
    GameLevel(q: 'کدام بازی با املاء است؟', options: ['فروشگاه', 'حافظه', 'غلط‌یاب', 'خانه'], answer: 2, hint: 'در چالش سرعتی سریع‌تر تصمیم بگیر.', difficulty: 'expert'),
  ]),
  GameDef('amusement', 'شهربازی', '۵۰ سؤال سرگرمی و چالش مرحله‌ای.', 'amusement', 1, const Color(0xFFFFCF6D), const Color(0xFF6C63FF), 'choice', [
    GameLevel(q: 'در شهربازی، وسیله‌ای که بالا و پایین می‌رود چیست؟', options: ['قلم', 'ساعت', 'کتاب', 'چرخ‌وفلک'], answer: 3, hint: 'در شهربازی دیده می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'کدام خوراکی بیشتر با شهربازی یادآوری می‌شود؟', options: ['نان خشک', 'سوپ', 'پشمک', 'برنج'], answer: 2, hint: 'شیرین و سبک است.', difficulty: 'easy'),
    GameLevel(q: 'در صف بازی باید چه کار کرد؟', options: ['هل داد', 'دوید', 'قانون را حذف کرد', 'نوبت را رعایت کرد'], answer: 3, hint: 'قانون صف مهم است.', difficulty: 'easy'),
    GameLevel(q: 'بلیت برای چه استفاده می‌شود؟', options: ['نوشتن', 'ورود به بازی', 'باران', 'خوابیدن'], answer: 1, hint: 'برای استفاده از بازی‌هاست.', difficulty: 'easy'),
    GameLevel(q: 'کدام بازی معمولاً سریع می‌چرخد؟', options: ['آشپزخانه', 'کتابخانه', 'ترن هوایی', 'کلاس'], answer: 2, hint: 'هیجان بالایی دارد.', difficulty: 'easy'),
    GameLevel(q: 'کدام وسیله در شهربازی نورانی‌تر است؟', options: ['تابلوهای چراغی', 'کفش', 'دفتر ساده', 'سنگ'], answer: 0, hint: 'شب‌ها بیشتر دیده می‌شود.', difficulty: 'easy'),
    GameLevel(q: 'در بازی هدف‌گیری باید چه چیز مهم‌تر باشد؟', options: ['دقت', 'عجله کور', 'چشم‌بستن', 'بی‌حوصلگی'], answer: 0, hint: 'هدف‌گیری به دقت نیاز دارد.', difficulty: 'easy'),
    GameLevel(q: 'اگر ۳ بلیت داری و ۱ خرج کنی، چند بلیت می‌ماند؟', options: ['۴', '۳', '۲', '۱'], answer: 2, hint: '۳ منهای ۱', difficulty: 'easy'),
    GameLevel(q: 'کدام برای امنیت لازم است؟', options: ['کمربند ایمنی', 'کاغذ', 'سکه اضافه', 'مداد'], answer: 0, hint: 'در وسیله‌های هیجانی مهم است.', difficulty: 'easy'),
    GameLevel(q: 'کدام بازی بیشتر به حافظه شبیه است؟', options: ['پیدا کردن جفت‌ها', 'خوردن پشمک', 'تاب خوردن', 'قدم زدن'], answer: 0, hint: 'باید جای کارت‌ها را به خاطر بسپاری.', difficulty: 'easy'),
    GameLevel(q: 'اگر یک بازی ۵ سکه بخواهد و ۱۵ سکه داری، چند بار می‌توانی بازی کنی؟', options: ['۳', '۵', '۲', '۴'], answer: 0, hint: '۱۵ تقسیم بر ۵', difficulty: 'medium'),
    GameLevel(q: 'در شهربازی، باخت در یک بازی یعنی چه؟', options: ['امتحان دوباره', 'پایان همه چیز', 'قفل دائمی', 'حذف حساب'], answer: 0, hint: 'می‌توان دوباره تلاش کرد.', difficulty: 'medium'),
    GameLevel(q: 'کدام رفتار درست است؟', options: ['زدن دکمه خراب', 'بی‌توجهی به هشدار', 'عبور از صف', 'رعایت قانون بازی'], answer: 3, hint: 'قانون بازی برای همه است.', difficulty: 'medium'),
    GameLevel(q: 'در بازی پرتاب حلقه، چه مهارتی مهم است؟', options: ['خواب', 'غذا', 'سر و صدا', 'تمرکز'], answer: 3, hint: 'باید دقیق پرتاب کنی.', difficulty: 'medium'),
    GameLevel(q: 'اگر جایزه کوچک گرفتی، بهترین واکنش چیست؟', options: ['ترک بازی', 'شکستن وسیله', 'ناراحتی شدید', 'ادامه تلاش'], answer: 3, hint: 'بازی برای سرگرمی است.', difficulty: 'medium'),
    GameLevel(q: 'کدام بازی به سرعت واکنش نیاز دارد؟', options: ['خرید خوراکی', 'نشستن', 'نقاشی دیوار', 'چراغ واکنشی'], answer: 3, hint: 'باید سریع دکمه را بزنی.', difficulty: 'medium'),
    GameLevel(q: 'کدام گزینه نشانه بازی سالم است؟', options: ['قانون روشن', 'دکمه خراب', 'صف بی‌نظم', 'جایزه نامعلوم'], answer: 0, hint: 'قوانین باید واضح باشند.', difficulty: 'medium'),
    GameLevel(q: 'کدام قسمت شهربازی برای استراحت است؟', options: ['ترن', 'هدف‌گیری', 'نیمکت', 'تاب زنجیری'], answer: 2, hint: 'برای نشستن است.', difficulty: 'medium'),
    GameLevel(q: 'اگر بازی زمان‌دار باشد، چه چیزی مهم است؟', options: ['سرعت', 'ایستادن', 'تأخیر', 'فراموشی'], answer: 0, hint: 'زمان محدود است.', difficulty: 'medium'),
    GameLevel(q: 'کدام بازی با شانس بیشتر مرتبط است؟', options: ['گردونه شانس', 'املا', 'حافظه', 'منطق'], answer: 0, hint: 'چرخش نتیجه را تعیین می‌کند.', difficulty: 'medium'),
    GameLevel(q: 'کدام برای بردن جایزه بزرگ لازم‌تر است؟', options: ['امتیاز بیشتر', 'اشتباه بیشتر', 'سکه کمتر', 'زمان تمام‌شده'], answer: 0, hint: 'جایزه به امتیاز بستگی دارد.', difficulty: 'medium'),
    GameLevel(q: 'در بازی حدس عدد، بهتر است چه کنی؟', options: ['منطقی حدس بزنی', 'نخوانی', 'تصادفی بزنی', 'خارج شوی'], answer: 0, hint: 'با منطق احتمال بیشتر است.', difficulty: 'medium'),
    GameLevel(q: 'اگر ۴ بازی انجام دهی و ۲ تا ببری، چند برد داری؟', options: ['۴', '۱', '۲', '۶'], answer: 2, hint: 'تعداد بردها همان ۲ است.', difficulty: 'medium'),
    GameLevel(q: 'کدام وسیله باید قبل از شروع بررسی شود؟', options: ['اسم خیابان', 'قفل ایمنی', 'کفش دیگران', 'رنگ آسمان'], answer: 1, hint: 'برای امنیت است.', difficulty: 'medium'),
    GameLevel(q: 'در بازی سریع، چشم باید کجا باشد؟', options: ['روی آسمان', 'روی زمین', 'روی موبایل دیگران', 'روی هدف'], answer: 3, hint: 'هدف بازی مهم است.', difficulty: 'medium'),
    GameLevel(q: 'کدام گزینه جایزه است؟', options: ['عروسک', 'بلیط پاره', 'خطا', 'صف طولانی'], answer: 0, hint: 'معمولاً جایزه بازی است.', difficulty: 'hard'),
    GameLevel(q: 'اگر در بازی امتیازی ۱۰ بگیری و رکورد ۱۲ باشد، چند امتیاز کم داری؟', options: ['۱', '۱۲', '۳', '۲'], answer: 3, hint: '۱۲ منهای ۱۰', difficulty: 'hard'),
    GameLevel(q: 'کدام حس در شهربازی طبیعی است؟', options: ['بی‌تفاوتی کامل', 'خواب عمیق', 'ترس از سؤال', 'هیجان'], answer: 3, hint: 'شهربازی هیجان دارد.', difficulty: 'hard'),
    GameLevel(q: 'کدام بازی به حافظه تصویری نزدیک‌تر است؟', options: ['قایق آرام', 'نیمکت', 'ترن هوایی', 'کارت‌های مخفی'], answer: 3, hint: 'باید تصویرها را حفظ کنی.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد نباید انجام شود؟', options: ['بلیت دادن', 'رعایت هشدار', 'هل دادن در صف', 'نوبت گرفتن'], answer: 2, hint: 'هل دادن خطرناک است.', difficulty: 'hard'),
    GameLevel(q: 'در بازی تیراندازی هدف چیست؟', options: ['زدن مرکز هدف', 'خوردن پشمک', 'خروج', 'نشستن'], answer: 0, hint: 'مرکز هدف امتیاز دارد.', difficulty: 'hard'),
    GameLevel(q: 'اگر هر برد ۱۰ سکه بدهد و ۳ برد داشته باشی، چند سکه می‌گیری؟', options: ['۴۰', '۱۰', '۲۰', '۳۰'], answer: 3, hint: '۳ ضربدر ۱۰', difficulty: 'hard'),
    GameLevel(q: 'کدام نشانه پایان بازی است؟', options: ['نمایش امتیاز', 'روشن شدن چراغ', 'خرید بلیت', 'شروع صف'], answer: 0, hint: 'آخر بازی نتیجه می‌آید.', difficulty: 'hard'),
    GameLevel(q: 'در شهربازی، کدام بخش برای خرید است؟', options: ['ترن', 'تاب', 'چرخ‌وفلک', 'غرفه فروش'], answer: 3, hint: 'غرفه محل فروش است.', difficulty: 'hard'),
    GameLevel(q: 'اگر زمان بازی تمام شود، چه باید دید؟', options: ['تنظیمات', 'پروفایل', 'نتیجه', 'فروشگاه'], answer: 2, hint: 'بعد از زمان، نتیجه نمایش داده می‌شود.', difficulty: 'hard'),
    GameLevel(q: 'کدام بازی به تعادل نیاز دارد؟', options: ['دیدن نقشه', 'خرید بلیت', 'پل معلق', 'جدول کلمات'], answer: 2, hint: 'باید تعادل حفظ شود.', difficulty: 'hard'),
    GameLevel(q: 'کدام چیز در بازی‌ها مصرف می‌شود؟', options: ['نام کاربر', 'آسمان', 'دیوار', 'بلیت'], answer: 3, hint: 'برای ورود به بازی است.', difficulty: 'hard'),
    GameLevel(q: 'اگر ۵۰ امتیاز برای جایزه لازم است و ۴۰ داری، چند کم داری؟', options: ['۱۰', '۲۰', '۵', '۳۰'], answer: 0, hint: '۵۰ منهای ۴۰', difficulty: 'hard'),
    GameLevel(q: 'کدام قانون برای کودک و بزرگسال یکسان است؟', options: ['ایمنی', 'نام خانوادگی', 'مدل گوشی', 'رنگ لباس'], answer: 0, hint: 'ایمنی برای همه است.', difficulty: 'hard'),
    GameLevel(q: 'در بازی حافظه شهربازی، چه چیزی مهم است؟', options: ['زمان غذا', 'صدای بلند', 'رنگ کفش', 'جای آیتم‌ها'], answer: 3, hint: 'باید مکان آیتم‌ها را حفظ کنی.', difficulty: 'hard'),
    GameLevel(q: 'کدام مورد بیشتر با شهربازی مرتبط است؟', options: ['امتحان مدرسه', 'هیجان', 'کار اداری', 'جلسه رسمی'], answer: 1, hint: 'شهربازی برای سرگرمی است.', difficulty: 'expert'),
    GameLevel(q: 'اگر یک بازی دو مرحله داشته باشد و یکی را رد کنی، چند مرحله مانده؟', options: ['۳', '۰', '۱', '۲'], answer: 2, hint: '۲ منهای ۱', difficulty: 'expert'),
    GameLevel(q: 'کدام گزینه مهارت هدف‌گیری است؟', options: ['فراموشی', 'نشانه‌گیری', 'خروج', 'بی‌دقتی'], answer: 1, hint: 'هدف‌گیری یعنی نشانه گرفتن.', difficulty: 'expert'),
    GameLevel(q: 'کدام مورد پاداش برد است؟', options: ['قلب کمتر', 'غلط بیشتر', 'سکه و جایزه', 'زمان صفر'], answer: 2, hint: 'برد پاداش دارد.', difficulty: 'expert'),
    GameLevel(q: 'در بازی چرخشی چه چیزی ممکن است تغییر کند؟', options: ['رنگ آسمان', 'قوانین قلب', 'نام کاربر', 'جهت و سرعت'], answer: 3, hint: 'چرخش با سرعت و جهت مرتبط است.', difficulty: 'expert'),
    GameLevel(q: 'کدام بازی با پرتاب توپ مرتبط است؟', options: ['حدس کلمه', 'فروشگاه', 'پروفایل', 'توپ به هدف'], answer: 3, hint: 'توپ باید به هدف بخورد.', difficulty: 'expert'),
    GameLevel(q: 'اگر ۲ بار ببازی و ۳ بار ببری، چند بازی انجام داده‌ای؟', options: ['۴', '۳', '۲', '۵'], answer: 3, hint: 'برد و باخت را جمع کن.', difficulty: 'expert'),
    GameLevel(q: 'کدام نشانه بازی قفل است؟', options: ['سکه اضافه', 'قلب کامل', 'قفل روی کارت', 'ستاره روی کارت'], answer: 2, hint: 'قفل یعنی هنوز باز نیست.', difficulty: 'expert'),
    GameLevel(q: 'برای بازی بهتر، سؤال باید چه باشد؟', options: ['محو و ریز', 'واضح و خوانا', 'تکراری زیاد', 'بدون جواب'], answer: 1, hint: 'خوانایی مهم است.', difficulty: 'expert'),
    GameLevel(q: 'در شهربازی چالشینو، هدف اصلی چیست؟', options: ['حذف کاربر', 'کم کردن همه سکه‌ها', 'بی‌قانونی', 'سرگرمی و پیشرفت'], answer: 3, hint: 'بازی باید سرگرم‌کننده باشد.', difficulty: 'expert'),
  ]),
];

class PlayerState {
  int coins;
  int energy;
  int xp;
  int hints;
  int gamesDone;
  int correct;
  int wrong;
  int ads;
  int bestSpeed;
  String dailyDate;
  Map<String, int> progresses;
  Set<String> playedGames;
  Set<String> achievements;

  PlayerState({
    this.coins = 970,
    this.energy = 50,
    this.xp = 0,
    this.hints = 3,
    this.gamesDone = 0,
    this.correct = 0,
    this.wrong = 0,
    this.ads = 0,
    this.bestSpeed = 0,
    this.dailyDate = '',
    Map<String, int>? progresses,
    Set<String>? playedGames,
    Set<String>? achievements,
  })  : progresses = progresses ?? <String, int>{},
        playedGames = playedGames ?? <String>{},
        achievements = achievements ?? <String>{};

  Map<String, dynamic> toJson() => {
        'coins': coins,
        'energy': energy,
        'xp': xp,
        'hints': hints,
        'gamesDone': gamesDone,
        'correct': correct,
        'wrong': wrong,
        'ads': ads,
        'bestSpeed': bestSpeed,
        'dailyDate': dailyDate,
        'progresses': progresses,
        'playedGames': playedGames.toList(),
        'achievements': achievements.toList(),
      };

  factory PlayerState.fromJson(Map<String, dynamic> json) => PlayerState(
        coins: json['coins'] ?? 970,
        energy: json['energy'] ?? 50,
        xp: json['xp'] ?? 0,
        hints: json['hints'] ?? 3,
        gamesDone: json['gamesDone'] ?? 0,
        correct: json['correct'] ?? 0,
        wrong: json['wrong'] ?? 0,
        ads: json['ads'] ?? 0,
        bestSpeed: json['bestSpeed'] ?? 0,
        dailyDate: json['dailyDate'] ?? '',
        progresses: (json['progresses'] is Map)
            ? Map<String, int>.from((json['progresses'] as Map).map((k, v) => MapEntry(k.toString(), (v as num).toInt())))
            : <String, int>{},
        playedGames: Set<String>.from(json['playedGames'] ?? const []),
        achievements: Set<String>.from(json['achievements'] ?? const []),
      );
}

class LeagueRule {
  final String name;
  final int min;
  final double coin;
  final double xp;
  const LeagueRule(this.name, this.min, this.coin, this.xp);
}

const leagueRules = <LeagueRule>[
  LeagueRule('برنزی', 0, 1.00, 1.00),
  LeagueRule('نقره‌ای', 900, 1.15, 1.15),
  LeagueRule('طلایی', 2200, 1.35, 1.30),
  LeagueRule('الماسی', 4200, 1.60, 1.55),
  LeagueRule('افسانه‌ای', 7000, 1.90, 1.85),
];

class ChaleshinoRoot extends StatefulWidget {
  const ChaleshinoRoot({super.key});

  @override
  State<ChaleshinoRoot> createState() => _ChaleshinoRootState();
}

class _ChaleshinoRootState extends State<ChaleshinoRoot> {
  PlayerState state = PlayerState();
  String tab = 'home';
  GameDef? activeGame;
  int hearts = 3;
  int runCorrect = 0;
  int runWrong = 0;
  int lastCoins = 0;
  int lastXp = 0;
  int timeLeft = 0;
  int timeTotal = 1;
  int? selectedAnswer;
  bool hintShown = false;
  bool memoryPreview = false;
  String wordAnswer = '';
  final List<int> wordPicked = <int>[];
  int speedIndex = 0;
  int speedScore = 0;
  int speedWrong = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('chaleshino_flutter_v6_state') ?? prefs.getString('chaleshino_flutter_v5_state');
    if (saved == null) return;
    try {
      setState(() => state = PlayerState.fromJson(jsonDecode(saved)));
    } catch (_) {}
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('chaleshino_flutter_v6_state', jsonEncode(state.toJson()));
  }

  LeagueRule get league {
    final score = state.xp + state.bestSpeed * 40 + state.correct * 10;
    var current = leagueRules.first;
    for (final l in leagueRules) {
      if (score >= l.min) current = l;
    }
    return current;
  }

  int _diffRank(String d) {
    switch (d) {
      case 'expert':
        return 3;
      case 'hard':
        return 2;
      case 'medium':
        return 1;
      default:
        return 0;
    }
  }

  int _leagueDiffRank() {
    switch (league.name) {
      case 'افسانه‌ای':
      case 'الماسی':
        return 3;
      case 'طلایی':
        return 2;
      case 'نقره‌ای':
        return 1;
      default:
        return 0;
    }
  }

  List<GameLevel> _eligibleLevels(GameDef game) {
    final rank = _leagueDiffRank();
    final list = game.levels.where((l) => _diffRank(l.difficulty) <= rank).toList();
    return list.isEmpty ? game.levels : list;
  }

  int _levelIndex(GameDef game) {
    final levels = _eligibleLevels(game);
    return (state.progresses[game.id] ?? 0) % levels.length;
  }

  GameLevel _level(GameDef game) => _eligibleLevels(game)[_levelIndex(game)];

  int _energyCost(GameLevel level) => _diffRank(level.difficulty) >= 2 ? 2 : 1;

  int _memoryPreviewLimit(GameLevel level) {
    switch (level.difficulty) {
      case 'expert':
        return 2;
      case 'hard':
      case 'medium':
        return 3;
      default:
        return 4;
    }
  }

  int _timeLimit(GameDef game, GameLevel level) {
    if (game.mode == 'speed') return 45;
    if (game.id == 'truefalse' || game.id == 'yesno') return 5;
    if (game.mode == 'memory') return level.difficulty == 'easy' ? 12 : level.difficulty == 'medium' ? 10 : 8;
    if (level.difficulty == 'easy') return 20;
    if (level.difficulty == 'medium') return 15;
    return 10;
  }

  int _baseCoin(GameLevel level) {
    switch (level.difficulty) {
      case 'expert':
        return 32;
      case 'hard':
        return 23;
      case 'medium':
        return 16;
      default:
        return 10;
    }
  }

  int _baseXp(GameLevel level, int stars) {
    final bonus = level.difficulty == 'expert' ? 12 : level.difficulty == 'hard' ? 7 : level.difficulty == 'medium' ? 4 : 0;
    return 8 + (stars * 4) + bonus;
  }

  String _today() => DateTime.now().toIso8601String().substring(0, 10);

  void openTab(String next) {
    timer?.cancel();
    setState(() {
      tab = next;
      activeGame = null;
    });
  }

  void startGame(GameDef game) {
    if (state.energy < _energyCost(_level(game))) {
      _toast('انرژی کافی نیست');
      return;
    }
    timer?.cancel();
    setState(() {
      activeGame = game;
      tab = 'game';
      hearts = 3;
      runCorrect = 0;
      runWrong = 0;
      lastCoins = 0;
      lastXp = 0;
      selectedAnswer = null;
      hintShown = false;
      speedScore = 0;
      speedWrong = 0;
      speedIndex = 0;
    });
    _prepareLevel();
    _save();
  }

  void _prepareLevel() {
    final game = activeGame;
    if (game == null) return;
    final level = _level(game);
    timer?.cancel();
    setState(() {
      selectedAnswer = null;
      hintShown = false;
      wordAnswer = '';
      wordPicked.clear();
      memoryPreview = game.mode == 'memory';
      if (game.mode == 'speed') {
        timeTotal = 45;
        timeLeft = 45;
        speedIndex = speedIndex % game.levels.length;
      } else if (game.mode == 'memory') {
        timeTotal = _memoryPreviewLimit(level);
        timeLeft = timeTotal;
      } else {
        timeTotal = _timeLimit(game, level);
        timeLeft = timeTotal;
      }
    });
    if (game.mode == 'speed') {
      _startTimer(_endSpeed);
    } else if (game.mode == 'memory') {
      _startTimer(_switchMemoryToAnswer);
    } else {
      _startTimer(() => _finishLevel(false));
    }
  }

  void _startTimer(VoidCallback onExpire) {
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (timeLeft <= 1) {
        t.cancel();
        onExpire();
      } else {
        setState(() => timeLeft--);
      }
    });
  }

  void _switchMemoryToAnswer() {
    final game = activeGame;
    if (game == null || tab != 'game') return;
    final level = _level(game);
    setState(() {
      memoryPreview = false;
      timeTotal = _timeLimit(game, level);
      timeLeft = timeTotal;
    });
    _startTimer(() => _finishLevel(false));
  }

  void _choiceAnswer(int index) {
    final game = activeGame;
    if (game == null || selectedAnswer != null) return;
    final level = game.mode == 'speed' ? game.levels[speedIndex % game.levels.length] : _level(game);
    setState(() => selectedAnswer = index);
    Future.delayed(const Duration(milliseconds: 260), () {
      if (!mounted || tab != 'game') return;
      if (game.mode == 'speed') {
        _speedAnswer(index == level.answer);
      } else {
        _finishLevel(index == level.answer);
      }
    });
  }

  void _speedAnswer(bool ok) {
    final game = activeGame;
    if (game == null) return;
    setState(() {
      if (ok) {
        speedScore++;
      } else {
        speedWrong++;
      }
      selectedAnswer = null;
      speedIndex = (speedIndex + 1) % game.levels.length;
    });
  }

  void _endSpeed() {
    if (activeGame?.mode != 'speed') return;
    timer?.cancel();
    final earnedCoins = speedScore * 10;
    final earnedXp = speedScore * 14;
    setState(() {
      runCorrect = speedScore;
      runWrong = speedWrong;
      lastCoins = earnedCoins;
      lastXp = earnedXp;
      state.coins += earnedCoins;
      state.xp += earnedXp;
      state.correct += speedScore;
      state.wrong += speedWrong;
      state.bestSpeed = math.max(state.bestSpeed, speedScore);
      _completeGameStats(activeGame!.id);
      tab = 'result';
    });
    _save();
  }

  void _wordPick(int index) {
    final game = activeGame;
    if (game == null || game.mode != 'word') return;
    final level = _level(game);
    if (wordPicked.contains(index)) return;
    if (wordAnswer.length >= (level.word ?? '').length) return;
    setState(() {
      wordPicked.add(index);
      wordAnswer += level.letters[index];
    });
  }

  void _wordBackspace() {
    if (wordPicked.isEmpty) return;
    setState(() {
      wordPicked.removeLast();
      if (wordAnswer.isNotEmpty) wordAnswer = wordAnswer.substring(0, wordAnswer.length - 1);
    });
  }

  void _wordClear() {
    setState(() {
      wordPicked.clear();
      wordAnswer = '';
    });
  }

  String _norm(String s) => s.replaceAll('ي', 'ی').replaceAll('ك', 'ک').replaceAll('آ', 'ا').replaceAll(RegExp(r'\s+'), '').trim();

  void _wordSubmit() {
    final game = activeGame;
    if (game == null || game.mode != 'word') return;
    final level = _level(game);
    _finishLevel(_norm(wordAnswer) == _norm(level.word ?? ''));
  }

  void _useHint() {
    if (hintShown) return;
    if (state.hints <= 0) {
      _toast('راهنما نداری');
      return;
    }
    setState(() {
      state.hints--;
      hintShown = true;
    });
    _save();
  }

  void _finishLevel(bool ok) {
    final game = activeGame;
    if (game == null) return;
    timer?.cancel();
    final level = _level(game);
    final stars = math.max(1, math.min(3, hearts - (hintShown ? 1 : 0)));
    final rawCoin = _baseCoin(level) + stars * 4;
    final rawXp = _baseXp(level, stars);
    final coinReward = (ok ? (rawCoin * league.coin).round() : 0);
    final xpReward = (ok ? (rawXp * league.xp).round() : 0);
    setState(() {
      if (ok) {
        runCorrect++;
        state.correct++;
        state.energy = math.max(0, state.energy - _energyCost(level));
        state.coins += coinReward;
        state.xp += xpReward;
        lastCoins += coinReward;
        lastXp += xpReward;
      } else {
        runWrong++;
        state.wrong++;
        hearts = math.max(0, hearts - 1);
      }
      state.progresses[game.id] = (state.progresses[game.id] ?? 0) + 1;
    });

    final played = runCorrect + runWrong;
    if (hearts <= 0 || played >= 5) {
      _showResult();
    } else {
      _prepareLevel();
    }
    _save();
  }

  void _showResult() {
    final game = activeGame;
    if (game == null) return;
    setState(() {
      _completeGameStats(game.id);
      tab = 'result';
    });
  }

  void _completeGameStats(String gameId) {
    state.gamesDone++;
    state.playedGames.add(gameId);
    if (state.gamesDone >= 3) state.achievements.add('۳ بازی انجام‌شده');
    if (state.correct >= 10) state.achievements.add('۱۰ جواب درست');
    if (state.xp >= 450) state.achievements.add('رسیدن به لیگ بعدی');
    if (state.playedGames.length >= 5) state.achievements.add('۵ بازی مختلف');
    if (state.bestSpeed >= 8) state.achievements.add('رکورد سرعتی');
  }

  void claimDaily() {
    final today = _today();
    if (state.dailyDate == today) {
      _toast('جایزه امروز قبلاً گرفته شده');
      return;
    }
    setState(() {
      state.dailyDate = today;
      state.coins += 130;
      state.energy += 10;
      state.achievements.add('دریافت جایزه روزانه');
    });
    _save();
    _toast('جایزه روزانه دریافت شد');
  }

  void watchAd() {
    setState(() {
      state.ads++;
      state.coins += 150;
      state.energy += 10;
      state.achievements.add('تماشای تبلیغ جایزه‌دار');
    });
    _save();
    _toast('۱۵۰ سکه و ۱۰ انرژی اضافه شد');
  }

  void buy({int coins = 0, int energy = 0, int hints = 0}) {
    setState(() {
      state.coins += coins;
      state.energy += energy;
      state.hints += hints;
    });
    _save();
    _toast('بسته اضافه شد');
  }

  void _toast(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: AppColor.ink, fontWeight: FontWeight.w900)),
        backgroundColor: Colors.white,
        behavior: SnackBarBehavior.floating,
        elevation: 18,
        margin: const EdgeInsets.fromLTRB(34, 0, 34, 104),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: AppColor.cyan.withOpacity(.16))),
        duration: const Duration(milliseconds: 1100),
      ),
    );
  }

  Widget _page() {
    switch (tab) {
      case 'shop':
        return ShopPage(state: state, onBuy: buy, onAd: watchAd);
      case 'rewards':
        return RewardsPage(state: state, onDaily: claimDaily, onAd: watchAd);
      case 'league':
        return LeaguePage(state: state, league: league);
      case 'profile':
        return ProfilePage(state: state);
      case 'game':
        final game = activeGame ?? games.first;
        final level = game.mode == 'speed' ? game.levels[speedIndex % game.levels.length] : _level(game);
        return GamePage(
          game: game,
          level: level,
          levelNumber: game.mode == 'speed' ? speedIndex + 1 : _levelIndex(game) + 1,
          totalLevels: game.mode == 'speed' ? game.levels.length : _eligibleLevels(game).length,
          hearts: hearts,
          correct: runCorrect,
          wrong: runWrong,
          timeLeft: timeLeft,
          timeTotal: timeTotal,
          selectedAnswer: selectedAnswer,
          hintShown: hintShown,
          memoryPreview: memoryPreview,
          wordAnswer: wordAnswer,
          wordPicked: wordPicked,
          speedScore: speedScore,
          speedWrong: speedWrong,
          onBack: () => openTab('home'),
          onChoice: _choiceAnswer,
          onWordLetter: _wordPick,
          onWordBack: _wordBackspace,
          onWordClear: _wordClear,
          onWordSubmit: _wordSubmit,
          onHint: _useHint,
        );
      case 'result':
        return ResultPage(game: activeGame ?? games.first, correct: runCorrect, wrong: runWrong, coins: lastCoins, xp: lastXp, onHome: () => openTab('home'), onReplay: () => startGame(activeGame ?? games.first), onAd: watchAd);
      default:
        return HomePage(state: state, onStart: startGame, onAd: watchAd);
    }
  }

  @override
  Widget build(BuildContext context) {
    final showNav = tab != 'game' && tab != 'result';
    return Scaffold(
      backgroundColor: AppColor.bg,
      bottomNavigationBar: showNav ? HtmlBottomNav(active: tab, onTap: openTab) : null,
      body: HtmlBackground(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Column(
              children: [
                SafeArea(bottom: false, child: TopBar(state: state, onProfile: () => openTab('profile'))),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 160),
                    child: ListView(
                      key: ValueKey(tab),
                      padding: EdgeInsets.fromLTRB(tab == 'game' ? 8 : 16, tab == 'home' ? 6 : 12, tab == 'game' ? 8 : 16, showNav ? 26 : 20),
                      children: [_page()],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HtmlBackground extends StatelessWidget {
  final Widget child;
  const HtmlBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFE4EBF7), Color(0xFFF1F6FF), Color(0xFFE7E1FF)], stops: [0, .46, 1]),
      ),
      child: Stack(
        children: [
          Positioned(top: -70, right: -70, child: CircleBlob(size: 220, color: AppColor.primary.withOpacity(.23))),
          Positioned(top: 58, left: -82, child: CircleBlob(size: 204, color: AppColor.cyan.withOpacity(.24))),
          Positioned(bottom: -115, left: 80, child: CircleBlob(size: 250, color: AppColor.orange.withOpacity(.20))),
          CustomPaint(painter: HtmlGridPainter(), size: Size.infinite),
          child,
        ],
      ),
    );
  }
}

class CircleBlob extends StatelessWidget {
  final double size;
  final Color color;
  const CircleBlob({super.key, required this.size, required this.color});
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: BoxDecoration(color: color, shape: BoxShape.circle));
}

class HtmlGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p1 = Paint()..color = AppColor.primary.withOpacity(.052)..strokeWidth = 1;
    final p2 = Paint()..color = AppColor.cyan.withOpacity(.052)..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 34) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p1);
    }
    for (double x = 0; x < size.width; x += 34) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p2);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class TopBar extends StatelessWidget {
  final PlayerState state;
  final VoidCallback onProfile;
  const TopBar({super.key, required this.state, required this.onProfile});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                HtmlIconBox(icon: 'brain', size: 48, radius: 18, colors: const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)], iconColor: AppColor.primary),
                const SizedBox(width: 10),
                const Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('چالشینو', style: TextStyle(fontSize: 22, height: 1.05, fontWeight: FontWeight.w900, color: AppColor.ink)),
                      SizedBox(height: 4),
                      Text('نسخه تستی v52', style: TextStyle(fontSize: 11, color: Color(0xFF6D7893), fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Wrap(
            textDirection: TextDirection.ltr,
            spacing: 7,
            runSpacing: 7,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              GestureDetector(onTap: onProfile, child: HtmlIconBox(icon: 'profile', size: 44, radius: 18, colors: const [Colors.white, Color(0xFFEFFBFF)], iconColor: AppColor.primary)),
              WalletPill(icon: 'energy', value: state.energy.toString()),
              WalletPill(icon: 'coin', value: state.coins.toString()),
            ],
          ),
        ],
      ),
    );
  }
}

class WalletPill extends StatelessWidget {
  final String icon;
  final String value;
  const WalletPill({super.key, required this.icon, required this.value});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFEFFBFF)]),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColor.cyan.withOpacity(.16)),
        boxShadow: [BoxShadow(color: const Color(0xFF374696).withOpacity(.15), blurRadius: 24, offset: const Offset(0, 12))],
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [HtmlSvgIcon(icon, size: 18, color: icon == 'coin' ? AppColor.orange : AppColor.primary), const SizedBox(width: 6), Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: AppColor.ink))]),
    );
  }
}

class HomePage extends StatelessWidget {
  final PlayerState state;
  final ValueChanged<GameDef> onStart;
  final VoidCallback onAd;
  const HomePage({super.key, required this.state, required this.onStart, required this.onAd});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SizedBox(
        height: 106,
        child: ListView(
          scrollDirection: Axis.horizontal,
          reverse: true,
          padding: const EdgeInsets.only(bottom: 10),
          children: [
            HomeAdCard(title: 'تبلیغ ویدئویی جایزه‌دار', subtitle: 'Placement واقعی ثبت شد؛ در HTML فعلاً شبیه‌سازی می‌شود.', icon: 'ad', action: 'تماشا', onTap: onAd),
            const SizedBox(width: 12),
            const HomeAdCard(title: 'تبلیغ بنری', subtitle: 'جایگاه بنری واقعی برای نسخه اندروید آماده شد.', icon: 'gift'),
            const SizedBox(width: 12),
            const HomeAdCard(title: 'بنر دوم تستی', subtitle: 'اسکرول افقی بنرها برای اتصال SDK حفظ شد.', icon: 'star'),
          ],
        ),
      ),
      GamesFrame(onStart: onStart),
      const SizedBox(height: 12),
      const SectionTitle(title: 'مسیر امروز', hint: 'مأموریت روزانه'),
      MissionProgressCard(title: '۳ بازی انجام بده', subtitle: '${state.gamesDone.clamp(0, 3)}/3 بازی ثبت شده', value: (state.gamesDone / 3).clamp(0, 1).toDouble(), icon: 'target', c1: AppColor.green, c2: AppColor.cyan),
      const SizedBox(height: 12),
      MissionProgressCard(title: '۱۰ جواب درست', subtitle: '${state.correct.clamp(0, 10)}/10 جواب درست', value: (state.correct / 10).clamp(0, 1).toDouble(), icon: 'brain', c1: AppColor.orange, c2: AppColor.danger),
    ]);
  }
}

class HomeAdCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final String? action;
  final VoidCallback? onTap;
  const HomeAdCard({super.key, required this.title, required this.subtitle, required this.icon, this.action, this.onTap});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: action == null ? 248 : 292,
      padding: const EdgeInsets.all(12),
      decoration: htmlCard(colors: const [Color(0xFFFFF8EA), Colors.white, Color(0xFFEEFBFF)], radius: 27, border: AppColor.cyan.withOpacity(.14), shadowOpacity: .14),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 46, radius: 17, colors: const [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Colors.white),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, color: AppColor.ink, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.3, color: Color(0xFF60708B), fontWeight: FontWeight.w800, height: 1.55))])),
        if (action != null) ...[const SizedBox(width: 8), HtmlButton(label: action!, onTap: onTap ?? () {}, color1: AppColor.green, color2: AppColor.cyan, compact: true)],
      ]),
    );
  }
}

class GamesFrame extends StatelessWidget {
  final ValueChanged<GameDef> onStart;
  const GamesFrame({super.key, required this.onStart});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: -4),
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 9),
      decoration: BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white.withOpacity(.28), const Color(0xFFEEF8FF).withOpacity(.22)]),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withOpacity(.48)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SectionTitle(title: 'بازی‌ها', hint: 'اسکرول کن'),
        SizedBox(
          height: 206,
          child: ListView.separated(
            reverse: true,
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(8, 2, 8, 7),
            itemCount: games.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) => GameCard(game: games[index], onTap: () => onStart(games[index])),
          ),
        ),
      ]),
    );
  }
}

class GameCard extends StatelessWidget {
  final GameDef game;
  final VoidCallback onTap;
  const GameCard({super.key, required this.game, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 214,
        padding: const EdgeInsets.all(14),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF0FBFF)], radius: 26, border: AppColor.cyan.withOpacity(.13)),
        child: Stack(children: [
          Positioned(left: -34, bottom: -48, child: CircleBlob(size: 122, color: game.c1.withOpacity(.14))),
          Positioned.fill(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                HtmlIconBox(icon: game.icon, size: 52, radius: 18, colors: [game.c1, game.c2], iconColor: Colors.white),
                MiniChip(text: game.mode == 'speed' ? 'رکوردی' : 'ادامه'),
              ]),
              const SizedBox(height: 8),
              Text(game.title, style: const TextStyle(fontSize: 16.5, height: 1.35, fontWeight: FontWeight.w900, color: AppColor.ink)),
              const SizedBox(height: 5),
              Text(game.description, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.2, height: 1.6, fontWeight: FontWeight.w700, color: AppColor.muted)),
              const SizedBox(height: 8),
              HtmlProgress(value: .28, colors: [game.c1, game.c2], height: 8),
              const Spacer(),
              Row(children: [MiniChip(text: '${game.energy} انرژی'), const SizedBox(width: 6), const MiniChip(text: 'لیگ برنزی')]),
            ]),
          ),
        ]),
      ),
    );
  }
}

class RewardsPage extends StatelessWidget {
  final PlayerState state;
  final VoidCallback onDaily;
  final VoidCallback onAd;
  const RewardsPage({super.key, required this.state, required this.onDaily, required this.onAd});
  @override
  Widget build(BuildContext context) {
    final claimed = state.dailyDate == DateTime.now().toIso8601String().substring(0, 10);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'جایزه‌ها و مأموریت‌ها', subtitle: 'مأموریت‌های روزانه و هفتگی با لیگ فعلی هماهنگ شده‌اند.', icon: 'gift'),
      const SizedBox(height: 14),
      QuestCard(title: 'جایزه روزانه', subtitle: claimed ? 'جایزه امروز دریافت شده است.' : '۱۳۰ سکه؛ با تبلیغ دو برابر می‌شود.', icon: 'gift', c1: AppColor.orange, c2: AppColor.danger, button: claimed ? 'دریافت شد' : 'دریافت', onTap: onDaily),
      const SizedBox(height: 14),
      const SectionTitle(title: 'مأموریت‌های روزانه', hint: 'امروز'),
      MissionProgressCard(title: '۳ مرحله امروز', subtitle: 'امروز ۳ مرحله کامل کن و پاداش بگیر.', value: (state.gamesDone / 3).clamp(0, 1).toDouble(), icon: 'target', c1: AppColor.green, c2: AppColor.cyan),
      const SizedBox(height: 12),
      MissionProgressCard(title: '۳ بازی مختلف', subtitle: '${state.playedGames.length.clamp(0, 3)}/3 بازی مختلف انجام شده.', value: (state.playedGames.length / 3).clamp(0, 1).toDouble(), icon: 'brain', c1: AppColor.cyan, c2: AppColor.green),
      const SizedBox(height: 12),
      QuestCard(title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه + ۱۰ انرژی تستی', icon: 'ad', c1: AppColor.primary, c2: AppColor.cyan, button: 'تماشا', onTap: onAd),
    ]);
  }
}

class ShopPage extends StatelessWidget {
  final PlayerState state;
  final void Function({int coins, int energy, int hints}) onBuy;
  final VoidCallback onAd;
  const ShopPage({super.key, required this.state, required this.onBuy, required this.onAd});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'فروشگاه چالشینو', subtitle: 'بسته‌های سکه و آیتم‌های بازی برای تست اقتصاد داخلی اضافه شدند.', icon: 'shop'),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: ShopStat(value: state.coins.toString(), label: 'سکه')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.energy.toString(), label: 'انرژی')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.hints.toString(), label: 'راهنما'))]),
      const SectionTitle(title: 'بسته‌های سکه', hint: 'اسکرول افقی'),
      SizedBox(
        height: 176,
        child: ListView(scrollDirection: Axis.horizontal, reverse: true, children: [
          ProductTile(title: '۱۰۰۰ سکه', subtitle: 'بسته شروع', icon: 'coin', c1: AppColor.orange, c2: const Color(0xFFFF9F43), onTap: () => onBuy(coins: 1000)),
          ProductTile(title: '۵۰ انرژی', subtitle: 'برای بازی بیشتر', icon: 'energy', c1: AppColor.cyan, c2: AppColor.primary, onTap: () => onBuy(energy: 50)),
          ProductTile(title: '۵ راهنما', subtitle: 'کمک داخل بازی', icon: 'riddle', c1: AppColor.green, c2: AppColor.cyan, onTap: () => onBuy(hints: 5)),
          ProductTile(title: 'تبلیغ جایزه‌دار', subtitle: '۱۵۰ سکه رایگان', icon: 'ad', c1: AppColor.primary, c2: AppColor.orange, onTap: onAd),
        ]),
      ),
      const SizedBox(height: 12),
      const HtmlNote(text: 'پرداخت واقعی در نسخه مارکتی فعال می‌شود. این بخش فعلاً تستی است.'),
    ]);
  }
}

class LeaguePage extends StatelessWidget {
  final PlayerState state;
  final LeagueRule league;
  const LeaguePage({super.key, required this.state, required this.league});
  @override
  Widget build(BuildContext context) {
    final next = leagueRules.firstWhere((l) => l.min > (state.xp + state.bestSpeed * 40 + state.correct * 10), orElse: () => leagueRules.last);
    final value = next == league ? 1.0 : ((state.xp + state.bestSpeed * 40 + state.correct * 10) / next.min).clamp(0, 1).toDouble();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      MiniHero(title: 'لیگ ${league.name}', subtitle: 'تا لیگ بعدی: XP ${next.min}', icon: 'medal', trailing: 'XP ${state.xp}'),
      const SizedBox(height: 12),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: htmlCard(colors: const [Color(0xFFFFF9E8), Colors.white, Color(0xFFF5FBFF)], radius: 30, border: AppColor.orange.withOpacity(.18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [const HtmlIconBox(icon: 'medal', size: 60, radius: 22, colors: [Color(0xFFFFCF6D), Color(0xFFFF9F43)], iconColor: Colors.white), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('لیگ فعلی تو: ${league.name}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 6), Text('پاداش سکه ×${league.coin} • XP ×${league.xp}', style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))]))]),
          const SizedBox(height: 16),
          HtmlProgress(value: value, colors: const [AppColor.orange, AppColor.cyan]),
        ]),
      ),
      const SectionTitle(title: 'رتبه‌بندی کامل', hint: 'نمونه تستی'),
      RankRow(name: 'بازیکن چالشینو', score: state.xp, active: true),
      const RankRow(name: 'هانا', score: 390),
      const RankRow(name: 'آرمان', score: 310),
      const RankRow(name: 'سارا', score: 280),
    ]);
  }
}

class ProfilePage extends StatelessWidget {
  final PlayerState state;
  const ProfilePage({super.key, required this.state});
  @override
  Widget build(BuildContext context) {
    final success = state.correct + state.wrong == 0 ? 0 : ((state.correct / (state.correct + state.wrong)) * 100).round();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const MiniHero(title: 'پروفایل کامل‌تر', subtitle: 'آمار، تنظیمات و دستاوردها', icon: 'profile'),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: ShopStat(value: state.gamesDone.toString(), label: 'بازی')), const SizedBox(width: 8), Expanded(child: ShopStat(value: '$success%', label: 'موفقیت')), const SizedBox(width: 8), Expanded(child: ShopStat(value: state.bestSpeed.toString(), label: 'رکورد سرعت'))]),
      const SectionTitle(title: 'دستاوردها', hint: 'مدال‌ها'),
      if (state.achievements.isEmpty) const HtmlNote(text: 'هنوز مدالی نگرفتی. چند بازی انجام بده تا مدال‌ها فعال شوند.') else ...state.achievements.map((a) => Padding(padding: const EdgeInsets.only(bottom: 10), child: QuestCard(title: a, subtitle: 'دستاورد فعال شده', icon: 'star', c1: AppColor.orange, c2: AppColor.primary, button: 'فعال', onTap: () {}))),
      const SectionTitle(title: 'تنظیمات بازی', hint: 'تستی'),
      const SettingsLikeCard(title: 'صدا', subtitle: 'برای نسخه Flutter به صداهای بازی وصل می‌شود.'),
      const SizedBox(height: 10),
      const SettingsLikeCard(title: 'لرزش', subtitle: 'برای لمس‌ها و جواب درست/غلط در موبایل.'),
    ]);
  }
}

class GamePage extends StatelessWidget {
  final GameDef game;
  final GameLevel level;
  final int levelNumber;
  final int totalLevels;
  final int hearts;
  final int correct;
  final int wrong;
  final int timeLeft;
  final int timeTotal;
  final int? selectedAnswer;
  final bool hintShown;
  final bool memoryPreview;
  final String wordAnswer;
  final List<int> wordPicked;
  final int speedScore;
  final int speedWrong;
  final VoidCallback onBack;
  final ValueChanged<int> onChoice;
  final ValueChanged<int> onWordLetter;
  final VoidCallback onWordBack;
  final VoidCallback onWordClear;
  final VoidCallback onWordSubmit;
  final VoidCallback onHint;

  const GamePage({
    super.key,
    required this.game,
    required this.level,
    required this.levelNumber,
    required this.totalLevels,
    required this.hearts,
    required this.correct,
    required this.wrong,
    required this.timeLeft,
    required this.timeTotal,
    required this.selectedAnswer,
    required this.hintShown,
    required this.memoryPreview,
    required this.wordAnswer,
    required this.wordPicked,
    required this.speedScore,
    required this.speedWrong,
    required this.onBack,
    required this.onChoice,
    required this.onWordLetter,
    required this.onWordBack,
    required this.onWordClear,
    required this.onWordSubmit,
    required this.onHint,
  });

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _gameHeader(),
      const SizedBox(height: 10),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF3FBFF), Color(0xFFFFF7EA)], radius: 32, border: AppColor.primary.withOpacity(.16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          _levelTop(),
          const SizedBox(height: 10),
          if (game.mode != 'speed') HtmlProgress(value: timeTotal <= 0 ? 0 : timeLeft / timeTotal, colors: [game.c1, game.c2], height: 10),
          if (game.mode != 'speed') const SizedBox(height: 10),
          if (game.mode == 'word') _wordBody() else if (game.mode == 'memory') _memoryBody() else if (game.mode == 'speed') _speedBody() else _choiceBody(),
          if (game.mode != 'speed') ...[
            const SizedBox(height: 10),
            if (hintShown) HtmlNote(text: 'راهنما: ${level.hint}'),
            const SizedBox(height: 10),
            Row(children: [Expanded(child: HtmlButton(label: 'راهنما', onTap: onHint, color1: AppColor.orange, color2: AppColor.danger, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'بازگشت', onTap: onBack, color1: AppColor.primary, color2: AppColor.violet, compact: true))]),
          ],
        ]),
      ),
    ]);
  }

  Widget _gameHeader() {
    return Row(children: [
      GestureDetector(onTap: onBack, child: Container(width: 42, height: 42, decoration: htmlCard(colors: const [Colors.white, Color(0xFFEFFBFF)], radius: 16, shadowOpacity: .12), child: const Center(child: Text('‹', style: TextStyle(fontSize: 30, color: AppColor.ink, fontWeight: FontWeight.w900))))),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(game.title, style: const TextStyle(fontSize: 18, color: AppColor.ink, fontWeight: FontWeight.w900)), Text(game.mode == 'speed' ? 'امتیاز: $speedScore • غلط: $speedWrong' : 'قلب‌ها: $hearts • درست: $correct • غلط: $wrong', style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))])),
      HtmlIconBox(icon: game.icon, size: 48, radius: 18, colors: [game.c1, game.c2], iconColor: Colors.white),
    ]);
  }

  Widget _levelTop() {
    final heartsRow = Row(mainAxisSize: MainAxisSize.min, children: List.generate(3, (i) => Padding(padding: const EdgeInsets.only(left: 4), child: Icon(Icons.favorite, size: 18, color: i < hearts ? AppColor.danger : AppColor.danger.withOpacity(.22)))));
    return Row(children: [
      MiniChip(text: game.mode == 'speed' ? '۴۵ ثانیه' : 'مرحله $levelNumber/$totalLevels'),
      const Spacer(),
      if (game.mode != 'speed') heartsRow,
      if (game.mode == 'speed') MiniChip(text: 'زمان $timeLeft'),
    ]);
  }

  Widget _questionBox(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      decoration: htmlCard(colors: const [Color(0xFFEEF8FF), Color(0xFFF7F3FF), Color(0xFFFFF8ED)], radius: 26, border: AppColor.primary.withOpacity(.15), shadowOpacity: .10),
      child: Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, height: 1.75, fontWeight: FontWeight.w900, color: AppColor.ink)),
    );
  }

  Widget _choiceBody() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _questionBox(level.q),
      const SizedBox(height: 12),
      _choiceGrid(),
    ]);
  }

  Widget _choiceGrid() {
    final count = level.options.length;
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: count,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 2.85,
      ),
      itemBuilder: (context, i) => _choiceButton(i, level.options[i]),
    );
  }

  Widget _choiceButton(int index, String text) {
    final selected = selectedAnswer == index;
    final isGood = selected && index == level.answer;
    final isBad = selected && index != level.answer;
    final colors = isGood ? const [Color(0xFFE6FFF5), Color(0xFFF4FFFB)] : isBad ? const [Color(0xFFFFEEF3), Color(0xFFFFF8FA)] : const [Colors.white, Color(0xFFEAF7FF), Color(0xFFF2EEFF)];
    return GestureDetector(
      onTap: selectedAnswer == null ? () => onChoice(index) : null,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: htmlCard(colors: colors, radius: 18, border: isGood ? AppColor.green.withOpacity(.35) : isBad ? AppColor.danger.withOpacity(.35) : AppColor.primary.withOpacity(.14), shadowOpacity: .08),
        child: Center(child: Text(text, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: TextStyle(fontSize: 13.2, height: 1.35, fontWeight: FontWeight.w900, color: isBad ? AppColor.danger : isGood ? AppColor.green : AppColor.ink))),
      ),
    );
  }

  Widget _wordBody() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _questionBox(level.q),
      const SizedBox(height: 10),
      Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 8, children: level.letters.map((x) => Container(width: 42, height: 42, alignment: Alignment.center, decoration: htmlCard(colors: const [Colors.white, Color(0xFFFFF2D9)], radius: 15, border: AppColor.orange.withOpacity(.22), shadowOpacity: .09), child: Text(x, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColor.ink)))).toList()),
      const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(12), decoration: htmlCard(colors: const [Colors.white, Color(0xFFF7F1FF)], radius: 18, shadowOpacity: .08), child: Text(wordAnswer.isEmpty ? 'جواب را بساز...' : wordAnswer, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppColor.ink))),
      const SizedBox(height: 10),
      Wrap(spacing: 7, runSpacing: 7, alignment: WrapAlignment.center, children: List.generate(level.letters.length, (i) {
        final used = wordPicked.contains(i);
        return GestureDetector(
          onTap: used ? null : () => onWordLetter(i),
          child: Opacity(opacity: used ? .36 : 1, child: Container(width: 40, height: 40, alignment: Alignment.center, decoration: htmlCard(colors: const [Colors.white, Color(0xFFEEF8FF)], radius: 14, shadowOpacity: .08), child: Text(level.letters[i], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColor.ink)))),
        );
      })),
      const SizedBox(height: 10),
      Row(children: [Expanded(child: HtmlButton(label: 'ثبت', onTap: onWordSubmit, color1: AppColor.green, color2: AppColor.cyan, compact: true)), const SizedBox(width: 7), Expanded(child: HtmlButton(label: 'حذف', onTap: onWordBack, color1: AppColor.orange, color2: AppColor.danger, compact: true)), const SizedBox(width: 7), Expanded(child: HtmlButton(label: 'پاک کن', onTap: onWordClear, color1: AppColor.primary, color2: AppColor.violet, compact: true))]),
    ]);
  }

  Widget _memoryBody() {
    if (memoryPreview) {
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _questionBox('این آیتم‌ها را به خاطر بسپار'),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: level.items.map((x) => MiniChip(text: x)).toList()),
        const SizedBox(height: 10),
        const HtmlNote(text: 'بعد از پایان زمان، آیتم‌ها مخفی می‌شوند.'),
      ]);
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _questionBox(level.q),
      const SizedBox(height: 12),
      _choiceGrid(),
    ]);
  }

  Widget _speedBody() {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(children: [Expanded(child: ShopStat(value: timeLeft.toString(), label: 'زمان')), const SizedBox(width: 8), Expanded(child: ShopStat(value: speedScore.toString(), label: 'امتیاز')), const SizedBox(width: 8), Expanded(child: ShopStat(value: speedWrong.toString(), label: 'غلط'))]),
      const SizedBox(height: 10),
      HtmlProgress(value: timeTotal <= 0 ? 0 : timeLeft / timeTotal, colors: [game.c1, game.c2], height: 10),
      const SizedBox(height: 12),
      _questionBox(level.q),
      const SizedBox(height: 12),
      _choiceGrid(),
      const SizedBox(height: 8),
      HtmlButton(label: 'خروج', onTap: onBack, color1: AppColor.primary, color2: AppColor.violet, compact: true),
    ]);
  }
}

class ResultPage extends StatelessWidget {
  final GameDef game;
  final int correct;
  final int wrong;
  final int coins;
  final int xp;
  final VoidCallback onHome;
  final VoidCallback onReplay;
  final VoidCallback onAd;
  const ResultPage({super.key, required this.game, required this.correct, required this.wrong, required this.coins, required this.xp, required this.onHome, required this.onReplay, required this.onAd});
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      MiniHero(title: 'نتیجه ${game.title}', subtitle: 'خلاصه عملکرد این بازی', icon: 'trophy'),
      const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(18), decoration: htmlCard(colors: const [Colors.white, Color(0xFFF3FBFF), Color(0xFFFFF8EE)], radius: 28, border: AppColor.primary.withOpacity(.15)), child: Column(children: [
        const HtmlIconBox(icon: 'trophy', size: 72, radius: 26, colors: [AppColor.cyan, AppColor.primary], iconColor: Colors.white),
        const SizedBox(height: 10),
        const Text('بازی کامل شد', style: TextStyle(fontSize: 22, color: AppColor.ink, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: ShopStat(value: correct.toString(), label: 'درست')), const SizedBox(width: 8), Expanded(child: ShopStat(value: wrong.toString(), label: 'غلط')), const SizedBox(width: 8), Expanded(child: ShopStat(value: coins.toString(), label: 'سکه'))]),
        const SizedBox(height: 8),
        Row(children: [Expanded(child: ShopStat(value: xp.toString(), label: 'XP')), const SizedBox(width: 8), Expanded(child: ShopStat(value: (correct + wrong).toString(), label: 'مرحله')), const SizedBox(width: 8), Expanded(child: ShopStat(value: game.energy.toString(), label: 'انرژی مصرفی'))]),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: HtmlButton(label: 'خانه', onTap: onHome, color1: AppColor.primary, color2: AppColor.violet, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'دوباره', onTap: onReplay, color1: AppColor.green, color2: AppColor.cyan, compact: true)), const SizedBox(width: 8), Expanded(child: HtmlButton(label: 'ادامه با تبلیغ', onTap: onAd, color1: AppColor.orange, color2: AppColor.danger, compact: true))]),
      ])),
    ]);
  }
}

class MiniHero extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final String? trailing;
  const MiniHero({super.key, required this.title, required this.subtitle, required this.icon, this.trailing});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 52, radius: 20, colors: const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)], iconColor: AppColor.primary),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, height: 1.45, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 5), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.7, fontWeight: FontWeight.w800, color: AppColor.muted))])),
        if (trailing != null) MiniChip(text: trailing!),
      ]),
    );
  }
}

class MissionProgressCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final double value;
  final String icon;
  final Color c1;
  final Color c2;
  const MissionProgressCard({super.key, required this.title, required this.subtitle, required this.value, required this.icon, required this.c1, required this.c2});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 54, radius: 20, colors: [c1, c2], iconColor: Colors.white),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 8), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.6, fontWeight: FontWeight.w800, color: AppColor.muted)), const SizedBox(height: 9), HtmlProgress(value: value, colors: [c1, c2])])),
      ]),
    );
  }
}

class QuestCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color c1;
  final Color c2;
  final String button;
  final VoidCallback onTap;
  const QuestCard({super.key, required this.title, required this.subtitle, required this.icon, required this.c1, required this.c2, required this.button, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: htmlCard(radius: 30),
      child: Row(children: [
        HtmlIconBox(icon: icon, size: 56, radius: 20, colors: [c1, c2], iconColor: Colors.white),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 6), Text(subtitle, style: const TextStyle(fontSize: 12, height: 1.7, fontWeight: FontWeight.w800, color: AppColor.muted))])),
        const SizedBox(width: 8),
        HtmlButton(label: button, onTap: onTap, color1: AppColor.green, color2: AppColor.cyan, compact: true),
      ]),
    );
  }
}

class ProductTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String icon;
  final Color c1;
  final Color c2;
  final VoidCallback onTap;
  const ProductTile({super.key, required this.title, required this.subtitle, required this.icon, required this.c1, required this.c2, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 148,
        margin: const EdgeInsets.only(left: 10),
        padding: const EdgeInsets.all(13),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF5FBFF)], radius: 24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          HtmlIconBox(icon: icon, size: 48, radius: 17, colors: [c1, c2], iconColor: Colors.white),
          const Spacer(),
          Text(title, style: const TextStyle(fontSize: 14.5, color: AppColor.ink, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text(subtitle, style: const TextStyle(fontSize: 11.5, color: AppColor.muted, fontWeight: FontWeight.w800, height: 1.5)),
        ]),
      ),
    );
  }
}

class RankRow extends StatelessWidget {
  final String name;
  final int score;
  final bool active;
  const RankRow({super.key, required this.name, required this.score, this.active = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: htmlCard(colors: active ? const [Color(0xFFEFFFF8), Color(0xFFF5FBFF)] : const [Colors.white, Color(0xFFF4FBFF)], radius: 24, border: active ? AppColor.green.withOpacity(.24) : null, shadowOpacity: .12),
      child: Row(children: [HtmlIconBox(icon: active ? 'profile' : 'star', size: 42, radius: 16), const SizedBox(width: 10), Expanded(child: Text(name, style: const TextStyle(fontSize: 14, color: AppColor.ink, fontWeight: FontWeight.w900))), MiniChip(text: '$score امتیاز')]),
    );
  }
}

class ShopStat extends StatelessWidget {
  final String value;
  final String label;
  const ShopStat({super.key, required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: htmlCard(colors: const [Colors.white, Color(0xFFF0FBFF)], radius: 20, shadowOpacity: .10),
        child: Column(children: [Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 11.2, color: AppColor.muted, fontWeight: FontWeight.w800))]),
      );
}

class SettingsLikeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  const SettingsLikeCard({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(14),
        decoration: htmlCard(radius: 22, shadowOpacity: .10),
        child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppColor.ink)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(fontSize: 11.5, height: 1.7, color: AppColor.muted, fontWeight: FontWeight.w800))])), const MiniChip(text: 'روشن')]),
      );
}

class HtmlNote extends StatelessWidget {
  final String text;
  const HtmlNote({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFF7FBFF)]), border: Border.all(color: AppColor.primary.withOpacity(.18)), borderRadius: BorderRadius.circular(22)),
        child: Text(text, style: const TextStyle(fontSize: 12, height: 1.8, fontWeight: FontWeight.w800, color: AppColor.muted)),
      );
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String hint;
  const SectionTitle({super.key, required this.title, required this.hint});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 14, 2, 10),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(title, style: const TextStyle(fontSize: 18, color: AppColor.ink, fontWeight: FontWeight.w900)), Text(hint, style: const TextStyle(fontSize: 12, color: AppColor.muted, fontWeight: FontWeight.w800))]),
      );
}

class HtmlProgress extends StatelessWidget {
  final double value;
  final List<Color> colors;
  final double height;
  const HtmlProgress({super.key, required this.value, required this.colors, this.height = 9});
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(99),
        child: Container(
          height: height,
          color: const Color(0xFFE8F2FB),
          child: Align(alignment: Alignment.centerRight, child: FractionallySizedBox(widthFactor: value.clamp(0, 1).toDouble(), child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: colors), borderRadius: BorderRadius.circular(99))))),
        ),
      );
}

class MiniChip extends StatelessWidget {
  final String text;
  const MiniChip({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Colors.white, Color(0xFFF0F8FF)]), border: Border.all(color: AppColor.cyan.withOpacity(.14)), borderRadius: BorderRadius.circular(999)),
        child: Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFF344260))),
      );
}

class HtmlButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color color1;
  final Color color2;
  final bool compact;
  const HtmlButton({super.key, required this.label, required this.onTap, required this.color1, required this.color2, this.compact = false});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: compact ? 11 : 16, vertical: compact ? 9 : 13),
          decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [color1, color2]), borderRadius: BorderRadius.circular(compact ? 16 : 19), boxShadow: [BoxShadow(color: const Color(0xFF374696).withOpacity(.15), blurRadius: 24, offset: const Offset(0, 12))]),
          child: Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: compact ? 11.5 : 14, fontWeight: FontWeight.w900, color: Colors.white)),
        ),
      );
}

class HtmlBottomNav extends StatelessWidget {
  final String active;
  final ValueChanged<String> onTap;
  const HtmlBottomNav({super.key, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('rewards', 'جایزه‌ها', 'gift'),
      ('league', 'لیگ', 'trophy'),
      ('home', 'خانه', 'home'),
      ('shop', 'فروشگاه', 'shop'),
      ('profile', 'پروفایل', 'profile'),
    ];
    return Container(
      color: Colors.transparent,
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: SizedBox(
        height: 94,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: items.map((it) {
            final selected = active == it.$1;
            final isHome = it.$1 == 'home';
            return Expanded(
              child: GestureDetector(
                onTap: () => onTap(it.$1),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  height: isHome ? 86 : 72,
                  margin: EdgeInsets.only(top: isHome ? 0 : 10, left: 5, right: 5),
                  decoration: BoxDecoration(
                    gradient: selected || isHome ? const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [AppColor.cyan, AppColor.primary, AppColor.orange]) : const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFEFFBFF)]),
                    borderRadius: BorderRadius.circular(isHome ? 28 : 20),
                    border: Border.all(color: selected || isHome ? Colors.white.withOpacity(.50) : AppColor.cyan.withOpacity(.14)),
                    boxShadow: [BoxShadow(color: const Color(0xFF374696).withOpacity(selected || isHome ? .22 : .12), blurRadius: selected || isHome ? 26 : 18, offset: const Offset(0, 10))],
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [HtmlSvgIcon(it.$3, size: isHome ? 31 : 25, color: selected || isHome ? Colors.white : const Color(0xFF5C6B82)), const SizedBox(height: 5), Text(it.$2, maxLines: 1, style: TextStyle(fontSize: isHome ? 12 : 11, color: selected || isHome ? Colors.white : const Color(0xFF53627B), fontWeight: FontWeight.w900))]),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class HtmlIconBox extends StatelessWidget {
  final String icon;
  final double size;
  final double radius;
  final List<Color>? colors;
  final Color iconColor;
  const HtmlIconBox({super.key, required this.icon, required this.size, required this.radius, this.colors, this.iconColor = AppColor.primary});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors ?? const [Colors.white, Color(0xFFE9F8FF), Color(0xFFD9D2FF)]),
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: AppColor.primary.withOpacity(.16)),
          boxShadow: [BoxShadow(color: const Color(0xFF4C56AA).withOpacity(.14), blurRadius: 24, offset: const Offset(0, 14))],
        ),
        child: Center(child: HtmlSvgIcon(icon, size: size * .55, color: iconColor)),
      );
}

class HtmlSvgIcon extends StatelessWidget {
  final String name;
  final double size;
  final Color color;
  const HtmlSvgIcon(this.name, {super.key, required this.size, required this.color});
  @override
  Widget build(BuildContext context) {
    final path = svgPaths[name] ?? svgPaths['star']!;
    final svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">$path</svg>';
    return SvgPicture.string(svg, width: size, height: size, colorFilter: ColorFilter.mode(color, BlendMode.srcIn));
  }
}

const svgPaths = <String, String>{
  'brain': r'''<path d="M9 6.4c-2.1.2-3.6 1.8-3.6 3.8 0 1 .4 1.9 1 2.5-.8.6-1.3 1.5-1.3 2.6 0 1.8 1.5 3.3 3.3 3.3h1.1V6.4Z"/><path d="M15 6.4c2.1.2 3.6 1.8 3.6 3.8 0 1-.4 1.9-1 2.5.8.6 1.3 1.5 1.3 2.6 0 1.8-1.5 3.3-3.3 3.3h-1.1V6.4Z"/><path d="M9.5 9.5H7.8M14.5 9.5h1.7M9.5 13H7.6M14.5 13h1.9M9.5 16.4H8.2M14.5 16.4h1.3"/>''',
  'coin': r'''<circle cx="12" cy="12" r="8"/><path d="M9 10.2c.7-1 2-1.5 3.3-1.2 1.5.3 2.7 1.5 2.7 3s-1.2 2.7-2.7 3c-1.3.3-2.6-.2-3.3-1.2"/><path d="M8.5 12h6"/>''',
  'energy': r'''<path d="M13 2.8 5.5 13h5.2L9.8 21.2 18.5 10h-5.3L13 2.8Z"/>''',
  'profile': r'''<circle cx="12" cy="8" r="3.6"/><path d="M4.8 20c1.2-4.2 13.2-4.2 14.4 0"/>''',
  'home': r'''<path d="M3.5 11.2 12 4l8.5 7.2"/><path d="M6.2 10.5v9h11.6v-9"/><path d="M10 19.5v-5h4v5"/>''',
  'gift': r'''<path d="M4.5 9h15v11h-15z"/><path d="M3.5 9h17V6.2h-17z"/><path d="M12 6.2V20"/><path d="M12 6.2C10.8 3 7.3 3.2 7.3 5.4c0 1.5 2.2 1.8 4.7.8ZM12 6.2c1.2-3.2 4.7-3 4.7-.8 0 1.5-2.2 1.8-4.7.8Z"/>''',
  'trophy': r'''<path d="M8 4h8v4.8c0 2.2-1.8 4-4 4s-4-1.8-4-4V4Z"/><path d="M8 6H5.2c0 3.8 2 5.4 4.3 5.6M16 6h2.8c0 3.8-2 5.4-4.3 5.6M12 12.8v3.8M8.8 20h6.4M10 16.6h4"/>''',
  'shop': r'''<path d="M5.2 9.5h13.6l-1 10H6.2l-1-10Z"/><path d="M8.5 9.5V8a3.5 3.5 0 0 1 7 0v1.5"/><path d="M4 9.5h16"/>''',
  'riddle': r'''<path d="M9 18h6M9.5 21h5"/><path d="M8.2 14.5c-1.3-1.1-2-2.7-2-4.4a5.8 5.8 0 0 1 11.6 0c0 1.7-.7 3.3-2 4.4-.8.7-1.1 1.4-1.2 2H9.4c-.1-.6-.4-1.3-1.2-2Z"/><path d="M10.8 10.3c.2-1.8 2.8-1.7 2.8.1 0 1.3-1.6 1.4-1.6 2.6M12 15h.1"/>''',
  'word': r'''<path d="M5 18 9.3 6h1.4L15 18M6.5 14h7"/><path d="M17 8h2.5M17 12h2.5M17 16h2.5"/>''',
  'speed': r'''<circle cx="12" cy="13" r="7"/><path d="M9 3h6M12 13V9M12 13l3 2"/>''',
  'logic': r'''<path d="M8 4h4v4H8zM12 8h4v4h-4zM8 12h4v4H8zM12 16h4v4h-4z"/><path d="M12 6h2M10 10h2M12 14h2"/>''',
  'picture': r'''<path d="M3.5 12s3.2-5.2 8.5-5.2 8.5 5.2 8.5 5.2-3.2 5.2-8.5 5.2S3.5 12 3.5 12Z"/><circle cx="12" cy="12" r="2.8"/>''',
  'ad': r'''<rect x="4" y="6" width="16" height="12" rx="3"/><path d="m10 10 5 2.5-5 2.5Z"/>''',
  'target': r'''<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1.2"/>''',
  'medal': r'''<path d="M8 3h8l-2 5h-4L8 3Z"/><circle cx="12" cy="14" r="5"/><path d="M12 11.5v4.8M9.8 14h4.4"/>''',
  'star': r'''<path d="m12 3 2.4 5 5.5.8-4 3.9.9 5.5-4.8-2.6-4.8 2.6.9-5.5-4-3.9 5.5-.8L12 3Z"/>''',
  'amusement': r'''<circle cx="12" cy="12" r="7"/><path d="M12 5v14M5 12h14M7.1 7.1l9.8 9.8M16.9 7.1l-9.8 9.8"/><circle cx="12" cy="12" r="1.3"/>''',
  'check': r'''<path d="m5 12 4 4 10-10"/>''',
  'truefalse': r'''<path d="m4 7 4 4 5-7"/><path d="M14 8h6M14 12h6M5 18h14"/>''',
  'yesno': r'''<path d="m5 12 4 4 10-10"/><path d="M4 5h16M4 19h16"/>''',
  'typo': r'''<path d="M5 6h14M7 6v12M17 6v12"/><path d="M8 18h3M15 18h3"/>''',
};
